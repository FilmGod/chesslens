# ChessLens — ผู้ช่วยดูกระดานหมากรุกบนหน้าจอ (Android)

แอปจะขออนุญาตบันทึกหน้าจอ ดูกระดานหมากรุกที่เปิดอยู่ อ่านตำแหน่งหมาก ติดตามเกม
แล้ววาด **ลูกศรบอกตาเดินที่ดีที่สุด** ทับบนหน้าจอ พร้อมข้อความ เช่น "ม้า g1 → f3"

> ใช้เพื่อฝึกซ้อม เล่นกับบอท หรือทบทวนเกมเก่า การใช้ช่วยตัดสินใจระหว่างเกมจริงกับคนอื่น
> ผิดกติกาของ lichess, chess.com และเว็บส่วนใหญ่ และอาจทำให้บัญชีถูกแบน

## สร้างไฟล์ APK (ไม่ต้องมีคอมพิวเตอร์ที่ลง Android Studio)

1. สมัคร GitHub (ฟรี) แล้วสร้าง repository ใหม่ (เลือก Private ได้)
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ขึ้นไป (รวมโฟลเดอร์ `.github` และ `gradle`)
   — ถ้าใช้เว็บ GitHub ให้ลากทั้งโฟลเดอร์ใส่ได้เลย หรือใช้ `git push`
3. ไปที่แท็บ **Actions** → เลือก **Build APK** → กด **Run workflow** (ถ้าไม่ได้รันเอง)
4. รอประมาณ 5–10 นาที เมื่อเสร็จ เปิดรันนั้น เลื่อนลงล่างสุดที่ **Artifacts** → ดาวน์โหลด `ChessLens-apk`
5. แตก zip ได้ `app-debug.apk` → ส่งเข้าแท็บเล็ต/มือถือแล้วติดตั้ง (อนุญาต "ติดตั้งแอปจากแหล่งที่ไม่รู้จัก")

ถ้าสร้างไม่ผ่าน ให้คัดลอกข้อความ error สีแดงจากหน้า Actions มาให้ผม แล้วจะแก้ให้

ทางเลือก: ถ้ามีคอมพิวเตอร์ เปิดโฟลเดอร์นี้ด้วย Android Studio แล้วกด Run หรือใช้คำสั่ง `./gradlew assembleDebug`
ไฟล์จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## วิธีใช้

1. เปิดแอป ChessLens → ขั้นที่ 1 อนุญาต "แสดงทับแอปอื่น"
2. ขั้นที่ 2 เลือกว่าฝั่งล่างของกระดานบนจอเป็นสีขาวหรือดำ
3. กด **เริ่มทำงาน** → ระบบถามสิทธิ์บันทึกหน้าจอ (เลือกทั้งหน้าจอ) → จะมีแผงเล็กๆ ลอยอยู่
4. เปิดแอป/เว็บหมากรุก เริ่มเกมใหม่ (แนะนำเล่นกับบอทก่อน) ให้เห็นตำแหน่งเริ่มต้น
5. กด **ตั้งกรอบ** ลากกรอบสีเหลืองให้พอดีกับกระดาน 8x8 (ลากจุดกลมมุมขวาล่างเพื่อปรับขนาด ใช้ปุ่มลูกศรขยับทีละพิกเซล) แล้วกด ตกลง
6. กด **เรียนรู้** (ครั้งเดียวต่อธีมกระดาน) — แอปจะจำหน้าตาตัวหมากของคุณ
7. เล่นได้เลย เมื่อถึงตาคุณ จะมีลูกศรสีเขียวและข้อความบอกตาเดิน
   - "สลับตา" ใช้เมื่อแอปเดาว่าเป็นตาใครผิด (เช่นเริ่มดูกลางเกม)
   - หมุนหน้าจอ → ต้อง "ตั้งกรอบ" ใหม่สำหรับแนวนั้น (แอปจำไว้แยกตามแนว)
   - เปลี่ยนธีม/ชุดตัวหมาก → กด "เรียนรู้" ใหม่ตอนตำแหน่งเริ่มเกม

## เอนจิน

- ค่าเริ่มต้น: เอนจินในตัว (เขียนเอง ระดับประมาณผู้เล่นสโมสร) ไม่ต้องดาวน์โหลดอะไร
- ถ้า GitHub ดึง Stockfish ได้ตอนสร้าง APK แอปจะใช้ Stockfish (แรงกว่ามาก) โดยอัตโนมัติ
  (Stockfish ใช้สัญญาอนุญาต GPLv3) แผงจะแสดงชื่อเอนจินที่ใช้อยู่ท้ายข้อความ

## ข้อจำกัดที่ควรรู้

- การอ่านกระดานทำงานโดยเรียนรู้จากหน้าจอของคุณเอง ทดสอบกับภาพจำลองเท่านั้น
  ยังไม่ได้ลองกับแอปหมากรุกจริง ถ้าอ่านไม่ออกบ่อย ให้ตั้งกรอบใหม่ให้พอดี ปิดแอนิเมชัน/เอฟเฟกต์
  บนกระดาน และกด "เรียนรู้" ใหม่
- ถ้ากระดานมีลูกศร/ไฮไลต์ที่ทับตัวหมาก (เช่นลูกศรจากเว็บเอง) อาจอ่านผิดได้
- แอปไม่เดินหมากแทนคุณ แสดงลูกศรเท่านั้น
- โครงสร้างโค้ด: `core/` คือสมอง (กติกา เอนจิน อ่านภาพ ติดตามเกม) ทดสอบได้โดยไม่ต้องใช้ Android
  (`./gradlew testDebugUnitTest`) ส่วน `CaptureService.kt` คือส่วนบันทึกหน้าจอและวาดลูกศร


## อัปเดต: ระบบอัตโนมัติ
- หากระดานบนหน้าจอเอง (ตรวจลายตาราง 8x8) ไม่ต้องลากกรอบ — ถ้าไม่เจอยังกด "ตั้งกรอบ" เองได้
- รู้เองว่าคุณเล่นขาวหรือดำ (ดูสีหมากตอนเริ่มเกม / ตำแหน่งคิงระหว่างเกม) ปุ่ม "กลับฝั่ง" ไว้แก้ถ้าผิด
- เรียนรู้ตัวหมากเองเมื่อเห็นตำแหน่งเริ่มเกม ไม่ต้องกด "เรียนรู้"

## Tap moves (practice against bots / engines only)
Enable the "ChessLens" accessibility service (Settings > Accessibility). The floating panel then has:
- **เดินให้** – taps the advised move once, when you press it.
- **ออโต้** – plays every move on your turn until you switch it off (asks for a second tap to confirm).
It only taps the two squares of the move; promotions are always queened (a second tap on the destination square picks the queen). Use it against bots or engines, never against real people.

## Activation keys
The app can require a one-device, time-limited key. Server code and setup steps are in `license-server/` (Cloudflare Worker).
Until `app/src/main/assets/license.json` contains a server address, the app runs without a key.

## Display options
Settings card in the app (and two quick buttons on the panel): evaluation bar beside the board, the three best moves as
coloured arrows with scores, and an engine strength slider (Stockfish only; Elo 1350–2850 or full strength).

## เวอร์ชัน PC (Windows)
โฟลเดอร์ `pc/` เป็นโปรแกรม Windows (Kotlin + Swing) ที่ใช้แกนเดียวกับแอปมือถือ (อ่านกระดาน ติดตามเกม เอนจิน ระบบคีย์)
- แคปหน้าจอด้วย Robot, วาดลูกศร/แถบประเมินบนหน้าต่างโปร่งใสที่เมาส์คลิกทะลุได้, "เดินให้/ออโต้" คลิกเมาส์จริง
- วางคู่กับ `stockfish.exe` ในโฟลเดอร์เดียวกันเพื่อใช้ Stockfish (ถ้าไม่มีจะใช้เอนจินในตัว)
- build: `./gradlew -p pc jar` หรือจาก GitHub Actions job `build-pc` (ได้ ChessLens-Windows.zip)
- ตั้งค่าเก็บที่ `%USERPROFILE%\.chesslens`
