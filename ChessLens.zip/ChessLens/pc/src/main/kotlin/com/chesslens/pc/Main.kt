package com.chesslens.pc

import javax.swing.SwingUtilities
import javax.swing.UIManager

fun main(args: Array<String>) {

    val settings = PcSettings()
    val license = PcLicense(settings.dir)
    val controller = Controller(settings, license)
    SwingUtilities.invokeLater {
        val w = ControlWindow(controller)
        w.show()
        Thread { license.refresh() }.start()
    }
}
