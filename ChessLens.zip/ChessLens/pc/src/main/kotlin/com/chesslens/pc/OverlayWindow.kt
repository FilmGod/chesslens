package com.chesslens.pc

import java.awt.BasicStroke
import java.awt.Color
import java.awt.Font
import java.awt.Graphics
import java.awt.Graphics2D
import java.awt.GraphicsDevice
import java.awt.RenderingHints
import java.awt.Rectangle
import java.awt.geom.Path2D
import java.awt.geom.RoundRectangle2D
import javax.swing.JPanel
import javax.swing.JWindow
import javax.swing.SwingUtilities
import javax.swing.Timer

/** Transparent, click-through window over one monitor that draws the arrows and the evaluation bar. */
class OverlayWindow(private val device: GraphicsDevice) {
    private val panel = ArrowPanel()
    private val window = JWindow()

    init {
        window.isAlwaysOnTop = true
        window.focusableWindowState = false
        window.background = Color(0, 0, 0, 0)
        panel.isOpaque = false
        window.contentPane = panel
        window.bounds = device.defaultConfiguration.bounds
    }

    fun show() {
        SwingUtilities.invokeAndWait {
            window.isVisible = true
            window.bounds = device.defaultConfiguration.bounds
            ClickThrough.apply(window)
            window.isAlwaysOnTop = true
        }
    }

    fun dispose() {
        SwingUtilities.invokeLater { panel.stop(); window.dispose() }
    }

    /** True when the arrows can be shown without blocking the mouse. */
    val clickThrough: Boolean get() = ClickThrough.isWindows

    fun setArrow(board: Rectangle?, from: Int, to: Int, bottomWhite: Boolean, extras: List<IntArray>) =
        SwingUtilities.invokeLater { panel.setArrow(board, from, to, bottomWhite, extras) }

    /** Removes the arrows and waits until the screen has really been repainted, so the next capture is clean. */
    fun clearArrowSync() {
        try {
            SwingUtilities.invokeAndWait { panel.clearArrow() }
        } catch (e: Exception) { }
    }

    fun clearArrow() = SwingUtilities.invokeLater { panel.clearArrow() }

    fun setEval(board: Rectangle?, whiteFrac: Float, text: String) =
        SwingUtilities.invokeLater { panel.setEval(board, whiteFrac, text) }

    private class ArrowPanel : JPanel() {
        private var board: Rectangle? = null
        private var from = -1
        private var to = -1
        private var bottomWhite = true
        private var extras: List<IntArray> = emptyList()
        private var progress = 1f
        private var pulse = 0f
        private var evalBoard: Rectangle? = null
        private var evalShown = 0.5f
        private var evalTarget = 0.5f
        private var evalText = ""
        private var evalOn = false
        private var t0 = 0L
        private val timer = Timer(16) { tick() }

        private val accent = Color(52, 226, 168)

        fun stop() = timer.stop()

        private fun tick() {
            val now = System.currentTimeMillis()
            if (board != null && from >= 0) {
                val p = ((now - t0) / 260f).coerceIn(0f, 1f)
                progress = 1f - (1f - p) * (1f - p)
                pulse = (0.5f - 0.5f * Math.cos((now - t0) / 900.0 * Math.PI * 2).toFloat())
            }
            evalShown += (evalTarget - evalShown) * 0.18f
            if (Math.abs(evalTarget - evalShown) < 0.002f) evalShown = evalTarget
            repaint()
            if ((board == null || from < 0) && !evalOn) timer.stop()
        }

        fun setArrow(b: Rectangle?, f: Int, t: Int, bw: Boolean, ex: List<IntArray>) {
            val same = from == f && to == t && bottomWhite == bw && board != null
            board = b?.let { Rectangle(it) }
            from = f
            to = t
            bottomWhite = bw
            extras = ex
            if (!same) {
                progress = 0f
                t0 = System.currentTimeMillis()
            }
            if (!timer.isRunning) timer.start()
            repaint()
        }

        fun clearArrow() {
            board = null
            from = -1
            to = -1
            extras = emptyList()
            paintImmediately(0, 0, width, height)
        }

        fun setEval(b: Rectangle?, frac: Float, text: String) {
            if (b == null) {
                evalOn = false
                repaint()
                return
            }
            evalBoard = Rectangle(b)
            evalText = text
            evalTarget = frac.coerceIn(0.02f, 0.98f)
            if (!evalOn) {
                evalOn = true
                evalShown = evalTarget
            }
            if (!timer.isRunning) timer.start()
            repaint()
        }

        private fun cx(r: Rectangle, sq: Int): Float {
            val f = if (bottomWhite) sq and 7 else 7 - (sq and 7)
            return r.x + (f + 0.5f) * r.width / 8f
        }

        private fun cy(r: Rectangle, sq: Int): Float {
            val k = if (bottomWhite) 7 - (sq shr 3) else sq shr 3
            return r.y + (k + 0.5f) * r.height / 8f
        }

        override fun paintComponent(g0: Graphics) {
            super.paintComponent(g0)
            val g = g0 as Graphics2D
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
            drawEval(g)
            val r = board ?: return
            if (from < 0 || to < 0) return
            val cell = r.width / 8f
            val colors = arrayOf(Color(255, 196, 61), Color(110, 170, 255), Color(255, 130, 190), Color(190, 150, 255))
            for ((i, e) in extras.withIndex().reversed()) drawShape(g, r, e[0], e[1], 1f, 0.72f, colors[i % colors.size], 175)
            val ringAlpha = (255 * (0.95f - 0.35f * pulse)).toInt()
            g.color = Color(accent.red, accent.green, accent.blue, ringAlpha)
            g.stroke = BasicStroke(cell * 0.07f)
            val rad = cell * (0.38f + 0.06f * pulse)
            g.draw(java.awt.geom.Ellipse2D.Float(cx(r, from) - rad, cy(r, from) - rad, rad * 2, rad * 2))
            drawShape(g, r, from, to, progress, 1f, accent, 240)
        }

        private fun drawShape(g: Graphics2D, r: Rectangle, from: Int, to: Int, p: Float, widthScale: Float, color: Color, alpha: Int) {
            val cell = r.width / 8f
            val ax = cx(r, from)
            val ay = cy(r, from)
            val fullBx = cx(r, to)
            val fullBy = cy(r, to)
            val bx = ax + (fullBx - ax) * p
            val by = ay + (fullBy - ay) * p
            val dx = fullBx - ax
            val dy = fullBy - ay
            val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len < 1f) return
            val ux = dx / len
            val uy = dy / len
            val headScale = if (p < 0.5f) p * 2f else 1f
            val headLen = cell * 0.45f * headScale * widthScale
            val headHalf = cell * 0.27f * headScale * widthScale
            val lineW = cell * 0.17f * widthScale
            val baseX = bx - ux * headLen
            val baseY = by - uy * headLen
            val startX = ax + ux * cell * 0.15f
            val startY = ay + uy * cell * 0.15f
            val white = Color(255, 255, 255, alpha * 215 / 255)
            val main = Color(color.red, color.green, color.blue, alpha)
            val glow = Color(color.red, color.green, color.blue, alpha / 4)
            g.stroke = BasicStroke(lineW * 2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)
            g.color = glow
            g.draw(java.awt.geom.Line2D.Float(startX, startY, baseX, baseY))
            g.stroke = BasicStroke(lineW + cell * 0.07f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)
            g.color = white
            g.draw(java.awt.geom.Line2D.Float(startX, startY, baseX, baseY))
            g.stroke = BasicStroke(lineW, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)
            g.color = main
            g.draw(java.awt.geom.Line2D.Float(startX, startY, baseX, baseY))
            if (headLen > 1f) {
                val head = Path2D.Float()
                head.moveTo(bx.toDouble(), by.toDouble())
                head.lineTo((baseX - uy * headHalf).toDouble(), (baseY + ux * headHalf).toDouble())
                head.lineTo((baseX + uy * headHalf).toDouble(), (baseY - ux * headHalf).toDouble())
                head.closePath()
                g.stroke = BasicStroke(cell * 0.07f * widthScale, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)
                g.color = white
                g.draw(head)
                g.color = main
                g.fill(head)
            }
        }

        private fun drawEval(g: Graphics2D) {
            if (!evalOn) return
            val eb = evalBoard ?: return
            val cell = eb.width / 8f
            val w = Math.max(8f, Math.min(cell * 0.3f, 18f))
            val gap = 4f
            var x1 = eb.x - gap - w
            if (x1 < 2f) x1 = eb.x + eb.width + gap
            if (x1 + w > width - 2f) return
            val top = eb.y.toFloat()
            val h = eb.height.toFloat()
            val shape = RoundRectangle2D.Float(x1, top, w, h, w, w)
            val old = g.clip
            g.clip(shape)
            g.color = Color(34, 38, 46)
            g.fill(shape)
            g.color = Color(240, 244, 248)
            val lightH = h * evalShown
            if (bottomWhite) g.fillRect(x1.toInt(), (top + h - lightH).toInt(), w.toInt() + 1, lightH.toInt() + 1)
            else g.fillRect(x1.toInt(), top.toInt(), w.toInt() + 1, lightH.toInt() + 1)
            g.color = Color(52, 226, 168, 170)
            g.stroke = BasicStroke(1f)
            g.drawLine(x1.toInt(), (top + h / 2).toInt(), (x1 + w).toInt(), (top + h / 2).toInt())
            g.clip = old
            g.color = Color(20, 24, 30, 160)
            g.draw(shape)
            g.font = Font("SansSerif", Font.BOLD, 13)
            val tw = g.fontMetrics.stringWidth(evalText)
            val ty = if (top > 22f) top - 6f else top + h + 16f
            val tx = (x1 + w / 2 - tw / 2).coerceIn(2f, width - tw - 2f)
            g.color = Color(0, 0, 0, 200)
            g.drawString(evalText, tx + 1, ty + 1)
            g.color = Color.WHITE
            g.drawString(evalText, tx, ty)
        }
    }
}
