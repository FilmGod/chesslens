package com.chesslens.pc

import java.awt.BasicStroke
import java.awt.Color
import java.awt.Cursor
import java.awt.Graphics
import java.awt.Graphics2D
import java.awt.GraphicsDevice
import java.awt.Point
import java.awt.Rectangle
import java.awt.event.KeyAdapter
import java.awt.event.KeyEvent
import java.awt.event.MouseAdapter
import java.awt.event.MouseEvent
import javax.swing.JPanel
import javax.swing.JWindow

/** Full-screen dim layer where the user drags a square around the board. Esc cancels. */
object FrameSelector {
    fun select(device: GraphicsDevice, done: (Rectangle?) -> Unit) {
        val w = JWindow()
        w.isAlwaysOnTop = true
        w.bounds = device.defaultConfiguration.bounds
        w.background = Color(0, 0, 0, 90)
        var a: Point? = null
        var b: Point? = null
        val panel = object : JPanel() {
            init { isOpaque = false; cursor = Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR) }
            override fun paintComponent(g0: Graphics) {
                val g = g0 as Graphics2D
                g.color = Color(0, 0, 0, 90)
                g.fillRect(0, 0, width, height)
                g.color = Color.WHITE
                g.drawString("ลากกรอบรอบกระดาน (กด Esc เพื่อยกเลิก)", 20, 30)
                val r = square(a, b) ?: return
                g.color = Color(52, 226, 168, 60)
                g.fillRect(r.x, r.y, r.width, r.height)
                g.color = Color(52, 226, 168)
                g.stroke = BasicStroke(2f)
                g.drawRect(r.x, r.y, r.width, r.height)
            }
        }
        w.contentPane = panel
        fun finish(r: Rectangle?) {
            w.dispose()
            done(r)
        }
        panel.addMouseListener(object : MouseAdapter() {
            override fun mousePressed(e: MouseEvent) { a = e.point; b = e.point; panel.repaint() }
            override fun mouseReleased(e: MouseEvent) {
                b = e.point
                val r = square(a, b)
                finish(if (r != null && r.width >= 80) r else null)
            }
        })
        panel.addMouseMotionListener(object : MouseAdapter() {
            override fun mouseDragged(e: MouseEvent) { b = e.point; panel.repaint() }
        })
        panel.isFocusable = true
        panel.addKeyListener(object : KeyAdapter() {
            override fun keyPressed(e: KeyEvent) { if (e.keyCode == KeyEvent.VK_ESCAPE) finish(null) }
        })
        w.isVisible = true
        panel.requestFocusInWindow()
    }

    private fun square(a: Point?, b: Point?): Rectangle? {
        if (a == null || b == null) return null
        val s = Math.max(Math.abs(b.x - a.x), Math.abs(b.y - a.y))
        val x = if (b.x >= a.x) a.x else a.x - s
        val y = if (b.y >= a.y) a.y else a.y - s
        return Rectangle(x, y, s, s)
    }
}
