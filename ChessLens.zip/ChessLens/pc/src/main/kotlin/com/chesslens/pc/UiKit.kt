package com.chesslens.pc

import java.awt.BasicStroke
import java.awt.Color
import java.awt.Cursor
import java.awt.Dimension
import java.awt.Font
import java.awt.Graphics
import java.awt.Graphics2D
import java.awt.GradientPaint
import java.awt.RenderingHints
import java.awt.event.MouseAdapter
import java.awt.event.MouseEvent
import java.awt.geom.RoundRectangle2D
import javax.swing.JButton
import javax.swing.JComponent
import javax.swing.JPanel
import javax.swing.JSlider
import javax.swing.Timer
import javax.swing.plaf.basic.BasicSliderUI

object Theme {
    val bg = Color(14, 17, 23)
    val card = Color(24, 29, 38)
    val cardLine = Color(44, 52, 66)
    val text = Color(236, 240, 245)
    val dim = Color(140, 152, 168)
    val accent = Color(52, 226, 168)
    val accent2 = Color(60, 160, 255)
    val btn = Color(36, 43, 55)
    val btnHover = Color(48, 58, 74)
    val danger = Color(255, 107, 107)
    /** A font that really has Thai glyphs (Segoe UI does not, which showed up as empty boxes). */
    private val family: String by lazy {
        val names = try {
            java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().availableFontFamilyNames.toHashSet()
        } catch (e: Throwable) { hashSetOf<String>() }
        val candidates = listOf("Leelawadee UI", "Tahoma", "Leelawadee", "Noto Sans Thai", "Segoe UI")
        candidates.firstOrNull { it in names && Font(it, Font.PLAIN, 12).canDisplay('\u0e01') } ?: Font.DIALOG
    }

    fun font(size: Float, bold: Boolean = false): Font = Font(family, if (bold) Font.BOLD else Font.PLAIN, 12).deriveFont(size)
    fun mix(a: Color, b: Color, t: Float) = Color(
        (a.red + (b.red - a.red) * t).toInt(), (a.green + (b.green - a.green) * t).toInt(), (a.blue + (b.blue - a.blue) * t).toInt()
    )
}

private fun Graphics2D.smooth() {
    setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
    setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
}

/** Flat rounded button; the hover colour fades for a fraction of a second, nothing runs while idle. */
class FlatButton(text: String, private val primary: Boolean = false) : JButton(text) {
    private var hover = 0f
    private var target = 0f
    private var down = false
    private val timer = Timer(16) {
        hover += (target - hover) * 0.35f
        if (Math.abs(target - hover) < 0.02f) { hover = target; (it.source as Timer).stop() }
        repaint()
    }
    var danger = false

    init {
        isContentAreaFilled = false
        isBorderPainted = false
        isFocusPainted = false
        isOpaque = false
        font = Theme.font(13f, true)
        cursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        preferredSize = Dimension(90, 34)
        addMouseListener(object : MouseAdapter() {
            override fun mouseEntered(e: MouseEvent) { target = 1f; timer.start() }
            override fun mouseExited(e: MouseEvent) { target = 0f; down = false; timer.start() }
            override fun mousePressed(e: MouseEvent) { down = true; repaint() }
            override fun mouseReleased(e: MouseEvent) { down = false; repaint() }
        })
    }

    override fun paintComponent(g0: Graphics) {
        val g = g0 as Graphics2D
        g.smooth()
        val w = width.toFloat()
        val h = height.toFloat()
        val shape = RoundRectangle2D.Float(0f, 0f, w - 1, h - 1, 12f, 12f)
        if (!isEnabled) {
            g.color = Color(30, 35, 44)
            g.fill(shape)
            g.color = Theme.dim
        } else if (primary) {
            val top = Theme.mix(Theme.accent, Color.WHITE, 0.15f * hover)
            val bot = Theme.mix(Theme.accent2, Color.WHITE, 0.15f * hover)
            g.paint = GradientPaint(0f, 0f, top, w, h, bot)
            g.fill(shape)
            g.color = Color(8, 20, 20)
        } else {
            g.color = Theme.mix(Theme.btn, Theme.btnHover, hover)
            g.fill(shape)
            g.color = Theme.mix(Theme.cardLine, Theme.accent, hover * 0.8f)
            g.stroke = BasicStroke(1f)
            g.draw(shape)
            g.color = if (danger) Theme.danger else Theme.text
        }
        if (down) { g.color = Color(0, 0, 0, 50); g.fill(shape); g.color = if (primary) Color(8, 20, 20) else Theme.text }
        g.font = font
        val fm = g.fontMetrics
        g.drawString(text, (w - fm.stringWidth(text)) / 2, (h + fm.ascent - fm.descent) / 2)
    }
}

/** Little on/off switch with a label. */
class SwitchBox(private val label: String, selected: Boolean) : JComponent() {
    var isSelected = selected
        private set
    private var pos = if (selected) 1f else 0f
    private val listeners = ArrayList<() -> Unit>()
    private val timer = Timer(16) {
        val t = if (isSelected) 1f else 0f
        pos += (t - pos) * 0.4f
        if (Math.abs(t - pos) < 0.03f) { pos = t; (it.source as Timer).stop() }
        repaint()
    }

    init {
        preferredSize = Dimension(200, 28)
        maximumSize = Dimension(Int.MAX_VALUE, 28)
        cursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        addMouseListener(object : MouseAdapter() {
            override fun mouseClicked(e: MouseEvent) {
                isSelected = !isSelected
                timer.start()
                listeners.forEach { it() }
            }
        })
    }

    fun onChange(f: () -> Unit) { listeners.add(f) }

    override fun paintComponent(g0: Graphics) {
        val g = g0 as Graphics2D
        g.smooth()
        val tw = 40f
        val th = 20f
        val y = (height - th) / 2
        g.color = Theme.mix(Color(52, 60, 74), Theme.accent, pos)
        g.fill(RoundRectangle2D.Float(2f, y, tw, th, th, th))
        g.color = Color.WHITE
        val kx = 2f + 3f + (tw - th) * pos
        g.fillOval(kx.toInt(), (y + 3).toInt(), (th - 6).toInt(), (th - 6).toInt())
        g.color = Theme.text
        g.font = Theme.font(13f)
        val fm = g.fontMetrics
        g.drawString(label, tw + 14, (height + fm.ascent - fm.descent) / 2f)
    }
}

class CardPanel : JPanel() {
    init { isOpaque = false }
    override fun paintComponent(g0: Graphics) {
        val g = g0 as Graphics2D
        g.smooth()
        val shape = RoundRectangle2D.Float(0f, 0f, width - 1f, height - 1f, 16f, 16f)
        g.color = Color(16, 12, 30, 205)
        g.fill(shape)
        g.color = Color(150, 110, 230, 90)
        g.draw(shape)
    }
}

/** Header strip with the app name and a state dot. */
class HeaderBar : JComponent() {
    var running = false
        set(v) { field = v; repaint() }
    init { preferredSize = Dimension(100, 44) }
    override fun paintComponent(g0: Graphics) {
        val g = g0 as Graphics2D
        g.smooth()
        g.paint = GradientPaint(0f, 0f, Color(10, 6, 24, 190), width.toFloat(), 0f, Color(10, 6, 24, 90))
        g.fillRect(0, 0, width, height)
        g.color = if (running) Theme.accent else Theme.dim
        g.fillOval(16, height / 2 - 5, 10, 10)
        if (running) { g.color = Color(Theme.accent.red, Theme.accent.green, Theme.accent.blue, 60); g.fillOval(12, height / 2 - 9, 18, 18) }
        g.font = Theme.font(17f, true)
        g.color = Theme.text
        g.drawString("ChessLens", 40, height / 2 + 6)
        g.font = Theme.font(12f)
        g.color = Theme.dim
        val s = if (running) "กำลังทำงาน" else "หยุดอยู่"
        g.drawString(s, width - 16 - g.fontMetrics.stringWidth(s), height / 2 + 5)
        g.color = Theme.cardLine
        g.drawLine(0, height - 1, width, height - 1)
    }
}

class SliderUi(s: JSlider) : BasicSliderUI(s) {
    override fun paintTrack(g0: Graphics) {
        val g = g0 as Graphics2D
        g.smooth()
        val r = trackRect
        val y = r.y + r.height / 2 - 3
        g.color = Color(44, 52, 66)
        g.fill(RoundRectangle2D.Float(r.x.toFloat(), y.toFloat(), r.width.toFloat(), 6f, 6f, 6f))
        val kx = thumbRect.x + thumbRect.width / 2
        g.paint = GradientPaint(r.x.toFloat(), 0f, Theme.accent, r.x + r.width.toFloat(), 0f, Theme.accent2)
        g.fill(RoundRectangle2D.Float(r.x.toFloat(), y.toFloat(), (kx - r.x).toFloat(), 6f, 6f, 6f))
    }
    override fun paintThumb(g0: Graphics) {
        val g = g0 as Graphics2D
        g.smooth()
        g.color = Color.WHITE
        g.fillOval(thumbRect.x + 1, thumbRect.y + 2, 16, 16)
        g.color = Theme.accent
        g.fillOval(thumbRect.x + 5, thumbRect.y + 6, 8, 8)
    }
    override fun getThumbSize() = Dimension(18, 20)
    override fun paintFocus(g: Graphics) {}
    override fun paintTicks(g: Graphics) {}
    override fun paintLabels(g: Graphics) {}
}

/** Window background: the artwork scaled once to fill the panel (cover), darkened so text stays readable. */
class BackgroundPanel : JPanel() {
    private val src: java.awt.image.BufferedImage? = try {
        BackgroundPanel::class.java.getResourceAsStream("/bg.jpg")?.use { javax.imageio.ImageIO.read(it) }
    } catch (e: Exception) { null }
    private var cache: java.awt.image.BufferedImage? = null
    private var cw = 0
    private var ch = 0

    init { background = Theme.bg }

    override fun paintComponent(g0: Graphics) {
        val g = g0 as Graphics2D
        g.color = Theme.bg
        g.fillRect(0, 0, width, height)
        val s = src ?: return
        if (width <= 0 || height <= 0) return
        if (cache == null || cw != width || ch != height) {
            val scale = Math.max(width.toDouble() / s.width, height.toDouble() / s.height)
            val sw = (s.width * scale).toInt()
            val sh = (s.height * scale).toInt()
            val out = java.awt.image.BufferedImage(width, height, java.awt.image.BufferedImage.TYPE_INT_RGB)
            val og = out.createGraphics()
            og.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC)
            og.drawImage(s, (width - sw) / 2, (height - sh) / 2, sw, sh, null)
            og.color = Color(6, 4, 16, 110)
            og.fillRect(0, 0, width, height)
            og.dispose()
            cache = out
            cw = width
            ch = height
        }
        g.drawImage(cache, 0, 0, null)
    }
}
