package com.chesslens.pc

import java.awt.GraphicsDevice
import java.awt.Rectangle
import java.awt.Robot

/** Screen capture of one monitor through java.awt.Robot. */
class RobotScreen(private val device: GraphicsDevice) : PixelScreen() {
    private val robot = Robot(device)
    val bounds: Rectangle get() = device.defaultConfiguration.bounds

    override fun captureFull(): Boolean = grab(Rectangle(0, 0, bounds.width, bounds.height))

    override fun captureRegion(r: Rectangle): Boolean {
        val b = bounds
        val c = r.intersection(Rectangle(0, 0, b.width, b.height))
        return !c.isEmpty && grab(c)
    }

    private fun grab(local: Rectangle): Boolean {
        return try {
            val b = bounds
            val img = robot.createScreenCapture(Rectangle(b.x + local.x, b.y + local.y, local.width, local.height))
            val data = img.getRGB(0, 0, img.width, img.height, null, 0, img.width)
            set(img.width, img.height, data, local.x, local.y, b.width, b.height)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Mouse clicks at screen-local points; times are offsets in ms from the first click. */
    fun click(points: List<java.awt.Point>, times: List<Long>) {
        val b = bounds
        val start = System.currentTimeMillis()
        for ((i, p) in points.withIndex()) {
            val wait = times[i] - (System.currentTimeMillis() - start)
            if (wait > 0) Thread.sleep(wait)
            robot.mouseMove(b.x + p.x, b.y + p.y)
            robot.delay(30)
            robot.mousePress(java.awt.event.InputEvent.BUTTON1_DOWN_MASK)
            robot.delay(40)
            robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_DOWN_MASK)
        }
    }
}
