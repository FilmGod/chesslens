package com.chesslens.pc

import com.chesslens.core.LicenseCore
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Properties
import java.util.UUID

/** Activation key handling for the PC app (same server and token format as the phone app). */
class PcLicense(dir: File) {
    private val file = File(dir, "license.properties")
    private val props = Properties()
    private val server: String
    private val pinnedPub: String

    init {
        try { file.inputStream().use { props.load(it) } } catch (e: Exception) { }
        val cfg = try {
            PcLicense::class.java.getResourceAsStream("/license.json")?.bufferedReader()?.use { it.readText() } ?: ""
        } catch (e: Exception) { "" }
        server = (LicenseCore.jsonString(cfg, "server") ?: "").trim().trimEnd('/')
        pinnedPub = (LicenseCore.jsonString(cfg, "pubkey") ?: "").trim()
    }

    private fun save() {
        try { file.outputStream().use { props.store(it, "ChessLens license") } } catch (e: Exception) { }
    }

    val required: Boolean get() = server.startsWith("https://")

    val device: String by lazy {
        var id = props.getProperty("deviceId", "")
        if (id.isEmpty()) {
            id = UUID.randomUUID().toString()
            props.setProperty("deviceId", id)
            save()
        }
        val host = try { java.net.InetAddress.getLocalHost().hostName } catch (e: Exception) { "pc" }
        MessageDigest.getInstance("SHA-256").digest("chesslens:pc:$id:$host".toByteArray()).joinToString("") { "%02x".format(it) }
    }

    class Status(val state: LicenseCore.State, val expiresAt: Long) {
        val daysLeft: Int get() = Math.max(0, Math.ceil((expiresAt - System.currentTimeMillis()) / 86400000.0).toInt())
    }

    private fun pub(): String = pinnedPub.ifEmpty { props.getProperty("pub", "") }

    fun status(): Status {
        if (!required) return Status(LicenseCore.State.VALID, Long.MAX_VALUE)
        val token = props.getProperty("token") ?: return Status(LicenseCore.State.INVALID, 0)
        val t = LicenseCore.parse(token, pub(), device)
        val st = LicenseCore.state(t, System.currentTimeMillis(), props.getProperty("lastOk", "0").toLongOrNull() ?: 0)
        return Status(st, t?.exp ?: 0)
    }

    val savedKey: String get() = props.getProperty("key", "")

    private fun post(path: String, body: String): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(server + path).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.requestMethod = if (body.isEmpty()) "GET" else "POST"
            if (body.isNotEmpty()) {
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            stream?.bufferedReader()?.use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    /** Error text for the user, or null when the key was accepted. Blocking. */
    fun activate(key: String): String? {
        if (!required) return null
        if (pinnedPub.isEmpty() && props.getProperty("pub", "").isEmpty()) {
            val r = post("/api/pubkey", "") ?: return "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ตรวจอินเทอร์เน็ตแล้วลองใหม่"
            val spki = LicenseCore.jsonString(r, "spki") ?: return "เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ"
            props.setProperty("pub", spki)
            save()
        }
        return check(key.trim(), false)
    }

    fun refresh(): String? {
        val k = savedKey
        if (!required || k.isEmpty()) return null
        return check(k, true)
    }

    private fun check(key: String, quietOffline: Boolean): String? {
        val body = "{\"key\":\"${key.replace("\"", "")}\",\"device\":\"$device\"}"
        val r = post("/api/verify", body)
            ?: return if (quietOffline) null else "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ตรวจอินเทอร์เน็ตแล้วลองใหม่"
        val ok = LicenseCore.jsonBool(r, "ok")
        if (ok == true) {
            val token = LicenseCore.jsonString(r, "token") ?: return "เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ"
            if (LicenseCore.parse(token, pub(), device) == null && pinnedPub.isEmpty()) {
                val spki = post("/api/pubkey", "")?.let { LicenseCore.jsonString(it, "spki") }
                if (spki != null) { props.setProperty("pub", spki); save() }
            }
            if (LicenseCore.parse(token, pub(), device) == null) {
                return if (LicenseCore.signatureOk(token, pub())) "คีย์นี้ออกให้เครื่องอื่น (รหัสเครื่องไม่ตรง)" else "ตรวจลายเซ็นของคีย์ไม่ผ่าน (กุญแจเซิร์ฟเวอร์ไม่ตรง)"
            }
            props.setProperty("key", key)
            props.setProperty("token", token)
            props.setProperty("lastOk", System.currentTimeMillis().toString())
            save()
            return null
        }
        if (ok == false) {
            props.remove("token")
            save()
            return LicenseCore.jsonString(r, "message") ?: "คีย์ใช้ไม่ได้"
        }
        return if (quietOffline) null else "เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ"
    }
}
