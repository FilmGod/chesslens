package com.chesslens.pc

import java.io.File
import java.util.Properties

/** Small persistent settings in ~/.chesslens. */
class PcSettings {
    val dir = File(System.getProperty("user.home"), ".chesslens").also { it.mkdirs() }
    val templatesFile = File(dir, "templates.bin")
    private val file = File(dir, "settings.properties")
    private val props = Properties()

    init {
        try { file.inputStream().use { props.load(it) } } catch (e: Exception) { }
    }

    private fun save() {
        try { file.outputStream().use { props.store(it, "ChessLens") } } catch (e: Exception) { }
    }

    var evalBar: Boolean
        get() = props.getProperty("evalBar", "true") == "true"
        set(v) { props.setProperty("evalBar", v.toString()); save() }

    var multiLines: Boolean
        get() = props.getProperty("multiLines", "false") == "true"
        set(v) { props.setProperty("multiLines", v.toString()); save() }

    /** 0 = full strength, otherwise 1350..2800. */
    var elo: Int
        get() = props.getProperty("elo", "0").toIntOrNull() ?: 0
        set(v) { props.setProperty("elo", v.toString()); save() }

    var enginePath: String
        get() = props.getProperty("enginePath", "")
        set(v) { props.setProperty("enginePath", v); save() }

    var screenIndex: Int
        get() = props.getProperty("screen", "0").toIntOrNull() ?: 0
        set(v) { props.setProperty("screen", v.toString()); save() }

    var bottomWhite: Boolean
        get() = props.getProperty("bottomWhite", "true") == "true"
        set(v) { props.setProperty("bottomWhite", v.toString()); save() }

    /** Saved board frame for a given screen size, or null when it was saved for another size. */
    fun frame(sw: Int, sh: Int): java.awt.Rectangle? {
        val v = props.getProperty("frame", "").split(",").mapNotNull { it.toIntOrNull() }
        if (v.size != 6 || v[4] != sw || v[5] != sh) return null
        return java.awt.Rectangle(v[0], v[1], v[2], v[3])
    }

    fun setFrame(sw: Int, sh: Int, r: java.awt.Rectangle) {
        props.setProperty("frame", "${r.x},${r.y},${r.width},${r.height},$sw,$sh")
        save()
    }
}
