package com.chesslens.pc

import com.sun.jna.Native
import com.sun.jna.platform.win32.User32
import com.sun.jna.platform.win32.WinDef
import java.awt.Window

/** Makes a window ignore the mouse so clicks reach the game underneath (Windows only). */
object ClickThrough {
    val isWindows = System.getProperty("os.name", "").lowercase().contains("win")

    fun apply(w: Window): Boolean {
        if (!isWindows) return false
        return try {
            val hwnd = WinDef.HWND(Native.getComponentPointer(w))
            val gwlExStyle = -20
            val layered = 0x00080000
            val transparent = 0x00000020
            val toolWindow = 0x00000080
            val noActivate = 0x08000000
            val cur = User32.INSTANCE.GetWindowLong(hwnd, gwlExStyle)
            User32.INSTANCE.SetWindowLong(hwnd, gwlExStyle, cur or layered or transparent or toolWindow or noActivate)
            true
        } catch (e: Throwable) {
            false
        }
    }
}
