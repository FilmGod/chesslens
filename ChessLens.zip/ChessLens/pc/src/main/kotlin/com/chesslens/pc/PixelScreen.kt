package com.chesslens.pc

import com.chesslens.core.BoardFinder
import com.chesslens.core.BoardImage
import com.chesslens.core.FoundBoard
import com.chesslens.core.Signature
import java.awt.Rectangle

/**
 * The newest picture of the screen. [captureFull] grabs everything (needed to look for the board);
 * [captureRegion] grabs just the board area, which is much cheaper and is what the 10-times-a-second loop uses.
 * Coordinates are always full-screen coordinates.
 */
abstract class PixelScreen {
    var width = 0
        protected set
    var height = 0
        protected set
    protected var pixels = IntArray(0)
    protected var ox = 0
    protected var oy = 0
    protected var pw = 0
    protected var ph = 0

    abstract fun captureFull(): Boolean
    abstract fun captureRegion(r: Rectangle): Boolean

    protected fun set(w: Int, h: Int, data: IntArray, originX: Int, originY: Int, screenW: Int, screenH: Int) {
        pixels = data
        pw = w
        ph = h
        ox = originX
        oy = originY
        width = screenW
        height = screenH
    }

    fun px(x: Int, y: Int): Int {
        if (pw == 0) return 0
        val lx = (x - ox).coerceIn(0, pw - 1)
        val ly = (y - oy).coerceIn(0, ph - 1)
        return pixels[ly * pw + lx] and 0xFFFFFF
    }

    fun findBoard(): FoundBoard? = if (ox == 0 && oy == 0 && pw == width && ph == height)
        BoardFinder.find(width, height) { x, y -> px(x, y) } else null

    /** False only when the area has clearly stopped looking like a chess board. */
    fun verifyBoard(r: Rectangle): Boolean = BoardFinder.verify(r.x, r.y, r.width, width, height) { x, y -> px(x, y) }

    /** A frame a fraction of a square off the real board: the better frame, or null. Needs a full capture. */
    fun alignBoard(r: Rectangle): FoundBoard? = if (ox == 0 && oy == 0 && pw == width && ph == height)
        BoardFinder.align(r.x, r.y, r.width, width, height) { x, y -> px(x, y) } else null

    fun signature(r: Rectangle): IntArray = Signature.sample(r.width, r.height) { x, y -> px(r.x + x, r.y + y) }

    /** The board area as a picture of at most 512 x 512 pixels. */
    fun grabBoard(r: Rectangle): BoardImage {
        val s = minOf(512, r.width, r.height)
        val sx = r.width.toDouble() / s
        val sy = r.height.toDouble() / s
        val out = IntArray(s * s)
        for (oy2 in 0 until s) for (ox2 in 0 until s) {
            var rr = 0
            var g = 0
            var b = 0
            for (k in 0 until 4) {
                val fx = (ox2 + 0.25 + 0.5 * (k and 1)) * sx
                val fy = (oy2 + 0.25 + 0.5 * (k shr 1)) * sy
                val c = px(r.x + fx.toInt(), r.y + fy.toInt())
                rr += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
            }
            out[oy2 * s + ox2] = (0xFF shl 24) or ((rr / 4) shl 16) or ((g / 4) shl 8) or (b / 4)
        }
        return BoardImage(s, s, out)
    }
}
