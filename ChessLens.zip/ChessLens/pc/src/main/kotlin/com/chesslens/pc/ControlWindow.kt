package com.chesslens.pc

import com.chesslens.core.LicenseCore
import java.awt.BorderLayout
import java.awt.Color
import java.awt.Dimension
import java.awt.GraphicsEnvironment
import java.awt.GridLayout
import javax.swing.BorderFactory
import javax.swing.Box
import javax.swing.BoxLayout
import javax.swing.JFrame
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.JScrollPane
import javax.swing.JSlider
import javax.swing.JTextArea
import javax.swing.JTextField
import javax.swing.SwingUtilities
import javax.swing.Timer

/** The small always-on-top control panel (custom-painted so it looks the same on every Windows theme). */
class ControlWindow(private val c: Controller) {
    private val frame = JFrame("ChessLens")
    private val header = HeaderBar()
    private val statusArea = JTextArea("พร้อม", 6, 30)
    private val startBtn = FlatButton("เริ่ม", true)
    private val autoBtn = FlatButton("ออโต้: ปิด")
    private val keyField = JTextField()
    private val keyInfo = JLabel(" ")
    private val keyCard = CardPanel()
    private val eloLabel = JLabel()

    private fun label(t: String, dim: Boolean = false) = JLabel(t).apply {
        foreground = if (dim) Theme.dim else Theme.text
        font = Theme.font(if (dim) 12f else 13f)
        alignmentX = 0f
    }

    private fun row(vararg comps: java.awt.Component): JPanel {
        val p = JPanel(GridLayout(1, comps.size, 8, 0))
        p.isOpaque = false
        comps.forEach { p.add(it) }
        p.alignmentX = 0f
        p.maximumSize = Dimension(Int.MAX_VALUE, 36)
        return p
    }

    private fun card(): CardPanel {
        val p = CardPanel()
        p.layout = BoxLayout(p, BoxLayout.Y_AXIS)
        p.border = BorderFactory.createEmptyBorder(12, 14, 12, 14)
        p.alignmentX = 0f
        return p
    }

    init {
        frame.defaultCloseOperation = JFrame.DO_NOTHING_ON_CLOSE
        frame.isAlwaysOnTop = true
        frame.isAutoRequestFocus = false
        val root = BackgroundPanel()
        root.layout = BorderLayout()

        // status
        statusArea.isEditable = false
        statusArea.lineWrap = true
        statusArea.wrapStyleWord = true
        statusArea.isOpaque = false
        statusArea.foreground = Theme.text
        statusArea.font = Theme.font(14f)
        statusArea.border = null
        val sp = JScrollPane(statusArea)
        sp.border = null
        sp.isOpaque = false
        sp.viewport.isOpaque = false
        sp.verticalScrollBar.unitIncrement = 12
        val statusCard = CardPanel()
        statusCard.layout = BorderLayout()
        statusCard.border = BorderFactory.createEmptyBorder(10, 12, 10, 12)
        statusCard.add(sp, BorderLayout.CENTER)
        statusCard.preferredSize = Dimension(380, 150)

        val body = JPanel()
        body.layout = BoxLayout(body, BoxLayout.Y_AXIS)
        body.isOpaque = false
        body.border = BorderFactory.createEmptyBorder(12, 12, 12, 12)
        statusCard.alignmentX = 0f
        body.add(statusCard)
        body.add(Box.createVerticalStrut(10))

        // key
        keyCard.layout = BoxLayout(keyCard, BoxLayout.Y_AXIS)
        keyCard.border = BorderFactory.createEmptyBorder(10, 14, 10, 14)
        keyCard.alignmentX = 0f
        keyCard.add(label("คีย์เปิดใช้งาน", true))
        keyCard.add(Box.createVerticalStrut(4))
        keyField.alignmentX = 0f
        keyField.maximumSize = Dimension(Int.MAX_VALUE, 30)
        keyField.background = Color(14, 17, 23)
        keyField.foreground = Theme.text
        keyField.caretColor = Theme.accent
        keyField.font = Theme.font(14f)
        keyField.border = BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.cardLine), BorderFactory.createEmptyBorder(4, 8, 4, 8)
        )
        keyCard.add(keyField)
        keyCard.add(Box.createVerticalStrut(6))
        val actBtn = FlatButton("เปิดใช้งานคีย์")
        actBtn.alignmentX = 0f
        actBtn.maximumSize = Dimension(Int.MAX_VALUE, 34)
        keyCard.add(actBtn)
        keyInfo.foreground = Theme.accent
        keyInfo.font = Theme.font(12f, true)
        keyInfo.alignmentX = 0f
        keyCard.add(Box.createVerticalStrut(4))
        keyCard.add(keyInfo)
        body.add(keyCard)
        body.add(Box.createVerticalStrut(10))

        // buttons
        val frameBtn = FlatButton("ตั้งกรอบ")
        val learnBtn = FlatButton("เรียนรู้")
        val sideBtn = FlatButton("สลับฝั่ง")
        val turnBtn = FlatButton("สลับตา")
        val playBtn = FlatButton("เดินให้")
        val screenBtn = FlatButton("สลับจอ")
        val quitBtn = FlatButton("ออก").apply { danger = true }
        val btns = card()
        btns.add(row(startBtn, frameBtn, learnBtn))
        btns.add(Box.createVerticalStrut(8))
        btns.add(row(sideBtn, turnBtn))
        btns.add(Box.createVerticalStrut(8))
        btns.add(row(playBtn, autoBtn))
        body.add(btns)
        body.add(Box.createVerticalStrut(10))

        // options
        val opts = card()
        val evalSw = SwitchBox("แถบประเมิน", c.settings.evalBar)
        val multiSw = SwitchBox("แสดง 3 ตาเดินที่ดีที่สุด", c.settings.multiLines)
        evalSw.alignmentX = 0f
        multiSw.alignmentX = 0f
        evalSw.onChange { c.settings.evalBar = evalSw.isSelected; c.optionsChanged() }
        multiSw.onChange { c.settings.multiLines = multiSw.isSelected; c.optionsChanged() }
        opts.add(evalSw)
        opts.add(multiSw)
        opts.add(Box.createVerticalStrut(6))
        eloLabel.foreground = Theme.text
        eloLabel.font = Theme.font(13f)
        eloLabel.alignmentX = 0f
        val slider = JSlider(0, 30, eloToIndex(c.settings.elo))
        slider.isOpaque = false
        slider.setUI(SliderUi(slider))
        slider.alignmentX = 0f
        fun updateElo() { eloLabel.text = "ระดับเอนจิน: " + if (slider.value >= 30) "เต็มแรง" else (1350 + slider.value * 50).toString() }
        updateElo()
        slider.addChangeListener {
            updateElo()
            if (!slider.valueIsAdjusting) {
                c.settings.elo = if (slider.value >= 30) 0 else 1350 + slider.value * 50
                c.optionsChanged()
            }
        }
        opts.add(eloLabel)
        opts.add(slider)
        opts.add(Box.createVerticalStrut(8))
        opts.add(row(screenBtn, quitBtn))
        body.add(opts)
        body.add(Box.createVerticalStrut(8))
        val credit = JLabel("LICENSE  ·  Made by FilmXr01")
        credit.foreground = Color(205, 180, 255)
        credit.font = Theme.font(12f, true)
        credit.alignmentX = 0f
        body.add(credit)

        root.add(header, BorderLayout.NORTH)
        root.add(body, BorderLayout.CENTER)
        frame.contentPane = root
        frame.pack()
        frame.minimumSize = frame.size
        val b = GraphicsEnvironment.getLocalGraphicsEnvironment().defaultScreenDevice.defaultConfiguration.bounds
        frame.setLocation(b.x + b.width - frame.width - 20, b.y + 60)

        startBtn.addActionListener {
            if (c.isRunning) c.stop() else if (licenseOk()) { startBtn.isEnabled = false; c.start() }
        }
        frameBtn.addActionListener {
            val devs = GraphicsEnvironment.getLocalGraphicsEnvironment().screenDevices
            val dev = devs[c.settings.screenIndex.coerceIn(0, devs.size - 1)]
            frame.isVisible = false
            Timer(250) {
                FrameSelector.select(dev) { r ->
                    frame.isVisible = true
                    if (r != null && c.isRunning) c.setManualFrame(r)
                    else if (r != null) {
                        c.settings.setFrame(dev.defaultConfiguration.bounds.width, dev.defaultConfiguration.bounds.height, r)
                        setStatus("บันทึกกรอบแล้ว กด 'เริ่ม'")
                    }
                }
            }.apply { isRepeats = false; start() }
        }
        learnBtn.addActionListener { if (c.isRunning) c.learn() }
        sideBtn.addActionListener { if (c.isRunning) c.flipSide() }
        turnBtn.addActionListener { if (c.isRunning) c.flipTurn() }
        playBtn.addActionListener { if (c.isRunning) c.playOnce() }
        autoBtn.addActionListener { if (c.isRunning) c.toggleAuto() }
        screenBtn.addActionListener {
            c.cycleScreen()
            setStatus("เลือกจอที่ ${c.settings.screenIndex + 1}")
        }
        quitBtn.addActionListener { c.shutdown(); Timer(700) { System.exit(0) }.apply { isRepeats = false; start() } }
        actBtn.addActionListener {
            val k = keyField.text.trim()
            if (k.isEmpty()) { keyInfo.text = "ใส่คีย์ก่อน"; return@addActionListener }
            actBtn.isEnabled = false
            keyInfo.text = "กำลังตรวจสอบ…"
            Thread {
                val err = c.license.activate(k)
                SwingUtilities.invokeLater {
                    actBtn.isEnabled = true
                    keyInfo.text = err ?: "เปิดใช้งานสำเร็จ"
                    refreshLicense()
                }
            }.start()
        }
        frame.addWindowListener(object : java.awt.event.WindowAdapter() {
            override fun windowClosing(e: java.awt.event.WindowEvent) { quitBtn.doClick() }
        })

        c.onStatus = { t -> setStatus(t) }
        c.onAutoChanged = { on -> SwingUtilities.invokeLater { autoBtn.text = if (on) "ออโต้: เปิด" else "ออโต้: ปิด" } }
        c.onStopped = { why ->
            SwingUtilities.invokeLater {
                startBtn.text = "เริ่ม"
                startBtn.isEnabled = true
                header.running = false
                if (why.isNotEmpty()) statusArea.text = why
                refreshLicense()
            }
        }
        c.windowBounds = { if (frame.isVisible) frame.bounds else null }
        c.hideWindowFor = { _, hide ->
            try {
                if (hide) SwingUtilities.invokeAndWait { frame.isVisible = false }
                else SwingUtilities.invokeLater { frame.isVisible = true }
            } catch (e: Exception) { }
        }
        refreshLicense()
    }

    private fun eloToIndex(elo: Int) = if (elo <= 0) 30 else ((elo - 1350) / 50).coerceIn(0, 29)

    private fun licenseOk(): Boolean {
        val st = c.license.status().state
        if (st == LicenseCore.State.VALID) return true
        setStatus("ต้องเปิดใช้งานคีย์ก่อน")
        return false
    }

    private fun refreshLicense() {
        keyCard.isVisible = c.license.required
        if (c.license.required) {
            val s = c.license.status()
            if (s.state == LicenseCore.State.VALID) keyInfo.text = "คีย์ใช้งานได้ เหลือ ${s.daysLeft} วัน"
            else if (keyInfo.text.isBlank()) keyInfo.text = "ยังไม่ได้เปิดใช้งาน / คีย์หมดอายุ"
            if (c.license.savedKey.isNotEmpty() && keyField.text.isEmpty()) keyField.text = c.license.savedKey
        }
        frame.pack()
    }

    fun setStatus(t: String) {
        SwingUtilities.invokeLater {
            statusArea.text = t
            statusArea.caretPosition = 0
            if (c.isRunning) startBtn.text = "หยุด"
            header.running = c.isRunning
            startBtn.isEnabled = true
        }
    }

    fun show() {
        SwingUtilities.invokeLater { frame.isVisible = true }
    }
}
