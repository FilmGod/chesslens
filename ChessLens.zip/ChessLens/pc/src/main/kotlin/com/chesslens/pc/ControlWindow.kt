package com.chesslens.pc

import com.chesslens.core.LicenseCore
import java.awt.BorderLayout
import java.awt.Color
import java.awt.Dimension
import java.awt.Font
import java.awt.GraphicsEnvironment
import java.awt.GridLayout
import java.awt.Rectangle
import javax.swing.BorderFactory
import javax.swing.BoxLayout
import javax.swing.JButton
import javax.swing.JCheckBox
import javax.swing.JFrame
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.JScrollPane
import javax.swing.JSlider
import javax.swing.JTextArea
import javax.swing.JTextField
import javax.swing.SwingUtilities
import javax.swing.Timer

/** The small always-on-top control panel. */
class ControlWindow(private val c: Controller) {
    private val bg = Color(18, 22, 28)
    private val fg = Color(232, 236, 240)
    private val accent = Color(52, 226, 168)
    private val frame = JFrame("ChessLens")
    private val statusArea = JTextArea("พร้อม", 7, 30)
    private val startBtn = button("เริ่ม")
    private val autoBtn = button("ออโต้: ปิด")
    private val keyField = JTextField()
    private val keyInfo = JLabel(" ")
    private val keyPanel = JPanel()
    private val controls = JPanel()
    private val eloLabel = JLabel()

    private fun button(t: String) = JButton(t).apply {
        background = Color(36, 42, 52); foreground = fg; isFocusPainted = false
        border = BorderFactory.createEmptyBorder(7, 10, 7, 10)
    }

    private fun label(t: String) = JLabel(t).apply { foreground = fg }

    init {
        frame.defaultCloseOperation = JFrame.DO_NOTHING_ON_CLOSE
        frame.isAlwaysOnTop = true
        frame.isAutoRequestFocus = false
        val root = JPanel(BorderLayout(0, 8))
        root.background = bg
        root.border = BorderFactory.createEmptyBorder(10, 10, 10, 10)

        statusArea.isEditable = false
        statusArea.lineWrap = true
        statusArea.wrapStyleWord = true
        statusArea.background = Color(26, 31, 39)
        statusArea.foreground = fg
        statusArea.font = Font("Tahoma", Font.PLAIN, 13)
        val sp = JScrollPane(statusArea)
        sp.border = BorderFactory.createLineBorder(Color(48, 56, 68))
        sp.preferredSize = Dimension(360, 150)
        root.add(sp, BorderLayout.NORTH)

        controls.layout = BoxLayout(controls, BoxLayout.Y_AXIS)
        controls.background = bg
        fun row(vararg comps: java.awt.Component): JPanel {
            val p = JPanel(GridLayout(1, comps.size, 6, 0))
            p.background = bg
            comps.forEach { p.add(it) }
            p.alignmentX = 0f
            p.maximumSize = Dimension(Int.MAX_VALUE, 38)
            return p
        }
        val frameBtn = button("ตั้งกรอบ")
        val learnBtn = button("เรียนรู้")
        val sideBtn = button("สลับฝั่ง")
        val turnBtn = button("สลับตา")
        val playBtn = button("เดินให้")
        val screenBtn = button("สลับจอ")
        val quitBtn = button("ออก")
        controls.add(row(startBtn, frameBtn, learnBtn))
        controls.add(javax.swing.Box.createVerticalStrut(6))
        controls.add(row(sideBtn, turnBtn))
        controls.add(javax.swing.Box.createVerticalStrut(6))
        controls.add(row(playBtn, autoBtn))
        controls.add(javax.swing.Box.createVerticalStrut(8))

        val evalCb = JCheckBox("แถบประเมิน", c.settings.evalBar).apply { background = bg; foreground = fg; alignmentX = 0f }
        val multiCb = JCheckBox("แสดง 3 ตาเดินที่ดีที่สุด", c.settings.multiLines).apply { background = bg; foreground = fg; alignmentX = 0f }
        evalCb.addActionListener { c.settings.evalBar = evalCb.isSelected; c.optionsChanged() }
        multiCb.addActionListener { c.settings.multiLines = multiCb.isSelected; c.optionsChanged() }
        controls.add(evalCb)
        controls.add(multiCb)

        eloLabel.foreground = fg
        eloLabel.alignmentX = 0f
        val slider = JSlider(0, 30, eloToIndex(c.settings.elo))
        slider.background = bg
        slider.alignmentX = 0f
        fun updateElo() { eloLabel.text = "ระดับเอนจิน: " + if (slider.value >= 30) "เต็มแรง" else (1350 + slider.value * 50).toString() }
        updateElo()
        slider.addChangeListener {
            updateElo()
            if (!slider.valueIsAdjusting) {
                c.settings.elo = if (slider.value >= 30) 0 else 1350 + slider.value * 50
                c.optionsChanged()
            }
        }
        controls.add(eloLabel)
        controls.add(slider)
        controls.add(javax.swing.Box.createVerticalStrut(6))
        controls.add(row(screenBtn, quitBtn))

        keyPanel.layout = BoxLayout(keyPanel, BoxLayout.Y_AXIS)
        keyPanel.background = bg
        keyPanel.add(label("คีย์เปิดใช้งาน").apply { alignmentX = 0f })
        keyField.alignmentX = 0f
        keyField.maximumSize = Dimension(Int.MAX_VALUE, 30)
        keyPanel.add(keyField)
        val actBtn = button("เปิดใช้งานคีย์")
        actBtn.alignmentX = 0f
        keyPanel.add(javax.swing.Box.createVerticalStrut(4))
        keyPanel.add(actBtn)
        keyInfo.foreground = accent
        keyInfo.alignmentX = 0f
        keyPanel.add(keyInfo)
        keyPanel.border = BorderFactory.createEmptyBorder(0, 0, 8, 0)

        val south = JPanel(BorderLayout())
        south.background = bg
        south.add(keyPanel, BorderLayout.NORTH)
        south.add(controls, BorderLayout.CENTER)
        root.add(south, BorderLayout.CENTER)
        frame.contentPane = root
        frame.pack()
        frame.minimumSize = frame.size
        val b = GraphicsEnvironment.getLocalGraphicsEnvironment().defaultScreenDevice.defaultConfiguration.bounds
        frame.setLocation(b.x + b.width - frame.width - 20, b.y + 60)

        startBtn.addActionListener {
            if (c.isRunning) c.stop() else if (licenseOk()) { startBtn.isEnabled = false; c.start() }
        }
        frameBtn.addActionListener {
            val devs = GraphicsEnvironment.getLocalGraphicsEnvironment().screenDevices
            val dev = devs[c.settings.screenIndex.coerceIn(0, devs.size - 1)]
            frame.isVisible = false
            Timer(250) {
                FrameSelector.select(dev) { r ->
                    frame.isVisible = true
                    if (r != null && c.isRunning) c.setManualFrame(r)
                    else if (r != null) {
                        c.settings.setFrame(dev.defaultConfiguration.bounds.width, dev.defaultConfiguration.bounds.height, r)
                        setStatus("บันทึกกรอบแล้ว กด 'เริ่ม'")
                    }
                }
            }.apply { isRepeats = false; start() }
        }
        learnBtn.addActionListener { if (c.isRunning) c.learn() }
        sideBtn.addActionListener { if (c.isRunning) c.flipSide() }
        turnBtn.addActionListener { if (c.isRunning) c.flipTurn() }
        playBtn.addActionListener { if (c.isRunning) c.playOnce() }
        autoBtn.addActionListener { if (c.isRunning) c.toggleAuto() }
        screenBtn.addActionListener {
            c.cycleScreen()
            setStatus("เลือกจอที่ ${c.settings.screenIndex + 1}")
        }
        quitBtn.addActionListener { c.shutdown(); Timer(700) { System.exit(0) }.apply { isRepeats = false; start() } }
        actBtn.addActionListener {
            val k = keyField.text.trim()
            if (k.isEmpty()) { keyInfo.text = "ใส่คีย์ก่อน"; return@addActionListener }
            actBtn.isEnabled = false
            keyInfo.text = "กำลังตรวจสอบ…"
            Thread {
                val err = c.license.activate(k)
                SwingUtilities.invokeLater {
                    actBtn.isEnabled = true
                    keyInfo.text = err ?: "เปิดใช้งานสำเร็จ"
                    refreshLicense()
                }
            }.start()
        }
        frame.addWindowListener(object : java.awt.event.WindowAdapter() {
            override fun windowClosing(e: java.awt.event.WindowEvent) { quitBtn.doClick() }
        })

        c.onStatus = { t -> setStatus(t) }
        c.onAutoChanged = { on -> SwingUtilities.invokeLater { autoBtn.text = if (on) "ออโต้: เปิด" else "ออโต้: ปิด" } }
        c.onStopped = { why ->
            SwingUtilities.invokeLater {
                startBtn.text = "เริ่ม"
                startBtn.isEnabled = true
                if (why.isNotEmpty()) statusArea.text = why
                refreshLicense()
            }
        }
        c.windowBounds = { if (frame.isVisible) frame.bounds else null }
        c.hideWindowFor = { _, hide ->
            try {
                if (hide) SwingUtilities.invokeAndWait { frame.isVisible = false }
                else SwingUtilities.invokeLater { frame.isVisible = true }
            } catch (e: Exception) { }
        }
        refreshLicense()
    }

    private fun eloToIndex(elo: Int) = if (elo <= 0) 30 else ((elo - 1350) / 50).coerceIn(0, 29)

    private fun licenseOk(): Boolean {
        val st = c.license.status().state
        if (st == LicenseCore.State.VALID) return true
        setStatus("ต้องเปิดใช้งานคีย์ก่อน")
        return false
    }

    private fun refreshLicense() {
        keyPanel.isVisible = c.license.required
        if (c.license.required) {
            val s = c.license.status()
            if (s.state == LicenseCore.State.VALID && keyInfo.text.trim().isEmpty() || s.state == LicenseCore.State.VALID) {
                keyInfo.text = "คีย์ใช้งานได้ เหลือ ${s.daysLeft} วัน"
            } else if (keyInfo.text.isBlank()) {
                keyInfo.text = "ยังไม่ได้เปิดใช้งาน / คีย์หมดอายุ"
            }
            if (c.license.savedKey.isNotEmpty() && keyField.text.isEmpty()) keyField.text = c.license.savedKey
        }
        frame.pack()
    }

    fun setStatus(t: String) {
        SwingUtilities.invokeLater {
            statusArea.text = t
            statusArea.caretPosition = 0
            if (c.isRunning) startBtn.text = "หยุด"
            startBtn.isEnabled = true
        }
    }

    fun show() {
        SwingUtilities.invokeLater { frame.isVisible = true }
    }
}
