package com.chesslens.pc

import com.chesslens.core.BoardGeometry
import com.chesslens.core.BoardReader
import com.chesslens.core.BuiltinEngine
import com.chesslens.core.LicenseCore
import com.chesslens.core.MoveAdvisor
import com.chesslens.core.MoveText
import com.chesslens.core.Moves
import com.chesslens.core.Piece
import com.chesslens.core.Position
import com.chesslens.core.PositionTracker
import com.chesslens.core.ReadResult
import com.chesslens.core.Signature
import com.chesslens.core.UciEngine
import java.awt.GraphicsEnvironment
import java.awt.Point
import java.awt.Rectangle
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** The PC counterpart of the phone's CaptureService: finds the board, reads it, tracks the game and shows the best move. */
class Controller(
    val settings: PcSettings,
    val license: PcLicense,
    private val screenFactory: (Int) -> PixelScreen = { RobotScreen(GraphicsEnvironment.getLocalGraphicsEnvironment().screenDevices[it.coerceIn(0, GraphicsEnvironment.getLocalGraphicsEnvironment().screenDevices.size - 1)]) },
    private val overlayFactory: ((Int) -> OverlayWindow?)? = null
) {
    companion object {
        private const val TICK_MS = 100L
        private const val QUICK_MS = 120L
        private const val CHANGE_THR = 10
    }

    class Advice(
        val from: Int, val to: Int, val text: String, val move: Int = 0,
        val others: List<IntArray> = emptyList(), val evalFrac: Float = 0.5f, val evalText: String = ""
    )

    // ---- hooks the UI sets ----
    @Volatile var onStatus: (String) -> Unit = {}
    @Volatile var onAutoChanged: (Boolean) -> Unit = {}
    @Volatile var onStopped: (String) -> Unit = {}
    /** Called around a board read so the control window can step out of the way if it covers the board. */
    @Volatile var hideWindowFor: (Rectangle?, Boolean) -> Unit = { _, _ -> }
    @Volatile var windowBounds: () -> Rectangle? = { null }

    private val work = ScheduledThreadPoolExecutor(1) { r -> Thread(r, "chesslens-work").apply { isDaemon = true } }
    private val analysisPool = Executors.newSingleThreadExecutor { r ->
        Thread(r, "chesslens-engine").apply { isDaemon = true; priority = Thread.MAX_PRIORITY }
    }

    private var screen: PixelScreen? = null
    private var overlay: OverlayWindow? = null
    private var robot: RobotScreen? = null
    private val reader = BoardReader()
    private val tracker = PositionTracker()
    private var engine: MoveAdvisor? = null
    private var engineTimeMs = 1000L
    @Volatile var frame: Rectangle? = null
        private set
    private var lastSig: IntArray? = null
    private var ignore: BooleanArray? = null
    private var accepted: IntArray? = null
    private var pending: IntArray? = null
    private var forceRead = false
    private var failCount = 0
    private var notBefore = 0L
    private var advice: Advice? = null
    @Volatile var autoMode = false
        private set
    private var autoArmUntil = 0L
    private var moving = false
    @Volatile private var generation = 0
    @Volatile private var running = false
    @Volatile var bottomWhite = true
        private set
    private val userColor: Int get() = if (bottomWhite) Piece.WHITE else Piece.BLACK
    private var verifyFails = 0
    private var tickCount = 0
    private var nextFindAt = 0L
    private var nextLearnAt = 0L
    private var licenseChecks = 0
    private var tickTask: java.util.concurrent.ScheduledFuture<*>? = null

    val isRunning: Boolean get() = running
    val engineName: String get() = engine?.name ?: "-"

    private fun status(t: String) = onStatus(t)

    // ------------------------------------------------------------ start / stop

    fun start() {
        if (running) return
        work.execute {
            try {
                val idx = settings.screenIndex
                val s = screenFactory(idx)
                screen = s
                robot = s as? RobotScreen
                overlay = overlayFactory?.invoke(idx) ?: (s as? RobotScreen)?.let {
                    val devs = GraphicsEnvironment.getLocalGraphicsEnvironment().screenDevices
                    OverlayWindow(devs[idx.coerceIn(0, devs.size - 1)])
                }
                overlay?.show()
                if (settings.templatesFile.exists()) {
                    try { settings.templatesFile.inputStream().use { reader.load(it) } } catch (e: Exception) { }
                }
                bottomWhite = settings.bottomWhite
                s.captureFull()
                frame = settings.frame(s.width, s.height)
                status("กำลังเตรียมเอนจิน…")
                startEngine()
                resetState()
                running = true
                status(guideText())
                scheduleTicks()
            } catch (e: Throwable) {
                status("เริ่มระบบไม่สำเร็จ: ${e.javaClass.simpleName} ${e.message ?: ""}")
                onStopped("")
            }
        }
    }

    fun stop(why: String = "") {
        work.execute {
            running = false
            autoMode = false
            onAutoChanged(false)
            generation++
            tickTask?.cancel(false)
            tickTask = null
            overlay?.dispose()
            overlay = null
            try { engine?.close() } catch (e: Exception) { }
            engine = null
            screen = null
            onStopped(why)
        }
    }

    fun shutdown() {
        stop()
        work.schedule({ work.shutdown() }, 500, TimeUnit.MILLISECONDS)
    }

    private fun resetState() {
        lastSig = null; accepted = null; pending = null; advice = null; ignore = null
        forceRead = false; failCount = 0; notBefore = 0; tracker.reset()
    }

    private fun scheduleTicks() {
        tickTask?.cancel(false)
        tickTask = work.scheduleWithFixedDelay({ tick() }, 400, TICK_MS, TimeUnit.MILLISECONDS)
    }

    private fun appDir(): File? = try {
        File(Controller::class.java.protectionDomain.codeSource.location.toURI()).parentFile
    } catch (e: Exception) { null }

    private fun findStockfish(): File? {
        val names = listOf("stockfish.exe", "stockfish", "stockfish-windows-x86-64-avx2.exe", "stockfish-windows-x86-64.exe")
        val dirs = listOfNotNull(appDir(), appDir()?.parentFile, File(System.getProperty("user.dir", ".")), settings.dir)
        val explicit = settings.enginePath.trim()
        if (explicit.isNotEmpty() && File(explicit).isFile) return File(explicit)
        for (d in dirs) for (n in names) {
            val f = File(d, n)
            if (f.isFile) return f
        }
        // any stockfish*.exe in the app folder
        for (d in dirs) d.listFiles { f -> f.isFile && f.name.lowercase().startsWith("stockfish") && !f.name.lowercase().endsWith(".txt") }?.firstOrNull()?.let { return it }
        return null
    }

    private fun startEngine() {
        val f = findStockfish()
        if (f != null) {
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 8)
            val uci = UciEngine(f.absolutePath, threads, 256)
            if (uci.start()) {
                engine = uci
                engineTimeMs = 700
                return
            }
        }
        engine = BuiltinEngine()
        engineTimeMs = 800
    }

    private fun guideText(): String = when {
        frame == null -> "กำลังหากระดานบนหน้าจอ… เปิดหน้าเกมหมากรุกให้เห็นกระดาน (หรือกด 'ตั้งกรอบ' เอง)"
        !reader.isReady -> "เจอกระดานแล้ว — เปิดเกมใหม่ให้เห็นตำแหน่งเริ่มต้น แอปจะเรียนรู้และรู้ฝั่งเองอัตโนมัติ"
        else -> "พร้อมแล้ว — เล่นได้เลย (คุณเล่น${if (bottomWhite) "ขาว" else "ดำ"})"
    }

    // ------------------------------------------------------------ loop

    private fun tick() {
        if (!running) return
        try {
            checkLicense()
            val s = screen ?: return
            step(s)
        } catch (e: Throwable) {
            status("เกิดข้อผิดพลาด: ${e.javaClass.simpleName} ${e.message ?: ""}")
        }
    }

    private fun checkLicense() {
        licenseChecks++
        if (licenseChecks % 18000 == 0) Thread { license.refresh() }.start()
        if (licenseChecks % 600 == 0 && license.status().state != LicenseCore.State.VALID) {
            stop("คีย์หมดอายุหรือถูกยกเลิก หยุดการทำงาน")
        }
    }

    private fun step(s: PixelScreen) {
        tickCount++
        val rect = frame
        if (rect == null) {
            autoFindBoard(s)
            return
        }
        if (!s.captureRegion(rect)) return
        if (tickCount % 20 == 0) checkFrameStillBoard(s, rect)
        if (frame == null) return
        if (!reader.isReady) {
            autoLearn(s, rect)
            return
        }
        if (System.currentTimeMillis() < notBefore) return
        val sig = s.signature(rect)
        val prev = lastSig
        val changed = forceRead || prev == null || Signature.changed(prev, sig, ignore, CHANGE_THR)
        if (!changed) return
        forceRead = false
        onBoardChanged(s, rect, sig)
    }

    private fun autoFindBoard(s: PixelScreen) {
        val now = System.currentTimeMillis()
        if (now < nextFindAt) return
        nextFindAt = now + 1500
        if (!s.captureFull()) return
        val fb = s.findBoard()
        if (fb == null) {
            status(guideText())
            return
        }
        verifyFails = 0
        applyFrame(Rectangle(fb.x, fb.y, fb.size, fb.size), auto = true)
    }

    private fun refindFrame(s: PixelScreen, rect: Rectangle): Boolean {
        if (!s.captureFull()) return false
        val fb = s.findBoard() ?: return false
        val moved = Math.abs(fb.x - rect.x) > fb.size / 80 || Math.abs(fb.y - rect.y) > fb.size / 80 ||
            Math.abs(fb.size - rect.width) > fb.size / 80
        if (!moved) return false
        applyFrame(Rectangle(fb.x, fb.y, fb.size, fb.size), auto = true)
        return true
    }

    private fun checkFrameStillBoard(s: PixelScreen, rect: Rectangle) {
        if (s.verifyBoard(rect)) { verifyFails = 0; return }
        verifyFails++
        if (verifyFails < 3) return
        verifyFails = 0
        refindFrame(s, rect)
    }

    private fun autoLearn(s: PixelScreen, rect: Rectangle) {
        val now = System.currentTimeMillis()
        if (now < nextLearnAt) return
        nextLearnAt = now + 1000
        val img = s.grabBoard(rect)
        if (reader.detectBottomWhite(img) == null) return
        doLearnNow()
    }

    private fun onBoardChanged(s: PixelScreen, rect: Rectangle, sig: IntArray) {
        generation++
        ignore = null
        showArrow(null)
        Thread.sleep(90)
        if (!s.captureRegion(rect)) return
        val sig2 = s.signature(rect)
        if (Signature.changed(sig, sig2, null, CHANGE_THR)) {
            lastSig = sig2
            forceRead = true
            return
        }
        lastSig = sig2
        val img = cleanCapture(s, rect)
        var res = reader.read(img, bottomWhite, tracker.pos?.board ?: Position.startBoard())
        if (!res.ok && res.unknown != null && res.guess != null && res.unknown.count { it } <= 3) {
            val done = tracker.complete(res.pieces, res.unknown, res.guess)
            if (done != null) res = ReadResult(true, done, "", res.worstCost)
        }
        if (!res.ok) {
            pending = null
            failCount++
            forceRead = failCount < 3
            notBefore = System.currentTimeMillis() + 1200
            if (res.pieces.all { it == 0 } && refindFrame(s, rect)) return
            status("อ่านกระดานไม่ออก: ${res.reason}\n" + gridText(res.pieces) +
                "\n[กรอบ ${rect.x},${rect.y} ขนาด ${rect.width} | จอ ${s.width}x${s.height}]\n(เปลี่ยนธีม/กระดานแล้ว? เปิดเกมใหม่ตอนตำแหน่งเริ่มต้น แอปจะเรียนรู้ใหม่เอง)")
            if (reader.detectBottomWhite(img) != null) doLearnNow()
            return
        }
        failCount = 0
        if (tracker.pos == null || looksLikeStart(res.pieces)) {
            val guess = reader.guessBottomWhite(img)
            if (guess != null && guess != bottomWhite) {
                setBottom(guess)
                clearEval()
                tracker.reset()
                accepted = null; pending = null; advice = null
                forceRead = true
                status("ตรวจพบว่าคุณเล่น${if (guess) "ขาว" else "ดำ"}")
                return
            }
        }
        val acc = accepted
        if (acc != null && acc.contentEquals(res.pieces)) {
            if (tracker.pos != null) analyzeCurrent()
            return
        }
        val pend = pending
        if (pend == null || !pend.contentEquals(res.pieces)) {
            pending = res.pieces
            forceRead = true
            notBefore = System.currentTimeMillis() + 30
            return
        }
        pending = null
        failCount = 0
        accepted = res.pieces
        advice = null
        tracker.update(res.pieces, userColor)
        analyzeCurrent()
    }

    private fun setBottom(white: Boolean) {
        bottomWhite = white
        settings.bottomWhite = white
    }

    private fun gridText(p: IntArray): String {
        val sb = StringBuilder()
        for (row in 0 until 8) {
            for (col in 0 until 8) sb.append(Piece.toChar(p[BoardReader.squareOf(row, col, bottomWhite)])).append(' ')
            if (row < 7) sb.append('\n')
        }
        return sb.toString()
    }

    private fun looksLikeStart(p: IntArray): Boolean {
        var n = 0
        for (sq in 0 until 64) if (p[sq] != 0) {
            val rank = sq shr 3
            if (rank != 0 && rank != 1 && rank != 6 && rank != 7) return false
            n++
        }
        return n == 32
    }

    /** Board picture without our own arrows or window on top. */
    private fun cleanCapture(s: PixelScreen, rect: Rectangle): com.chesslens.core.BoardImage {
        overlay?.clearArrowSync()
        val wb = windowBounds()
        val covers = wb != null && wb.intersects(rect)
        if (covers) hideWindowFor(rect, true)
        if (overlay != null || covers) Thread.sleep(if (covers) 120 else 40)
        s.captureRegion(rect)
        val img = s.grabBoard(rect)
        if (covers) hideWindowFor(rect, false)
        return img
    }

    // ------------------------------------------------------------ analysis

    private fun turnNote(): String = if (tracker.assumedTurn) "\n(เดาว่าเป็นตาคุณ — กด 'สลับตา' ถ้าไม่ใช่)" else ""

    private fun analyzeCurrent() {
        val pos = tracker.pos ?: return
        val moves = pos.legalMoves()
        if (moves.isEmpty()) {
            advice = null
            showArrow(null)
            status(if (pos.inCheck()) "รุกจน — จบเกม" else "เสมอ (ไม่มีตาเดิน)")
            return
        }
        if (pos.side != userColor) {
            advice = null
            showArrow(null)
            status("รอคู่ต่อสู้เดิน…" + turnNote())
            return
        }
        val a = advice
        if (a != null) {
            applyAdvice(a)
            return
        }
        val eng = engine ?: return
        val snapshot = pos.copy()
        eng.configure(if (settings.multiLines) 3 else 1, settings.elo)
        val gen = generation
        val ms = engineTimeMs
        status("กำลังคิด…")
        analysisPool.execute {
            for (budget in longArrayOf(QUICK_MS, ms)) {
                if (gen != generation) return@execute
                val r = try { eng.analyze(snapshot, budget) } catch (e: Exception) { null }
                if (r == null) {
                    val why = (eng as? UciEngine)?.lastError ?: ""
                    work.execute { if (gen == generation) engineFailed(eng, why) }
                    return@execute
                }
                work.execute {
                    if (gen != generation) return@execute
                    var text = MoveText.describe(snapshot, r.move) + "\nประเมิน: " + MoveText.scoreText(r) +
                        "  (${eng.name}, ลึก ${r.depth})" + turnNote()
                    val shown = if (settings.multiLines) r.others else emptyList()
                    if (shown.isNotEmpty()) {
                        text += "\nตัวเลือกอื่น: " + shown.withIndex().joinToString("   ") { (i, o) ->
                            "${i + 2}) ${Moves.squareName(Moves.from(o.move))}${Moves.squareName(Moves.to(o.move))} ${MoveText.scoreText(o)}"
                        }
                    }
                    if (settings.elo > 0 && eng is UciEngine) text += "\nจำกัดระดับเอนจิน ~${settings.elo}"
                    val whiteCp = if (snapshot.side == Piece.WHITE) r.scoreCp else -r.scoreCp
                    val frac = if (r.mateIn != null) {
                        val whiteWins = (r.mateIn > 0) == (snapshot.side == Piece.WHITE)
                        if (whiteWins) 0.98f else 0.02f
                    } else (1.0 / (1.0 + Math.exp(-whiteCp / 400.0))).toFloat()
                    val evalText = if (r.mateIn != null) "M" + Math.abs(r.mateIn)
                    else (if (whiteCp >= 0) "+" else "-") + String.format(java.util.Locale.US, "%.1f", Math.abs(whiteCp) / 100.0)
                    val adv = Advice(
                        Moves.from(r.move), Moves.to(r.move), text, r.move,
                        r.others.map { intArrayOf(Moves.from(it.move), Moves.to(it.move)) }, frac, evalText
                    )
                    advice = adv
                    applyAdvice(adv)
                    if (budget == ms && autoMode) playAdvice(true)
                }
            }
        }
    }

    private fun engineFailed(eng: MoveAdvisor, why: String) {
        if (eng is UciEngine) {
            try { eng.close() } catch (e: Exception) { }
            engine = BuiltinEngine()
            engineTimeMs = 800
            status("Stockfish ใช้ไม่ได้ ($why)\nสลับไปใช้เอนจินในตัวแทน")
            analyzeCurrent()
        } else {
            status("คิดตาเดินไม่ออก: ไม่พบตาเดินที่ใช้ได้ในตำแหน่งนี้\nอ่านกระดานอาจผิด ลองกด 'สลับตา' หรือ 'เรียนรู้'")
        }
    }

    private fun applyAdvice(a: Advice) {
        val mask = BoardGeometry.arrowSampleMask(a.from, a.to, bottomWhite)
        if (settings.multiLines) for (e in a.others) {
            val m2 = BoardGeometry.arrowSampleMask(e[0], e[1], bottomWhite)
            for (i in mask.indices) if (m2[i]) mask[i] = true
        }
        ignore = mask
        showArrow(a)
        status(a.text)
    }

    private fun showArrow(a: Advice?) {
        val o = overlay ?: return
        val r = frame
        if (a == null || r == null) {
            o.clearArrow()
            o.setEval(null, 0.5f, "")
            return
        }
        o.setArrow(r, a.from, a.to, bottomWhite, if (settings.multiLines) a.others else emptyList())
        if (settings.evalBar) o.setEval(r, a.evalFrac, a.evalText) else o.setEval(null, 0.5f, "")
    }

    private fun clearEval() { overlay?.setEval(null, 0.5f, "") }

    // ------------------------------------------------------------ user actions (UI thread calls these)

    private fun applyFrame(r: Rectangle, auto: Boolean = false) {
        clearEval()
        val s = screen
        frame = r
        if (s != null) settings.setFrame(s.width, s.height, r)
        lastSig = null; accepted = null; pending = null; advice = null
        generation++
        showArrow(null)
        status(guideText())
    }

    fun setManualFrame(r: Rectangle) = work.execute { applyFrame(r) }

    fun learn() = work.execute { doLearnNow() }

    private fun doLearnNow() {
        val s = screen ?: return
        val rect = frame
        if (rect == null) {
            status("ตั้งกรอบกระดานก่อน (กด 'ตั้งกรอบ')")
            return
        }
        generation++
        advice = null
        ignore = null
        showArrow(null)
        Thread.sleep(300)
        val img = cleanCapture(s, rect)
        val (lr, side) = reader.learnAuto(img)
        if (lr.ok && side != null) {
            setBottom(side)
            try { settings.templatesFile.outputStream().use { reader.save(it) } } catch (e: Exception) { }
            clearEval()
            tracker.reset()
            accepted = null; pending = null; lastSig = null
            forceRead = true
            notBefore = 0
            status(lr.message + "\nคุณเล่น${if (side) "ขาว" else "ดำ"} — เริ่มเล่นได้เลย")
        } else {
            status(lr.message + "\n[กรอบ ${rect.x},${rect.y} ขนาด ${rect.width} | จอ ${s.width}x${s.height}]")
        }
    }

    fun flipSide() = work.execute {
        clearEval()
        generation++
        advice = null; ignore = null
        showArrow(null)
        setBottom(!bottomWhite)
        tracker.reset()
        accepted = null; pending = null; lastSig = null
        forceRead = true
        status("สลับเป็นเล่น${if (bottomWhite) "ขาว" else "ดำ"}")
    }

    fun flipTurn() = work.execute {
        if (tracker.pos == null) return@execute
        generation++
        advice = null; ignore = null
        showArrow(null)
        tracker.flipTurn()
        analyzeCurrent()
    }

    fun optionsChanged() = work.execute {
        advice = null
        generation++
        if (tracker.pos != null) analyzeCurrent() else showArrow(null)
    }

    fun cycleScreen() {
        val n = GraphicsEnvironment.getLocalGraphicsEnvironment().screenDevices.size
        settings.screenIndex = (settings.screenIndex + 1) % Math.max(1, n)
        if (running) {
            stop()
            work.schedule({ start() }, 600, TimeUnit.MILLISECONDS)
        }
    }

    // ------------------------------------------------------------ clicking the move (practice vs bots / engines only)

    private fun squareCenter(rect: Rectangle, sq: Int): Point {
        val file = sq and 7
        val rank = sq shr 3
        val col = if (bottomWhite) file else 7 - file
        val row = if (bottomWhite) 7 - rank else rank
        return Point((rect.x + (col + 0.5) * rect.width / 8.0).toInt(), (rect.y + (row + 0.5) * rect.height / 8.0).toInt())
    }

    fun toggleAuto() = work.execute {
        val now = System.currentTimeMillis()
        if (autoMode) {
            autoMode = false
            onAutoChanged(false)
            status("ปิดโหมดออโต้แล้ว")
            return@execute
        }
        if (robot == null) { status("โหมดออโต้ใช้ไม่ได้ในสภาพแวดล้อมนี้"); return@execute }
        if (now > autoArmUntil) {
            autoArmUntil = now + 5000
            status("โหมดออโต้จะเดินให้ทุกตา ใช้ฝึกกับบอท/เอนจินเท่านั้น ห้ามใช้กับคนจริง\nกด 'ออโต้' อีกครั้งภายใน 5 วินาทีเพื่อยืนยัน")
            return@execute
        }
        autoMode = true
        onAutoChanged(true)
        status("เปิดโหมดออโต้ (ฝึกกับบอท) จะเดินให้เมื่อถึงตาคุณ")
        analyzeCurrent()
    }

    private fun stopAuto(why: String) {
        autoMode = false
        onAutoChanged(false)
        status(why)
    }

    fun playOnce() = work.execute { playAdvice(false) }

    private fun playAdvice(fromAuto: Boolean) {
        val a = advice
        val rect = frame
        val rb = robot
        val pos = tracker.pos
        if (moving) return
        if (rb == null) return
        if (a == null || rect == null || pos == null || pos.side != userColor) {
            if (!fromAuto) status("ยังไม่มีตาเดินที่ต้องเดิน (รอถึงตาคุณและรอให้คิดเสร็จ)")
            return
        }
        moving = true
        val gen = generation
        val before = accepted?.copyOf()
        val promo = Moves.promo(a.move) != 0
        val f = squareCenter(rect, a.from)
        val t = squareCenter(rect, a.to)
        overlay?.clearArrowSync()
        val wb = windowBounds()
        val covers = wb != null && (wb.contains(f) || wb.contains(t))
        if (covers) hideWindowFor(rect, true)
        Thread.sleep(120)
        val taps = if (promo) listOf(f, t, t) else listOf(f, t)
        val times = if (promo) listOf(0L, 220L, 900L) else listOf(0L, 220L)
        var ok = true
        try { rb.click(taps, times) } catch (e: Exception) { ok = false }
        if (covers) hideWindowFor(rect, false)
        moving = false
        if (!ok) { stopAuto("คลิกไม่สำเร็จ ปิดโหมดออโต้"); return }
        if (promo) status("เดินเลื่อนขั้นเป็นควีน")
        forceRead = true
        notBefore = System.currentTimeMillis() + 150
        work.schedule({
            val same = before != null && accepted != null && accepted!!.contentEquals(before)
            if (same && gen == generation && tracker.pos?.side == userColor && autoMode) {
                stopAuto("เดินแล้วกระดานไม่เปลี่ยน (เกมอาจไม่รับคลิก) ปิดโหมดออโต้")
            }
        }, 3500, TimeUnit.MILLISECONDS)
    }
}
