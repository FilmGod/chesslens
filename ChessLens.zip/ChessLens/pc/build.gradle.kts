plugins {
    kotlin("jvm") version "2.0.21"
}

dependencies {
    // only used to make the arrow window click-through on Windows
    implementation("net.java.dev.jna:jna-platform:5.14.0")
}

sourceSets {
    main {
        // the board reader, engine and game tracker are shared with the Android app
        kotlin.srcDir("../app/src/main/java/com/chesslens/core")
        // license.json (server address) is shared as well
        resources.srcDir("../app/src/main/assets")
    }
}

tasks.jar {
    archiveFileName.set("chesslens.jar")
    manifest { attributes("Main-Class" to "com.chesslens.pc.MainKt") }
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    exclude("META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA")
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) })
}
