package com.chesslens

import org.junit.Assert.assertTrue
import org.junit.Test

class CoreTest {
    @Test
    fun everythingPasses() {
        val r = CoreChecks.runAll()
        assertTrue("failed: " + r.failures.joinToString("; "), r.failures.isEmpty())
    }
}
