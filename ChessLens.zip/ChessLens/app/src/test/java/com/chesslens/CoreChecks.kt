package com.chesslens

import com.chesslens.core.BoardGeometry
import com.chesslens.core.BoardImage
import com.chesslens.core.BoardReader
import com.chesslens.core.BuiltinEngine
import com.chesslens.core.MoveText
import com.chesslens.core.Moves
import com.chesslens.core.Piece
import com.chesslens.core.Position
import com.chesslens.core.PositionTracker
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Random

/** Pure-JVM checks of everything that does not need Android. Used by CoreTest (JUnit) and runnable via main(). */
object CoreChecks {
    class Report {
        val failures = ArrayList<String>()
        var passed = 0
        fun check(ok: Boolean, what: String) {
            if (ok) passed++ else failures.add(what)
        }
    }

    fun perftChecks(r: Report) {
        val cases = listOf(
            Triple(Position.START_FEN, 4, 197281L),
            Triple("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1", 3, 97862L),
            Triple("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1", 4, 4085603L),
            Triple("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1", 5, 674624L),
            Triple("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1", 4, 422333L),
            Triple("rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 4, 2103487L),
            Triple("r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10", 3, 89890L)
        )
        for ((fen, depth, expected) in cases) {
            val p = Position.fromFen(fen)!!
            val got = p.perft(depth)
            r.check(got == expected, "perft d$depth '$fen': got $got expected $expected")
        }
    }

    private fun randomGame(seed: Long, plies: Int): ArrayList<Position> {
        val rnd = Random(seed)
        val p = Position.start()
        val out = ArrayList<Position>()
        out.add(p.copy())
        repeat(plies) {
            val moves = p.legalMoves()
            if (moves.isEmpty()) return out
            p.makeMove(moves[rnd.nextInt(moves.size)])
            out.add(p.copy())
        }
        return out
    }

    fun hashChecks(r: Report) {
        for (seed in 1L..6L) {
            val rnd = Random(seed)
            val p = Position.start()
            val startHash = p.hash
            val startFen = p.toFen()
            var made = 0
            var ok = true
            for (i in 0 until 250) {
                val moves = p.legalMoves()
                if (moves.isEmpty()) break
                p.makeMove(moves[rnd.nextInt(moves.size)])
                made++
                if (p.hash != p.computeHash()) ok = false
                val back = Position.fromFen(p.toFen())!!
                if (back.hash != p.hash) ok = false
            }
            r.check(ok, "incremental hash / FEN round trip (seed $seed)")
            repeat(made) { p.unmakeMove() }
            r.check(p.hash == startHash && p.toFen() == startFen, "unmake restores start (seed $seed)")
        }
    }

    fun engineChecks(r: Report) {
        val eng = BuiltinEngine()
        fun best(fen: String, ms: Long = 1500): String {
            val res = eng.analyze(Position.fromFen(fen)!!, ms) ?: return "none"
            return Moves.uci(res.move)
        }
        r.check(best("6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1") == "a1a8", "back-rank mate in 1")
        r.check(best("6k1/8/6K1/8/8/8/8/R7 w - - 0 1") == "a1a8", "rook mate with king support")
        r.check(best("4k3/8/8/3q4/8/8/8/3QK3 w - - 0 1") == "d1d5", "wins the queen")
        r.check(best("6k1/5ppp/8/8/8/8/5PPP/r5K1 w - - 0 1") == "none", "checkmated side has no move")
        // black to move must also work (mirror of the back-rank mate)
        r.check(best("r5k1/5ppp/8/8/8/8/5PPP/6K1 b - - 0 1") == "a8a1", "back-rank mate in 1 for black")
        // does not hang the queen to a pawn
        val safe = best("rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 2")
        r.check(safe != "none", "plays something in an ordinary opening position")
    }

    // ----- synthetic board pictures -----
    private fun inShape(type: Int, u: Double, v: Double): Boolean {
        if (u in 0.22..0.78 && v in 0.80..0.90) return true
        fun circle(cx: Double, cy: Double, rad: Double) = (u - cx) * (u - cx) + (v - cy) * (v - cy) <= rad * rad
        return when (type) {
            Piece.PAWN -> circle(0.5, 0.38, 0.14) || (v in 0.5..0.8 && Math.abs(u - 0.5) <= 0.08 + (v - 0.5) * 0.35)
            Piece.ROOK -> (u in 0.3..0.7 && v in 0.35..0.8) ||
                (v in 0.22..0.35 && (u in 0.28..0.38 || u in 0.45..0.55 || u in 0.62..0.72))
            Piece.KNIGHT -> (v in 0.2..0.5 && u >= 0.25 && u <= 0.45 + (v - 0.2) * 1.2) || (u in 0.35..0.7 && v in 0.5..0.8)
            Piece.BISHOP -> (Math.abs(u - 0.5) / 0.16 + Math.abs(v - 0.4) / 0.22 <= 1.0) ||
                (u in 0.4..0.6 && v in 0.55..0.8) || circle(0.5, 0.15, 0.05)
            Piece.QUEEN -> circle(0.5, 0.35, 0.2) ||
                (v in 0.1..0.3 && (Math.abs(u - 0.3) < (v - 0.1) * 0.4 || Math.abs(u - 0.5) < (v - 0.1) * 0.4 || Math.abs(u - 0.7) < (v - 0.1) * 0.4)) ||
                (v in 0.5..0.8 && Math.abs(u - 0.5) <= 0.15)
            Piece.KING -> (u in 0.45..0.55 && v in 0.1..0.4) || (u in 0.35..0.65 && v in 0.18..0.28) ||
                (v in 0.4..0.8 && Math.abs(u - 0.5) <= 0.17)
            else -> false
        }
    }

    private fun pieceColor(piece: Int, u: Double, v: Double): Int? {
        val type = piece and 7
        if (!inShape(type, u, v)) return null
        val inner = inShape(type, 0.5 + (u - 0.5) / 0.88, 0.55 + (v - 0.55) / 0.88)
        val white = (piece shr 3) == Piece.WHITE
        return if (inner) (if (white) 0xF5F5F5 else 0x464646) else (if (white) 0x191919 else 0x0F0F0F)
    }

    fun renderBoard(
        board: IntArray, whiteAtBottom: Boolean, highlight: Set<Int> = emptySet(),
        shiftX: Int = 0, shiftY: Int = 0, noise: Int = 0, rnd: Random = Random(1),
        light: Int = 0xF0D9B5, dark: Int = 0xB58863
    ): BoardImage {
        val cell = 80
        val size = cell * 8
        val px = IntArray(size * size) { 0x808080 }
        for (y in 0 until size) for (x in 0 until size) {
            val sx = x - shiftX
            val sy = y - shiftY
            if (sx !in 0 until size || sy !in 0 until size) continue
            val col = sx / cell
            val row = sy / cell
            val sq = BoardReader.squareOf(row, col, whiteAtBottom)
            val isLight = ((sq and 7) + (sq shr 3)) % 2 == 1
            var bg = if (isLight) light else dark
            if (sq in highlight) { // the move highlight sits under the piece, as on real chess sites
                val hr = (((bg shr 16) and 255) * 0.65 + 255 * 0.35).toInt()
                val hg = (((bg shr 8) and 255) * 0.65 + 255 * 0.35).toInt()
                val hb = ((bg and 255) * 0.65).toInt()
                bg = (hr shl 16) or (hg shl 8) or hb
            }
            var rr = 0
            var gg = 0
            var bb = 0
            for (sub in 0 until 4) {
                val u = ((sx % cell) + 0.25 + (sub and 1) * 0.5) / cell
                val v = ((sy % cell) + 0.25 + (sub shr 1) * 0.5) / cell
                var c = bg
                val piece = board[sq]
                if (piece != 0) pieceColor(piece, u, v)?.let { c = it }
                rr += (c shr 16) and 255
                gg += (c shr 8) and 255
                bb += c and 255
            }
            var r = rr / 4
            var g = gg / 4
            var b = bb / 4
            if (noise > 0) {
                r = (r + rnd.nextInt(2 * noise + 1) - noise).coerceIn(0, 255)
                g = (g + rnd.nextInt(2 * noise + 1) - noise).coerceIn(0, 255)
                b = (b + rnd.nextInt(2 * noise + 1) - noise).coerceIn(0, 255)
            }
            px[y * size + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        return BoardImage(size, size, px)
    }

    fun readerChecks(r: Report) {
        for (white in listOf(true, false)) {
            val tag = if (white) "white at bottom" else "black at bottom"
            val reader = BoardReader()
            val start = Position.startBoard()
            val lr = reader.learn(renderBoard(start, white), white)
            r.check(lr.ok, "learn ($tag): ${lr.message}")
            if (!lr.ok) continue
            val game = randomGame(if (white) 11 else 12, 90)
            // 1) same framing as when it learned (what happens in real use): must be perfect, with move highlights and noise
            var wrong = 0
            var notOk = 0
            var tested = 0
            for (i in 0 until game.size step 3) {
                val rnd = Random(i.toLong())
                val hl = HashSet<Int>()
                if (i > 0) { hl.add(rnd.nextInt(64)); hl.add(rnd.nextInt(64)) }
                val img = renderBoard(game[i].board, white, hl, noise = 4, rnd = rnd)
                val res = reader.read(img, white)
                tested++
                if (!res.ok) notOk++ else if (!res.pieces.contentEquals(game[i].board)) wrong++
            }
            r.check(wrong == 0 && notOk == 0, "read $tag: $wrong wrong, $notOk unreadable of $tested")

            // 2) board framed 1-2 px differently: may refuse to read, but must never read a wrong position
            var wrongShift = 0
            var testedShift = 0
            for (i in 0 until game.size step 3) {
                val rnd = Random(i.toLong() + 500)
                val img = renderBoard(game[i].board, white, shiftX = 1 + i % 2, shiftY = 1, noise = 4, rnd = rnd)
                val res = reader.read(img, white)
                testedShift++
                if (res.ok && !res.pieces.contentEquals(game[i].board)) wrongShift++
            }
            r.check(wrongShift == 0, "never misreads a shifted board ($tag): $wrongShift wrong of $testedShift")

            // different square colours (another board theme) must still be readable with the same templates
            val green = renderBoard(game[40].board, white, light = 0xEEEED2, dark = 0x769656)
            val rg = reader.read(green, white)
            r.check(rg.ok && rg.pieces.contentEquals(game[40].board), "read $tag on a green board: ${rg.reason}")

            // junk must be rejected, not turned into a position
            val junk = BoardImage(640, 640, IntArray(640 * 640) { 0xFF336699.toInt() xor (it * 2654435761L).toInt() and 0x00FFFFFF })
            r.check(!reader.read(junk, white).ok, "random noise is rejected ($tag)")

            // empty board picture: nothing found, so invalid (no kings)
            val empty = renderBoard(IntArray(64), white)
            r.check(!reader.read(empty, white).ok, "empty board is rejected ($tag)")
        }

        // learning must refuse a position that is not the starting position
        val reader = BoardReader()
        val moved = Position.start().also { it.makeMove(it.parseUci("e2e4")) }.board
        r.check(!reader.learn(renderBoard(moved, true), true).ok, "learn refuses a non-start position")

        // save / load
        val a = BoardReader()
        a.learn(renderBoard(Position.startBoard(), true), true)
        val bos = ByteArrayOutputStream()
        a.save(bos)
        val b = BoardReader()
        r.check(b.load(ByteArrayInputStream(bos.toByteArray())), "templates load")
        val g = randomGame(5, 40)
        val rr = b.read(renderBoard(g[30].board, true), true)
        r.check(rr.ok && rr.pieces.contentEquals(g[30].board), "loaded templates read correctly")
        r.check(!BoardReader().load(ByteArrayInputStream(ByteArray(10))), "garbage template file is rejected")
    }

    fun trackerChecks(r: Report) {
        for (seed in 1L..5L) {
            val game = randomGame(seed, 120)
            val t = PositionTracker()
            val userColor = if (seed % 2 == 0L) Piece.BLACK else Piece.WHITE
            var bad = 0
            var i = 0
            val rnd = Random(seed)
            while (i < game.size) {
                t.update(game[i].board, userColor)
                val p = t.pos!!
                if (!p.board.contentEquals(game[i].board)) bad++
                if (!t.assumedTurn && p.side != game[i].side) bad++
                i += 1 + rnd.nextInt(3) // sometimes skips one or two plies
            }
            r.check(bad == 0, "tracker follows a random game with skipped frames (seed $seed): $bad mismatches")
        }
        // starting mid-game: turn is assumed to be the user's
        val g = randomGame(9, 30)
        val t = PositionTracker()
        t.update(g[20].board, Piece.WHITE)
        r.check(t.assumedTurn && t.pos!!.side == Piece.WHITE, "mid-game start assumes the user's turn")
        t.flipTurn()
        r.check(t.pos!!.side == Piece.BLACK && !t.assumedTurn, "flip turn works")
        // new game after the old one resets to white to move
        val t2 = PositionTracker()
        t2.update(g[10].board, Piece.BLACK)
        t2.update(Position.startBoard(), Piece.BLACK)
        r.check(t2.pos!!.side == Piece.WHITE && !t2.assumedTurn, "new game detected from the start position")
        // castling is tracked as a move
        val c = Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")!!
        val t3 = PositionTracker()
        t3.update(c.board, Piece.WHITE)
        val after = c.copy().also { it.makeMove(it.parseUci("e1g1")) }
        t3.update(after.board, Piece.WHITE)
        r.check(t3.pos!!.board.contentEquals(after.board) && t3.pos!!.side == Piece.BLACK, "castling is followed")
    }

    fun geometryChecks(r: Report) {
        val m = BoardGeometry.arrowMask(12, 28, true) // e2 -> e4
        r.check(m[6 * 8 + 4] && m[5 * 8 + 4] && m[4 * 8 + 4], "arrow mask covers e2-e4")
        r.check(!m[0] && !m[63], "arrow mask leaves far squares alone")
        val flipped = BoardGeometry.arrowMask(12, 28, false)
        r.check(flipped[1 * 8 + 3] && flipped[2 * 8 + 3] && flipped[3 * 8 + 3], "arrow mask mirrors when black is at the bottom")
    }

    fun signatureChecks(r: Report) {
        val g = randomGame(21, 40)
        val a = renderBoard(g[30].board, true)
        val b = renderBoard(g[31].board, true)
        val sa = com.chesslens.core.Signature.of(a)
        val sb = com.chesslens.core.Signature.of(b)
        r.check(!com.chesslens.core.Signature.changed(sa, com.chesslens.core.Signature.of(a), null, 12), "same picture is not a change")
        r.check(com.chesslens.core.Signature.changed(sa, sb, null, 12), "a move is detected as a change")
        val noisy = renderBoard(g[30].board, true, noise = 6, rnd = Random(3))
        r.check(!com.chesslens.core.Signature.changed(sa, com.chesslens.core.Signature.of(noisy), null, 12), "noise alone is not a change")
        // draw an "arrow" (bright stripe) over e2-e4 and check that masking it hides it from change detection
        val withArrow = renderBoard(g[30].board, true)
        val mask = BoardGeometry.arrowSampleMask(12, 28, true)
        val px = withArrow.argb.copyOf()
        val cell = withArrow.width / 8
        for (y in 4 * cell + cell / 2 until 7 * cell - cell / 2) for (x in 4 * cell + cell / 2 - 8 until 4 * cell + cell / 2 + 8) px[y * withArrow.width + x] = 0xFF00C853.toInt()
        val sArrow = com.chesslens.core.Signature.of(BoardImage(withArrow.width, withArrow.height, px))
        r.check(com.chesslens.core.Signature.changed(sa, sArrow, null, 12), "an unmasked arrow looks like a change")
        r.check(!com.chesslens.core.Signature.changed(sa, sArrow, mask, 12), "a masked arrow is ignored")
        r.check(com.chesslens.core.Signature.changed(sa, sb, BoardGeometry.arrowSampleMask(0, 1, true), 12), "moves away from the arrow are still seen")
    }

    /** Whole chain as the app uses it: picture -> board reader -> game tracker -> engine -> move, over a played game. */
    fun pipelineChecks(r: Report) {
        val white = true
        val reader = BoardReader()
        r.check(reader.learn(renderBoard(Position.startBoard(), white), white).ok, "pipeline: learn start position")
        val tracker = PositionTracker()
        val engine = BuiltinEngine()
        val truth = Position.start()
        val rnd = Random(77)
        var illegal = 0
        var lost = 0
        var userMoves = 0
        var last = -1
        repeat(40) { ply ->
            val hl = HashSet<Int>()
            if (last >= 0) { hl.add(Moves.from(last)); hl.add(Moves.to(last)) }
            val img = renderBoard(truth.board, white, hl, noise = 3, rnd = Random(ply.toLong()))
            val read = reader.read(img, white)
            if (!read.ok || !read.pieces.contentEquals(truth.board)) { lost++; return }
            tracker.update(read.pieces, Piece.WHITE)
            val pos = tracker.pos ?: run { lost++; return }
            if (!tracker.assumedTurn && pos.side != truth.side) lost++
            val moves = truth.legalMoves()
            if (moves.isEmpty()) return
            val mv: Int
            if (truth.side == Piece.WHITE) {
                val res = engine.analyze(pos.copy(), 120)
                if (res == null || res.move !in moves) { illegal++; return }
                val text = MoveText.describe(pos, res.move)
                if (text.isBlank()) illegal++
                mv = res.move
                userMoves++
            } else {
                mv = moves[rnd.nextInt(moves.size)]
            }
            truth.makeMove(mv)
            last = mv
        }
        r.check(lost == 0, "pipeline: board lost or misread $lost times")
        r.check(illegal == 0, "pipeline: engine suggested an illegal/unreadable move $illegal times")
        r.check(userMoves >= 10, "pipeline: only $userMoves advice rounds ran")
    }

    fun runAll(): Report {
        val r = Report()
        perftChecks(r)
        hashChecks(r)
        engineChecks(r)
        readerChecks(r)
        trackerChecks(r)
        geometryChecks(r)
        signatureChecks(r)
        pipelineChecks(r)
        return r
    }
}

fun main() {
    val t0 = System.currentTimeMillis()
    val r = CoreChecks.runAll()
    println("passed=${r.passed} failed=${r.failures.size} time=${System.currentTimeMillis() - t0}ms")
    r.failures.forEach { println("FAIL: $it") }
    if (r.failures.isNotEmpty()) System.exit(1)
}
