package com.chesslens

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Colours and small helpers shared by the app screen and the floating panel (no AppCompat/Material needed). */
object Ui {
    val BG = Color.rgb(10, 15, 21)
    val CARD = Color.rgb(20, 28, 38)
    val CARD_HI = Color.rgb(29, 40, 53)
    val STROKE = Color.rgb(42, 56, 72)
    val TEXT = Color.rgb(233, 240, 247)
    val MUTED = Color.rgb(135, 151, 169)
    val ACCENT = Color.rgb(52, 226, 168)
    val ACCENT_DEEP = Color.rgb(20, 168, 132)
    val ON_ACCENT = Color.rgb(4, 32, 24)
    val GOLD = Color.rgb(255, 196, 61)
    val ERR = Color.rgb(255, 111, 117)

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusPx: Int, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx.toFloat()
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun gradient(c1: Int, c2: Int, radiusPx: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
            cornerRadius = radiusPx.toFloat()
        }

    fun circle(color: Int): GradientDrawable = GradientDrawable().apply {
        setShape(GradientDrawable.OVAL)
        setColor(color)
    }

    /** Gentle shrink while pressed and a soft spring back. Does not consume the touch, so clicks still work. */
    fun pressEffect(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate()?.scaleX(0.95f)?.scaleY(0.95f)?.setDuration(90)?.setInterpolator(DecelerateInterpolator())?.start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(220)?.setInterpolator(OvershootInterpolator(2.2f))?.start()
            }
            false
        }
    }

    /** Fade and slide the view up into place; [delayMs] staggers a list of cards. */
    fun enter(v: View, delayMs: Long, risePx: Int) {
        v.alpha = 0f
        v.setTranslationY(risePx.toFloat())
        v.animate()?.alpha(1f)?.translationY(0f)?.setStartDelay(delayMs)?.setDuration(420)
            ?.setInterpolator(DecelerateInterpolator(1.6f))?.start()
    }

    fun label(ctx: Context, text: String, sizeSp: Float, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun primaryButton(ctx: Context, label: String, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(ON_ACCENT)
        setTypeface(typeface, Typeface.BOLD)
        background = gradient(ACCENT, ACCENT_DEEP, dp(ctx, 14))
        setStateListAnimator(null)
        setElevation(0f)
        setPadding(dp(ctx, 18), dp(ctx, 12), dp(ctx, 18), dp(ctx, 12))
        setOnClickListener { onClick() }
        pressEffect(this)
    }

    fun ghostButton(ctx: Context, label: String, color: Int = TEXT, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(color)
        background = rounded(CARD_HI, dp(ctx, 14), STROKE, 1)
        setStateListAnimator(null)
        setElevation(0f)
        setPadding(dp(ctx, 18), dp(ctx, 10), dp(ctx, 18), dp(ctx, 10))
        setOnClickListener { onClick() }
        pressEffect(this)
    }

    fun pill(ctx: Context, text: String, fg: Int, bg: Int): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 12f
        setTextColor(fg)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(bg, dp(ctx, 20))
        setPadding(dp(ctx, 10), dp(ctx, 4), dp(ctx, 10), dp(ctx, 4))
        gravity = Gravity.CENTER
    }

    fun withAlpha(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).also { it.setMargins(l, t, r, b) }
}
