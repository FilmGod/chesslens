package com.chesslens.core

import java.util.Random

/** Playing style: among moves that are nearly as good as the best, prefer the ones that fit the style. */
object PlayStyle {
    const val BALANCED = 0
    const val AGGRESSIVE = 1
    const val SOLID = 2

    val names = listOf("สมดุล", "บุก", "มั่นคง")

    private fun isCastle(pos: Position, m: Int): Boolean =
        Piece.type(pos.board[Moves.from(m)]) == Piece.KING && Math.abs(Moves.to(m) - Moves.from(m)) == 2

    /** How aggressive a move is (checks, captures, sacrifices, advanced pawns); quiet development is low. */
    fun aggression(pos: Position, m: Int): Double {
        var s = 0.0
        val victim = pos.board[Moves.to(m)]
        val mover = pos.board[Moves.from(m)]
        if (victim != 0) s += 1.5
        val q = pos.copy()
        q.makeMove(m)
        if (q.inCheck(q.side)) s += 2.0
        if (MoveQuality.materialSwing(pos, m) <= -2) s += 1.5
        if (Piece.type(mover) == Piece.PAWN) {
            val rank = Moves.to(m) shr 3
            val adv = if (Piece.color(mover) == Piece.WHITE) rank else 7 - rank
            if (adv >= 4) s += 1.0
        }
        if (Moves.promo(m) != 0) s += 2.0
        if (isCastle(pos, m)) s -= 1.0
        return s
    }

    fun solidity(pos: Position, m: Int): Double {
        var s = 0.0
        if (isCastle(pos, m)) s += 2.0
        if (pos.board[Moves.to(m)] == 0) s += 1.0
        val q = pos.copy()
        q.makeMove(m)
        if (q.inCheck(q.side)) s -= 0.5
        if (MoveQuality.materialSwing(pos, m) < 0) s -= 2.0
        return s
    }

    /** Index into [lines] (best first) of the line to play for [style]. */
    fun pick(pos: Position, lines: List<SearchResult>, style: Int, rng: Random): Int {
        if (style == BALANCED || lines.size < 2) return 0
        val best = MoveQuality.winPct(lines[0])
        val tol = if (style == AGGRESSIVE) 6.0 else 4.0
        var bestIdx = 0
        var bestScore = -1e9
        for (i in lines.indices) {
            val loss = best - MoveQuality.winPct(lines[i])
            if (loss > tol) continue
            val sc = (if (style == AGGRESSIVE) aggression(pos, lines[i].move) else solidity(pos, lines[i].move)) -
                loss * 0.15 + rng.nextDouble() * 0.05
            if (sc > bestScore) { bestScore = sc; bestIdx = i }
        }
        return bestIdx
    }
}
