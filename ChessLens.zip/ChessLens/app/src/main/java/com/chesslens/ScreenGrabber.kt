package com.chesslens

import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import com.chesslens.core.BoardFinder
import com.chesslens.core.BoardImage
import com.chesslens.core.FoundBoard
import com.chesslens.core.Signature

/** Receives the screen from MediaProjection and lets the rest of the app read pixels from the newest frame. */
class ScreenGrabber(
    private val projection: MediaProjection,
    private val handler: Handler,
    width: Int,
    height: Int,
    private val dpi: Int
) {
    var width = width
        private set
    var height = height
        private set

    private val lock = Any()
    private var reader: ImageReader = makeReader(width, height)
    private var display: VirtualDisplay = projection.createVirtualDisplay(
        "ChessLens", width, height, dpi,
        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler
    )
    private var latest: Image? = null

    /** Number of frames received so far; the screen only produces a frame when something on it changes. */
    @Volatile
    var frameCount = 0L
        private set

    private fun makeReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd -> onImage(rd) }, handler)
        return r
    }

    private fun onImage(rd: ImageReader) {
        val img = try {
            rd.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return
        synchronized(lock) {
            latest?.close()
            latest = img
            frameCount++
        }
    }

    fun resize(w: Int, h: Int) {
        synchronized(lock) {
            latest?.close()
            latest = null
            val old = reader
            reader = makeReader(w, h)
            display.resize(w, h, dpi)
            display.surface = reader.surface
            old.close()
            width = w
            height = h
        }
    }

    /** Waits until a frame newer than [after] arrives, or [timeoutMs] passes. */
    fun awaitFrame(after: Long, timeoutMs: Long) {
        val end = System.currentTimeMillis() + timeoutMs
        while (frameCount <= after && System.currentTimeMillis() < end) {
            try {
                Thread.sleep(15)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private inline fun <T> withPixels(block: (pixel: (Int, Int) -> Int) -> T): T? {
        synchronized(lock) {
            val img = latest ?: return null
            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val w = img.width
            val h = img.height
            val pixel = { x: Int, y: Int ->
                val o = y.coerceIn(0, h - 1) * rowStride + x.coerceIn(0, w - 1) * pixelStride
                ((buf.get(o).toInt() and 255) shl 16) or ((buf.get(o + 1).toInt() and 255) shl 8) or (buf.get(o + 2).toInt() and 255)
            }
            return try {
                block(pixel)
            } catch (e: Exception) {
                null
            }
        }
    }

    /** Looks for a chess board anywhere on the newest frame. */
    fun findBoard(): FoundBoard? = withPixels { px ->
        BoardFinder.find(width, height) { x, y -> px(x, y) }
    }

    /** False only when the area has clearly stopped looking like a chess board; true if unsure (no frame yet). */
    fun verifyBoard(rect: Rect): Boolean = withPixels { px ->
        BoardFinder.verify(rect.left, rect.top, rect.width(), width, height) { x, y -> px(x, y) }
    } ?: true

    /** Fingerprint of the board area, for cheap change detection. */
    fun signature(rect: Rect): IntArray? = withPixels { px ->
        Signature.sample(rect.width(), rect.height()) { x, y -> px(rect.left + x, rect.top + y) }
    }

    /** Copies the board area into a picture of at most 512 x 512 pixels. */
    fun grabBoard(rect: Rect): BoardImage? = withPixels { px ->
        val s = minOf(512, rect.width(), rect.height())
        val sx = rect.width().toDouble() / s
        val sy = rect.height().toDouble() / s
        val out = IntArray(s * s)
        for (oy in 0 until s) for (ox in 0 until s) {
            var r = 0
            var g = 0
            var b = 0
            for (k in 0 until 4) {
                val fx = (ox + 0.25 + 0.5 * (k and 1)) * sx
                val fy = (oy + 0.25 + 0.5 * (k shr 1)) * sy
                val c = px(rect.left + fx.toInt(), rect.top + fy.toInt())
                r += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
            }
            out[oy * s + ox] = (0xFF shl 24) or ((r / 4) shl 16) or ((g / 4) shl 8) or (b / 4)
        }
        BoardImage(s, s, out)
    }

    /** The whole screen shrunk to [outW] pixels wide with [rect] outlined in red, to show where the frame really is. */
    fun overview(rect: Rect, outW: Int): BoardImage? = withPixels { px ->
        val outH = (outW.toLong() * height / width).toInt().coerceAtLeast(1)
        val out = IntArray(outW * outH)
        val sx = width.toDouble() / outW
        val sy = height.toDouble() / outH
        for (oy in 0 until outH) for (ox in 0 until outW) {
            out[oy * outW + ox] = (0xFF shl 24) or px((ox * sx).toInt(), (oy * sy).toInt())
        }
        val l = (rect.left / sx).toInt()
        val r = (rect.right / sx).toInt()
        val t = (rect.top / sy).toInt()
        val bt = (rect.bottom / sy).toInt()
        for (x in l..r) for (w in 0..1) {
            val yy1 = (t + w).coerceIn(0, outH - 1)
            val yy2 = (bt - w).coerceIn(0, outH - 1)
            if (x in 0 until outW) { out[yy1 * outW + x] = 0xFFFF0000.toInt(); out[yy2 * outW + x] = 0xFFFF0000.toInt() }
        }
        for (y in t..bt) for (w in 0..1) {
            val xx1 = (l + w).coerceIn(0, outW - 1)
            val xx2 = (r - w).coerceIn(0, outW - 1)
            if (y in 0 until outH) { out[y * outW + xx1] = 0xFFFF0000.toInt(); out[y * outW + xx2] = 0xFFFF0000.toInt() }
        }
        BoardImage(outW, outH, out)
    }

    fun release() {
        synchronized(lock) {
            latest?.close()
            latest = null
            try { display.release() } catch (e: Exception) { }
            try { reader.close() } catch (e: Exception) { }
        }
    }
}
