package com.chesslens.core

import kotlin.math.abs

/**
 * @param scoreCp centipawns from the point of view of the side to move
 * @param mateIn  > 0: side to move mates in that many moves; < 0: side to move gets mated; null: no forced mate seen
 */
class SearchResult(val move: Int, val scoreCp: Int, val mateIn: Int?, val depth: Int, val others: List<SearchResult> = emptyList())

interface MoveAdvisor {
    val name: String
    fun analyze(pos: Position, timeMs: Long): SearchResult?

    /** [multiPv] = how many best moves to report (1..5); [elo] = 0 for full strength, else the strength to play at. */
    fun configure(multiPv: Int, elo: Int) {}
    fun close() {}
}

/** Self-contained alpha-beta engine (no native code). Roughly club level; Stockfish is used instead when bundled. */
class BuiltinEngine : MoveAdvisor {
    override val name = "Built-in"

    private companion object {
        const val MAX_PLY = 64
        const val INF = 32000
        const val MATE = 30000
        const val MATE_BOUND = MATE - 200
        const val TT_SIZE = 1 shl 20
        const val EXACT = 0
        const val LOWER = 1
        const val UPPER = 2

        val VALUE = intArrayOf(0, 100, 320, 330, 500, 900, 0)
        val ORDER_VALUE = intArrayOf(0, 1, 3, 3, 5, 9, 20)
        val PASSED = intArrayOf(0, 5, 10, 20, 35, 60, 100, 0)

        // Piece-square tables, written from White's point of view with rank 8 first.
        val PST = arrayOf(
            IntArray(64),
            intArrayOf(
                0, 0, 0, 0, 0, 0, 0, 0,
                50, 50, 50, 50, 50, 50, 50, 50,
                10, 10, 20, 30, 30, 20, 10, 10,
                5, 5, 10, 25, 25, 10, 5, 5,
                0, 0, 0, 20, 20, 0, 0, 0,
                5, -5, -10, 0, 0, -10, -5, 5,
                5, 10, 10, -20, -20, 10, 10, 5,
                0, 0, 0, 0, 0, 0, 0, 0
            ),
            intArrayOf(
                -50, -40, -30, -30, -30, -30, -40, -50,
                -40, -20, 0, 0, 0, 0, -20, -40,
                -30, 0, 10, 15, 15, 10, 0, -30,
                -30, 5, 15, 20, 20, 15, 5, -30,
                -30, 0, 15, 20, 20, 15, 0, -30,
                -30, 5, 10, 15, 15, 10, 5, -30,
                -40, -20, 0, 5, 5, 0, -20, -40,
                -50, -40, -30, -30, -30, -30, -40, -50
            ),
            intArrayOf(
                -20, -10, -10, -10, -10, -10, -10, -20,
                -10, 0, 0, 0, 0, 0, 0, -10,
                -10, 0, 5, 10, 10, 5, 0, -10,
                -10, 5, 5, 10, 10, 5, 5, -10,
                -10, 0, 10, 10, 10, 10, 0, -10,
                -10, 10, 10, 10, 10, 10, 10, -10,
                -10, 5, 0, 0, 0, 0, 5, -10,
                -20, -10, -10, -10, -10, -10, -10, -20
            ),
            intArrayOf(
                0, 0, 0, 0, 0, 0, 0, 0,
                5, 10, 10, 10, 10, 10, 10, 5,
                -5, 0, 0, 0, 0, 0, 0, -5,
                -5, 0, 0, 0, 0, 0, 0, -5,
                -5, 0, 0, 0, 0, 0, 0, -5,
                -5, 0, 0, 0, 0, 0, 0, -5,
                -5, 0, 0, 0, 0, 0, 0, -5,
                0, 0, 0, 5, 5, 0, 0, 0
            ),
            intArrayOf(
                -20, -10, -10, -5, -5, -10, -10, -20,
                -10, 0, 0, 0, 0, 0, 0, -10,
                -10, 0, 5, 5, 5, 5, 0, -10,
                -5, 0, 5, 5, 5, 5, 0, -5,
                0, 0, 5, 5, 5, 5, 0, -5,
                -10, 5, 5, 5, 5, 5, 0, -10,
                -10, 0, 5, 0, 0, 0, 0, -10,
                -20, -10, -10, -5, -5, -10, -10, -20
            ),
            IntArray(64)
        )
        val KING_MG = intArrayOf(
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -20, -30, -30, -40, -40, -30, -30, -20,
            -10, -20, -20, -20, -20, -20, -20, -10,
            20, 20, 0, 0, 0, 0, 20, 20,
            20, 30, 10, 0, 0, 10, 30, 20
        )
        val KING_EG = intArrayOf(
            -50, -40, -30, -20, -20, -30, -40, -50,
            -30, -20, -10, 0, 0, -10, -20, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -30, 0, 0, 0, 0, -30, -30,
            -50, -30, -30, -30, -30, -30, -30, -50
        )
    }

    private val ttKey = LongArray(TT_SIZE)
    private val ttInfo = IntArray(TT_SIZE)
    private val ttScore = IntArray(TT_SIZE)
    private val killers = Array(MAX_PLY + 2) { IntArray(2) }
    private val history = Array(2) { IntArray(64 * 64) }
    private val moveBufs = Array(MAX_PLY + 2) { IntArray(256) }
    private val scoreBufs = Array(MAX_PLY + 2) { IntArray(256) }

    private var pos = Position()
    private var nodes = 0L
    private var deadline = 0L
    private var canStop = false
    private var stopped = false
    private var rootBest = 0

    override fun analyze(pos: Position, timeMs: Long): SearchResult? {
        this.pos = pos.copy()
        val legal = this.pos.legalMoves()
        if (legal.isEmpty()) return null
        for (k in killers) { k[0] = 0; k[1] = 0 }
        for (h in history) h.fill(0)
        if (legal.size == 1) return SearchResult(legal[0], evaluate(), null, 0)

        deadline = System.nanoTime() + timeMs * 1_000_000L
        stopped = false
        canStop = false
        nodes = 0
        var best = legal[0]
        var bestScore = 0
        var doneDepth = 0
        val startNs = System.nanoTime()
        for (d in 1..40) {
            canStop = d > 1
            rootBest = 0
            val score = search(d, -INF, INF, 0, false)
            if (stopped) break
            if (rootBest != 0) best = rootBest
            bestScore = score
            doneDepth = d
            if (abs(score) >= MATE - d) break
            val used = System.nanoTime() - startNs
            if (used * 100 > timeMs * 1_000_000L * 45) break // next iteration would not finish
        }
        val mate = when {
            bestScore > MATE_BOUND -> (MATE - bestScore + 1) / 2
            bestScore < -MATE_BOUND -> -((MATE + bestScore + 1) / 2)
            else -> null
        }
        return SearchResult(best, bestScore, mate, doneDepth)
    }

    private fun timeUp(): Boolean = canStop && System.nanoTime() > deadline

    private fun search(depthIn: Int, alphaIn: Int, beta: Int, ply: Int, allowNull: Boolean): Int {
        var depth = depthIn
        var alpha = alphaIn
        if ((nodes++ and 2047L) == 0L && timeUp()) stopped = true
        if (stopped) return 0
        if (ply >= MAX_PLY - 1) return evaluate()
        val isRoot = ply == 0
        if (!isRoot) {
            if (pos.halfmove >= 100 || pos.isRepetition() || pos.insufficientMaterial()) return 0
        }
        val inCheck = pos.inCheck(pos.side)
        if (inCheck) depth++
        if (depth <= 0) return quiesce(alpha, beta, ply)

        val idx = pos.hash.toInt() and (TT_SIZE - 1)
        var ttMove = 0
        if (ttKey[idx] == pos.hash) {
            val info = ttInfo[idx]
            ttMove = info and 0x7FFF
            val td = (info shr 16) and 0xFF
            val flag = (info shr 24) and 3
            if (!isRoot && td >= depth) {
                var s = ttScore[idx]
                if (s > MATE_BOUND) s -= ply else if (s < -MATE_BOUND) s += ply
                when (flag) {
                    EXACT -> return s
                    LOWER -> if (s >= beta) return s
                    UPPER -> if (s <= alpha) return s
                }
            }
        }

        if (allowNull && !inCheck && !isRoot && depth >= 3 && beta < MATE_BOUND && pos.hasNonPawn(pos.side)) {
            pos.makeNull()
            val s = -search(depth - 3, -beta, -beta + 1, ply + 1, false)
            pos.unmakeNull()
            if (stopped) return 0
            if (s >= beta) return beta
        }

        val buf = moveBufs[ply]
        val sc = scoreBufs[ply]
        val n = pos.generate(buf, false)
        for (i in 0 until n) sc[i] = scoreMove(buf[i], ttMove, ply)

        var best = -INF
        var bestMove = 0
        var legal = 0
        var flag = UPPER
        val us = pos.side
        for (i in 0 until n) {
            var bi = i
            var bs = sc[i]
            for (j in i + 1 until n) if (sc[j] > bs) { bs = sc[j]; bi = j }
            if (bi != i) {
                val tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm
                val ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts
            }
            val m = buf[i]
            val from = m and 63
            val to = (m shr 6) and 63
            val isCapture = pos.board[to] != 0 ||
                (pos.board[from] and 7 == Piece.PAWN && to == pos.ep && (from and 7) != (to and 7))
            val quiet = !isCapture && ((m shr 12) and 7) == 0
            if (!pos.makeLegal(m)) continue
            legal++
            var score: Int
            if (legal == 1) {
                score = -search(depth - 1, -beta, -alpha, ply + 1, true)
            } else {
                var red = 0
                if (depth >= 3 && legal > 4 && quiet && !inCheck) red = 1
                score = -search(depth - 1 - red, -alpha - 1, -alpha, ply + 1, true)
                if (score > alpha && (red > 0 || score < beta)) {
                    score = -search(depth - 1, -beta, -alpha, ply + 1, true)
                }
            }
            pos.unmakeMove()
            if (stopped) return 0
            if (score > best) {
                best = score
                bestMove = m
                if (isRoot) rootBest = m
                if (score > alpha) {
                    alpha = score
                    flag = EXACT
                    if (alpha >= beta) {
                        flag = LOWER
                        if (quiet) {
                            if (killers[ply][0] != m) { killers[ply][1] = killers[ply][0]; killers[ply][0] = m }
                            history[us][from * 64 + to] += depth * depth
                        }
                        break
                    }
                }
            }
        }
        if (legal == 0) return if (inCheck) -MATE + ply else 0

        var store = best
        if (store > MATE_BOUND) store += ply else if (store < -MATE_BOUND) store -= ply
        ttKey[idx] = pos.hash
        ttScore[idx] = store
        ttInfo[idx] = bestMove or ((depth.coerceIn(0, 255)) shl 16) or (flag shl 24)
        return best
    }

    private fun quiesce(alphaIn: Int, beta: Int, ply: Int): Int {
        var alpha = alphaIn
        if ((nodes++ and 2047L) == 0L && timeUp()) stopped = true
        if (stopped) return 0
        val stand = evaluate()
        if (ply >= MAX_PLY - 1) return stand
        if (stand >= beta) return stand
        if (stand > alpha) alpha = stand
        val buf = moveBufs[ply]
        val sc = scoreBufs[ply]
        val n = pos.generate(buf, true)
        for (i in 0 until n) sc[i] = scoreMove(buf[i], 0, ply)
        for (i in 0 until n) {
            var bi = i
            var bs = sc[i]
            for (j in i + 1 until n) if (sc[j] > bs) { bs = sc[j]; bi = j }
            if (bi != i) {
                val tm = buf[i]; buf[i] = buf[bi]; buf[bi] = tm
                val ts = sc[i]; sc[i] = sc[bi]; sc[bi] = ts
            }
            val m = buf[i]
            val victim = pos.board[(m shr 6) and 63] and 7
            if (stand + VALUE[victim] + 200 < alpha && ((m shr 12) and 7) == 0) continue
            if (!pos.makeLegal(m)) continue
            val s = -quiesce(-beta, -alpha, ply + 1)
            pos.unmakeMove()
            if (stopped) return 0
            if (s > alpha) {
                alpha = s
                if (alpha >= beta) return alpha
            }
        }
        return alpha
    }

    private fun scoreMove(m: Int, ttMove: Int, ply: Int): Int {
        if (m == ttMove) return 1_000_000
        val from = m and 63
        val to = (m shr 6) and 63
        val attacker = pos.board[from] and 7
        var victim = pos.board[to] and 7
        if (victim == 0 && attacker == Piece.PAWN && to == pos.ep && (from and 7) != (to and 7)) victim = Piece.PAWN
        if (victim != 0) return 100_000 + ORDER_VALUE[victim] * 16 - ORDER_VALUE[attacker]
        val promo = (m shr 12) and 7
        if (promo != 0) return 90_000 + promo
        if (killers[ply][0] == m) return 80_000
        if (killers[ply][1] == m) return 70_000
        return history[pos.side][from * 64 + to]
    }

    /** Static evaluation in centipawns from the side to move's point of view. */
    private fun evaluate(): Int {
        val b = pos.board
        var score = 0
        var npm = 0
        var kingMg = 0
        var kingEg = 0
        val bishops = IntArray(2)
        val pawnsOn = Array(2) { IntArray(8) }
        val pawnMax = Array(2) { IntArray(8) { -1 } }
        val pawnMin = Array(2) { IntArray(8) { 8 } }
        for (sq in 0 until 64) {
            val p = b[sq]
            if (p == 0) continue
            val c = p shr 3
            val t = p and 7
            val idx = if (c == Piece.WHITE) sq xor 56 else sq
            val sign = if (c == Piece.WHITE) 1 else -1
            when (t) {
                Piece.KING -> {
                    kingMg += sign * KING_MG[idx]
                    kingEg += sign * KING_EG[idx]
                }
                Piece.PAWN -> {
                    score += sign * (VALUE[t] + PST[t][idx])
                    val f = sq and 7
                    val r = sq shr 3
                    pawnsOn[c][f]++
                    if (r > pawnMax[c][f]) pawnMax[c][f] = r
                    if (r < pawnMin[c][f]) pawnMin[c][f] = r
                }
                else -> {
                    score += sign * (VALUE[t] + PST[t][idx])
                    npm += VALUE[t]
                    if (t == Piece.BISHOP) bishops[c]++
                }
            }
        }
        if (bishops[0] >= 2) score += 30
        if (bishops[1] >= 2) score -= 30
        // pawn structure and rook files
        for (c in 0..1) {
            val sign = if (c == 0) 1 else -1
            val e = c xor 1
            for (f in 0 until 8) {
                if (pawnsOn[c][f] > 1) score -= sign * 12 * (pawnsOn[c][f] - 1)
                if (pawnsOn[c][f] == 0) continue
                // passed pawn test uses the most advanced pawn on the file
                val r = if (c == 0) pawnMax[c][f] else pawnMin[c][f]
                var passed = true
                for (g in maxOf(0, f - 1)..minOf(7, f + 1)) {
                    if (pawnsOn[e][g] == 0) continue
                    if (c == 0 && pawnMax[e][g] > r) passed = false
                    if (c == 1 && pawnMin[e][g] < r) passed = false
                }
                if (passed) {
                    val rel = if (c == 0) r else 7 - r
                    score += sign * PASSED[rel]
                }
            }
        }
        for (sq in 0 until 64) {
            val p = b[sq]
            if (p and 7 != Piece.ROOK) continue
            val c = p shr 3
            val f = sq and 7
            val sign = if (c == 0) 1 else -1
            if (pawnsOn[c][f] == 0) score += sign * (if (pawnsOn[c xor 1][f] == 0) 20 else 10)
        }
        val w = npm.coerceAtMost(5000)
        score += (kingMg * w + kingEg * (5000 - w)) / 5000
        return (if (pos.side == Piece.WHITE) score else -score) + 10
    }
}
