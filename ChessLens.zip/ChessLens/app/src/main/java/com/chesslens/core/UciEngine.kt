package com.chesslens.core

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Talks to any UCI engine binary (used for a bundled Stockfish). Returns null on any failure so callers can fall back. */
class UciEngine(
    private val exePath: String,
    private val threads: Int = 2,
    private val hashMb: Int = 32
) : MoveAdvisor {
    override val name = "Stockfish"

    private var proc: Process? = null
    private var out: BufferedWriter? = null
    private val lines = LinkedBlockingQueue<String>()

    fun start(): Boolean {
        return try {
            val p = ProcessBuilder(exePath).redirectErrorStream(true).start()
            proc = p
            out = BufferedWriter(OutputStreamWriter(p.outputStream))
            val reader = BufferedReader(InputStreamReader(p.inputStream))
            val t = Thread {
                try {
                    while (true) {
                        val l = reader.readLine() ?: break
                        lines.put(l)
                    }
                } catch (_: Exception) {
                }
            }
            t.isDaemon = true
            t.start()
            send("uci")
            if (!waitFor("uciok", 8000)) { close(); return false }
            send("setoption name Threads value $threads")
            send("setoption name Hash value $hashMb")
            send("isready")
            if (!waitFor("readyok", 8000)) { close(); return false }
            true
        } catch (e: Exception) {
            close()
            false
        }
    }

    private fun send(s: String) {
        val w = out ?: throw IllegalStateException("engine not running")
        w.write(s)
        w.write("\n")
        w.flush()
    }

    private fun waitFor(token: String, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return false
            val l = lines.poll(left, TimeUnit.MILLISECONDS) ?: return false
            if (l.trim() == token) return true
        }
    }

    override fun analyze(pos: Position, timeMs: Long): SearchResult? {
        if (proc == null) return null
        try {
            lines.clear()
            send("position fen ${pos.toFen()}")
            send("go movetime $timeMs")
            var depth = 0
            var cp = 0
            var mate: Int? = null
            val end = System.currentTimeMillis() + timeMs + 5000
            while (true) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) { close(); return null }
                val l = lines.poll(left, TimeUnit.MILLISECONDS)
                if (l == null) { close(); return null }
                if (l.startsWith("info ") && " score " in l) {
                    val tk = l.split(' ')
                    var i = 0
                    while (i < tk.size - 1) {
                        if (tk[i] == "depth") {
                            depth = tk[i + 1].toIntOrNull() ?: depth
                        } else if (tk[i] == "score" && i + 2 < tk.size) {
                            val v = tk[i + 2].toIntOrNull()
                            if (tk[i + 1] == "cp" && v != null) { cp = v; mate = null }
                            if (tk[i + 1] == "mate" && v != null) {
                                mate = v
                                cp = if (v > 0) 30000 - v else -30000 - v
                            }
                        }
                        i++
                    }
                } else if (l.startsWith("bestmove")) {
                    val mv = l.split(' ').getOrNull(1) ?: return null
                    if (mv == "(none)" || mv == "0000") return null
                    val m = pos.parseUci(mv)
                    if (m < 0) return null
                    return SearchResult(m, cp, mate, depth)
                }
            }
        } catch (e: Exception) {
            close()
            return null
        }
    }

    override fun close() {
        try { out?.write("quit\n"); out?.flush() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null
        out = null
    }
}
