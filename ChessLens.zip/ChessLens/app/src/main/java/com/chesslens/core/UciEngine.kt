package com.chesslens.core

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Talks to any UCI engine binary (used for a bundled Stockfish). Returns null on any failure so callers can fall back. */
class UciEngine(
    private val exePath: String,
    private val threads: Int = 2,
    private val hashMb: Int = 32
) : MoveAdvisor {
    override val name = "Stockfish"

    /** Why the last call returned null, for showing to the user. */
    @Volatile var lastError = ""
    private var proc: Process? = null
    private var out: BufferedWriter? = null
    private val lines = LinkedBlockingQueue<String>()

    fun start(): Boolean {
        return try {
            val p = ProcessBuilder(exePath).redirectErrorStream(true).start()
            proc = p
            out = BufferedWriter(OutputStreamWriter(p.outputStream))
            val reader = BufferedReader(InputStreamReader(p.inputStream))
            val t = Thread {
                try {
                    while (true) {
                        val l = reader.readLine() ?: break
                        lines.put(l)
                    }
                } catch (_: Exception) {
                }
            }
            t.isDaemon = true
            t.start()
            send("uci")
            if (!waitFor("uciok", 8000)) { close(); return false }
            send("setoption name Threads value $threads")
            send("setoption name Hash value $hashMb")
            send("isready")
            if (!waitFor("readyok", 8000)) { close(); return false }
            true
        } catch (e: Exception) {
            close()
            false
        }
    }

    private fun send(s: String) {
        synchronized(this) {
            val w = out ?: throw IllegalStateException("engine not running")
            w.write(s)
            w.write("\n")
            w.flush()
        }
    }

    @Volatile private var wantPv = 1
    @Volatile private var wantElo = 0
    private var sentPv = 1
    private var sentElo = 0

    override fun configure(multiPv: Int, elo: Int) {
        wantPv = multiPv.coerceIn(1, 5)
        wantElo = if (elo <= 0) 0 else elo.coerceIn(1320, 3190)
    }

    /** Sends changed options right before a search (the search thread is the only caller, so nothing interleaves). */
    private fun applyOptions() {
        if (wantPv != sentPv) { send("setoption name MultiPV value $wantPv"); sentPv = wantPv }
        if (wantElo != sentElo) {
            if (wantElo == 0) send("setoption name UCI_LimitStrength value false")
            else { send("setoption name UCI_LimitStrength value true"); send("setoption name UCI_Elo value $wantElo") }
            sentElo = wantElo
        }
    }

    private fun waitFor(token: String, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return false
            val l = lines.poll(left, TimeUnit.MILLISECONDS) ?: return false
            if (l.trim() == token) return true
        }
    }

    override fun analyze(pos: Position, timeMs: Long): SearchResult? {
        if (proc == null) { lastError = "Stockfish ไม่ได้ทำงานอยู่"; return null }
        try {
            lines.clear()
            applyOptions()
            send("position fen ${pos.toFen()}")
            send("go movetime $timeMs")
            val lineCp = IntArray(6)
            val lineMate = arrayOfNulls<Int>(6)
            val lineMove = arrayOfNulls<String>(6)
            val lineDepth = IntArray(6)
            val end = System.currentTimeMillis() + timeMs + 5000
            while (true) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) { lastError = "Stockfish ไม่ตอบ (หมดเวลา)"; close(); return null }
                val l = lines.poll(left, TimeUnit.MILLISECONDS)
                if (l == null) { lastError = "Stockfish ไม่ตอบ"; close(); return null }
                if (l.startsWith("info ") && " score " in l && " pv " in l) {
                    val tk = l.split(' ')
                    var k = 1
                    var depth = 0
                    var cp = 0
                    var mate: Int? = null
                    var move: String? = null
                    var i = 0
                    while (i < tk.size - 1) {
                        when (tk[i]) {
                            "multipv" -> k = (tk[i + 1].toIntOrNull() ?: 1).coerceIn(1, 5)
                            "depth" -> depth = tk[i + 1].toIntOrNull() ?: depth
                            "score" -> if (i + 2 < tk.size) {
                                val v = tk[i + 2].toIntOrNull()
                                if (tk[i + 1] == "cp" && v != null) { cp = v; mate = null }
                                if (tk[i + 1] == "mate" && v != null) {
                                    mate = v
                                    cp = if (v > 0) 30000 - v else -30000 - v
                                }
                            }
                            "pv" -> { move = tk[i + 1]; i = tk.size }
                        }
                        i++
                    }
                    if (move != null) {
                        lineCp[k] = cp; lineMate[k] = mate; lineMove[k] = move; lineDepth[k] = depth
                    }
                } else if (l.startsWith("bestmove")) {
                    val mv = l.split(' ').getOrNull(1) ?: return null
                    if (mv == "(none)" || mv == "0000") { lastError = "Stockfish ว่าไม่มีตาเดิน (ตำแหน่งที่อ่านอาจผิด)"; return null }
                    val m = pos.parseUci(mv)
                    if (m < 0) { lastError = "ตาเดิน $mv ของ Stockfish ไม่ตรงกับกฎที่แอปรู้ (ตำแหน่งที่อ่านอาจผิด)"; return null }
                    var main = 1
                    for (k in 1..5) if (lineMove[k] == mv) { main = k; break }
                    val others = ArrayList<SearchResult>()
                    for (k in 1..5) {
                        val s = lineMove[k] ?: continue
                        if (s == mv) continue
                        val om = pos.parseUci(s)
                        if (om >= 0 && others.size < wantPv - 1) others.add(SearchResult(om, lineCp[k], lineMate[k], lineDepth[k]))
                    }
                    return SearchResult(m, lineCp[main], lineMate[main], lineDepth[main], others)
                }
            }
        } catch (e: Exception) {
            lastError = "Stockfish ขัดข้อง: ${e.javaClass.simpleName}"
            close()
            return null
        }
    }

    override fun close() {
        try { out?.write("quit\n"); out?.flush() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
        proc = null
        out = null
    }
}
