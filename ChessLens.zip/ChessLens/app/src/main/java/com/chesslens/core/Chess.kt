package com.chesslens.core

import java.util.Random

/** Piece codes: white = 1..6, black = 9..14 (type | color shl 3). Squares: a1 = 0, h1 = 7, a8 = 56, h8 = 63. */
object Piece {
    const val EMPTY = 0
    const val PAWN = 1
    const val KNIGHT = 2
    const val BISHOP = 3
    const val ROOK = 4
    const val QUEEN = 5
    const val KING = 6
    const val WHITE = 0
    const val BLACK = 1

    fun make(color: Int, type: Int) = type or (color shl 3)
    fun color(p: Int) = p shr 3
    fun type(p: Int) = p and 7

    private const val CHARS = " PNBRQK"

    fun toChar(p: Int): Char {
        if (p == EMPTY) return '.'
        val c = CHARS[type(p)]
        return if (color(p) == WHITE) c else c.lowercaseChar()
    }

    /** Returns -1 when the character is not a piece letter. */
    fun fromChar(c: Char): Int {
        val t = CHARS.indexOf(c.uppercaseChar())
        if (t <= 0) return -1
        return make(if (c.isUpperCase()) WHITE else BLACK, t)
    }
}

object Moves {
    fun make(from: Int, to: Int, promo: Int = 0) = from or (to shl 6) or (promo shl 12)
    fun from(m: Int) = m and 63
    fun to(m: Int) = (m shr 6) and 63
    fun promo(m: Int) = (m shr 12) and 7

    fun squareName(sq: Int): String = "${'a' + (sq and 7)}${(sq shr 3) + 1}"

    fun uci(m: Int): String {
        val p = promo(m)
        return squareName(from(m)) + squareName(to(m)) + if (p != 0) "  nbrq"[p].toString().trim() else ""
    }
}

internal object Tables {
    val knight = Array(64) { IntArray(0) }
    val king = Array(64) { IntArray(0) }

    /** rays[dir][sq]; dirs 0..3 are orthogonal, 4..7 diagonal. */
    val rays = Array(8) { Array(64) { IntArray(0) } }
    private val DF = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)
    private val DR = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)

    val pieceKey = Array(16) { LongArray(64) }
    val castleKey = LongArray(16)
    val epKey = LongArray(8)
    val sideKey: Long
    val castleMask = IntArray(64) { 15 }

    init {
        val kn = intArrayOf(1, 2, 2, 1, -1, 2, -2, 1, 1, -2, 2, -1, -1, -2, -2, -1)
        for (sq in 0 until 64) {
            val f = sq and 7
            val r = sq shr 3
            val kl = ArrayList<Int>()
            var i = 0
            while (i < kn.size) {
                val nf = f + kn[i]
                val nr = r + kn[i + 1]
                if (nf in 0..7 && nr in 0..7) kl.add(nr * 8 + nf)
                i += 2
            }
            knight[sq] = kl.toIntArray()
            val kg = ArrayList<Int>()
            for (df in -1..1) for (dr in -1..1) {
                if (df == 0 && dr == 0) continue
                val nf = f + df
                val nr = r + dr
                if (nf in 0..7 && nr in 0..7) kg.add(nr * 8 + nf)
            }
            king[sq] = kg.toIntArray()
            for (d in 0 until 8) {
                val rl = ArrayList<Int>()
                var cf = f + DF[d]
                var cr = r + DR[d]
                while (cf in 0..7 && cr in 0..7) {
                    rl.add(cr * 8 + cf)
                    cf += DF[d]
                    cr += DR[d]
                }
                rays[d][sq] = rl.toIntArray()
            }
        }
        val rnd = Random(0x5DEECE66DL)
        for (p in 0 until 16) for (s in 0 until 64) pieceKey[p][s] = rnd.nextLong()
        for (i in 0 until 16) castleKey[i] = rnd.nextLong()
        for (i in 0 until 8) epKey[i] = rnd.nextLong()
        sideKey = rnd.nextLong()
        castleMask[0] = 13
        castleMask[4] = 12
        castleMask[7] = 14
        castleMask[56] = 7
        castleMask[60] = 3
        castleMask[63] = 11
    }
}

class Position {
    val board = IntArray(64)
    var side = Piece.WHITE
    /** Bits: 1 = white O-O, 2 = white O-O-O, 4 = black O-O, 8 = black O-O-O. */
    var castle = 0
    var ep = -1
    var halfmove = 0
    var fullmove = 1
    var hash = 0L
    val kingSq = intArrayOf(-1, -1)

    private var cap = 256
    private var sp = 0
    private var uMove = IntArray(cap)
    private var uCaptured = IntArray(cap)
    private var uCapSq = IntArray(cap)
    private var uCastle = IntArray(cap)
    private var uEp = IntArray(cap)
    private var uHalf = IntArray(cap)
    private var uHash = LongArray(cap)
    private var hashStack = LongArray(cap + 1)

    private fun ensure() {
        if (sp + 2 >= cap) {
            cap *= 2
            uMove = uMove.copyOf(cap)
            uCaptured = uCaptured.copyOf(cap)
            uCapSq = uCapSq.copyOf(cap)
            uCastle = uCastle.copyOf(cap)
            uEp = uEp.copyOf(cap)
            uHalf = uHalf.copyOf(cap)
            uHash = uHash.copyOf(cap)
            hashStack = hashStack.copyOf(cap + 1)
        }
    }

    fun computeHash(): Long {
        var h = 0L
        for (s in 0 until 64) {
            val p = board[s]
            if (p != 0) h = h xor Tables.pieceKey[p][s]
        }
        h = h xor Tables.castleKey[castle]
        if (ep >= 0) h = h xor Tables.epKey[ep and 7]
        if (side == Piece.BLACK) h = h xor Tables.sideKey
        return h
    }

    /** Call after filling board/side/castle/ep. Resets the move history. */
    fun finishSetup() {
        kingSq[0] = -1
        kingSq[1] = -1
        for (s in 0 until 64) {
            val p = board[s]
            if (p and 7 == Piece.KING) kingSq[p shr 3] = s
        }
        hash = computeHash()
        sp = 0
        hashStack[0] = hash
    }

    fun copy(): Position {
        val c = Position()
        System.arraycopy(board, 0, c.board, 0, 64)
        c.side = side
        c.castle = castle
        c.ep = ep
        c.halfmove = halfmove
        c.fullmove = fullmove
        c.hash = hash
        c.kingSq[0] = kingSq[0]
        c.kingSq[1] = kingSq[1]
        c.cap = cap
        c.sp = sp
        c.uMove = uMove.copyOf()
        c.uCaptured = uCaptured.copyOf()
        c.uCapSq = uCapSq.copyOf()
        c.uCastle = uCastle.copyOf()
        c.uEp = uEp.copyOf()
        c.uHalf = uHalf.copyOf()
        c.uHash = uHash.copyOf()
        c.hashStack = hashStack.copyOf()
        return c
    }

    fun setSideToMove(color: Int) {
        side = color
        ep = -1
        finishSetup()
    }

    fun makeMove(m: Int) {
        ensure()
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        val piece = board[from]
        val color = piece shr 3
        val type = piece and 7
        var captured = board[to]
        var capSq = to
        uMove[sp] = m
        uCastle[sp] = castle
        uEp[sp] = ep
        uHalf[sp] = halfmove
        uHash[sp] = hash
        var h = hash
        if (ep >= 0) h = h xor Tables.epKey[ep and 7]
        h = h xor Tables.castleKey[castle]
        if (type == Piece.PAWN && to == ep && captured == 0 && (from and 7) != (to and 7)) {
            capSq = if (color == Piece.WHITE) to - 8 else to + 8
            captured = board[capSq]
            board[capSq] = 0
            h = h xor Tables.pieceKey[captured][capSq]
        } else if (captured != 0) {
            h = h xor Tables.pieceKey[captured][to]
        }
        uCaptured[sp] = captured
        uCapSq[sp] = capSq
        board[from] = 0
        h = h xor Tables.pieceKey[piece][from]
        val placed = if (promo != 0) (promo or (color shl 3)) else piece
        board[to] = placed
        h = h xor Tables.pieceKey[placed][to]
        if (type == Piece.KING) {
            kingSq[color] = to
            if (to - from == 2) {
                val rook = board[from + 3]
                board[from + 3] = 0
                board[from + 1] = rook
                h = h xor Tables.pieceKey[rook][from + 3] xor Tables.pieceKey[rook][from + 1]
            } else if (from - to == 2) {
                val rook = board[from - 4]
                board[from - 4] = 0
                board[from - 1] = rook
                h = h xor Tables.pieceKey[rook][from - 4] xor Tables.pieceKey[rook][from - 1]
            }
        }
        castle = castle and Tables.castleMask[from] and Tables.castleMask[to]
        ep = if (type == Piece.PAWN && (to - from == 16 || from - to == 16)) (from + to) / 2 else -1
        h = h xor Tables.castleKey[castle]
        if (ep >= 0) h = h xor Tables.epKey[ep and 7]
        halfmove = if (type == Piece.PAWN || captured != 0) 0 else halfmove + 1
        if (color == Piece.BLACK) fullmove++
        side = side xor 1
        h = h xor Tables.sideKey
        hash = h
        sp++
        hashStack[sp] = h
    }

    fun unmakeMove() {
        sp--
        val m = uMove[sp]
        val from = m and 63
        val to = (m shr 6) and 63
        val promo = (m shr 12) and 7
        val color = side xor 1
        val placed = board[to]
        val orig = if (promo != 0) Piece.make(color, Piece.PAWN) else placed
        board[from] = orig
        board[to] = 0
        val captured = uCaptured[sp]
        if (captured != 0) board[uCapSq[sp]] = captured
        if (orig and 7 == Piece.KING) {
            kingSq[color] = from
            if (to - from == 2) {
                val rook = board[from + 1]
                board[from + 1] = 0
                board[from + 3] = rook
            } else if (from - to == 2) {
                val rook = board[from - 1]
                board[from - 1] = 0
                board[from - 4] = rook
            }
        }
        castle = uCastle[sp]
        ep = uEp[sp]
        halfmove = uHalf[sp]
        hash = uHash[sp]
        side = color
        if (color == Piece.BLACK) fullmove--
    }

    fun makeNull() {
        ensure()
        uMove[sp] = 0
        uCaptured[sp] = 0
        uCapSq[sp] = 0
        uCastle[sp] = castle
        uEp[sp] = ep
        uHalf[sp] = halfmove
        uHash[sp] = hash
        var h = hash
        if (ep >= 0) h = h xor Tables.epKey[ep and 7]
        ep = -1
        h = h xor Tables.sideKey
        side = side xor 1
        halfmove++
        hash = h
        sp++
        hashStack[sp] = h
    }

    fun unmakeNull() {
        sp--
        ep = uEp[sp]
        halfmove = uHalf[sp]
        hash = uHash[sp]
        side = side xor 1
    }

    fun isAttacked(sq: Int, by: Int): Boolean {
        val f = sq and 7
        val r = sq shr 3
        if (by == Piece.WHITE) {
            if (r > 0) {
                if (f > 0 && board[sq - 9] == WP) return true
                if (f < 7 && board[sq - 7] == WP) return true
            }
        } else {
            if (r < 7) {
                if (f > 0 && board[sq + 7] == BP) return true
                if (f < 7 && board[sq + 9] == BP) return true
            }
        }
        val kn = Piece.make(by, Piece.KNIGHT)
        for (t in Tables.knight[sq]) if (board[t] == kn) return true
        val kg = Piece.make(by, Piece.KING)
        for (t in Tables.king[sq]) if (board[t] == kg) return true
        val rk = Piece.make(by, Piece.ROOK)
        val bs = Piece.make(by, Piece.BISHOP)
        val qn = Piece.make(by, Piece.QUEEN)
        for (d in 0 until 4) {
            for (t in Tables.rays[d][sq]) {
                val p = board[t]
                if (p != 0) {
                    if (p == rk || p == qn) return true
                    break
                }
            }
        }
        for (d in 4 until 8) {
            for (t in Tables.rays[d][sq]) {
                val p = board[t]
                if (p != 0) {
                    if (p == bs || p == qn) return true
                    break
                }
            }
        }
        return false
    }

    fun inCheck(color: Int = side): Boolean = kingSq[color] >= 0 && isAttacked(kingSq[color], color xor 1)

    /** Pseudo-legal move generation. Returns the number of moves written to [buf]. */
    fun generate(buf: IntArray, capturesOnly: Boolean): Int {
        var n = 0
        val us = side
        val them = us xor 1
        for (from in 0 until 64) {
            val p = board[from]
            if (p == 0 || (p shr 3) != us) continue
            when (p and 7) {
                Piece.PAWN -> n = genPawn(from, us, them, buf, n, capturesOnly)
                Piece.KNIGHT -> for (t in Tables.knight[from]) {
                    val q = board[t]
                    if (q == 0) {
                        if (!capturesOnly) buf[n++] = from or (t shl 6)
                    } else if ((q shr 3) == them) buf[n++] = from or (t shl 6)
                }
                Piece.BISHOP -> n = genSlide(from, 4, 8, them, buf, n, capturesOnly)
                Piece.ROOK -> n = genSlide(from, 0, 4, them, buf, n, capturesOnly)
                Piece.QUEEN -> n = genSlide(from, 0, 8, them, buf, n, capturesOnly)
                Piece.KING -> {
                    for (t in Tables.king[from]) {
                        val q = board[t]
                        if (q == 0) {
                            if (!capturesOnly) buf[n++] = from or (t shl 6)
                        } else if ((q shr 3) == them) buf[n++] = from or (t shl 6)
                    }
                    if (!capturesOnly) n = genCastle(from, us, them, buf, n)
                }
            }
        }
        return n
    }

    private fun genSlide(from: Int, d0: Int, d1: Int, them: Int, buf: IntArray, nIn: Int, capturesOnly: Boolean): Int {
        var n = nIn
        for (d in d0 until d1) {
            for (t in Tables.rays[d][from]) {
                val q = board[t]
                if (q == 0) {
                    if (!capturesOnly) buf[n++] = from or (t shl 6)
                } else {
                    if ((q shr 3) == them) buf[n++] = from or (t shl 6)
                    break
                }
            }
        }
        return n
    }

    private fun genPawn(from: Int, us: Int, them: Int, buf: IntArray, nIn: Int, capturesOnly: Boolean): Int {
        var n = nIn
        val dir = if (us == Piece.WHITE) 8 else -8
        val startRank = if (us == Piece.WHITE) 1 else 6
        val promoRank = if (us == Piece.WHITE) 7 else 0
        val f = from and 7
        val r = from shr 3
        val one = from + dir
        if (board[one] == 0) {
            if ((one shr 3) == promoRank) {
                for (pr in intArrayOf(Piece.QUEEN, Piece.KNIGHT, Piece.ROOK, Piece.BISHOP)) {
                    if (capturesOnly && pr != Piece.QUEEN) continue
                    buf[n++] = from or (one shl 6) or (pr shl 12)
                }
            } else if (!capturesOnly) {
                buf[n++] = from or (one shl 6)
                if (r == startRank && board[one + dir] == 0) buf[n++] = from or ((one + dir) shl 6)
            }
        }
        for (df in intArrayOf(-1, 1)) {
            val nf = f + df
            if (nf < 0 || nf > 7) continue
            val t = one + df
            val q = board[t]
            if (q != 0 && (q shr 3) == them) {
                if ((t shr 3) == promoRank) {
                    for (pr in intArrayOf(Piece.QUEEN, Piece.KNIGHT, Piece.ROOK, Piece.BISHOP)) {
                        if (capturesOnly && pr != Piece.QUEEN) continue
                        buf[n++] = from or (t shl 6) or (pr shl 12)
                    }
                } else buf[n++] = from or (t shl 6)
            } else if (q == 0 && t == ep) {
                buf[n++] = from or (t shl 6)
            }
        }
        return n
    }

    private fun genCastle(from: Int, us: Int, them: Int, buf: IntArray, nIn: Int): Int {
        var n = nIn
        if (us == Piece.WHITE && from == 4) {
            if ((castle and 1) != 0 && board[5] == 0 && board[6] == 0 && board[7] == WR &&
                !isAttacked(4, them) && !isAttacked(5, them)
            ) buf[n++] = 4 or (6 shl 6)
            if ((castle and 2) != 0 && board[3] == 0 && board[2] == 0 && board[1] == 0 && board[0] == WR &&
                !isAttacked(4, them) && !isAttacked(3, them)
            ) buf[n++] = 4 or (2 shl 6)
        } else if (us == Piece.BLACK && from == 60) {
            if ((castle and 4) != 0 && board[61] == 0 && board[62] == 0 && board[63] == BR &&
                !isAttacked(60, them) && !isAttacked(61, them)
            ) buf[n++] = 60 or (62 shl 6)
            if ((castle and 8) != 0 && board[59] == 0 && board[58] == 0 && board[57] == 0 && board[56] == BR &&
                !isAttacked(60, them) && !isAttacked(59, them)
            ) buf[n++] = 60 or (58 shl 6)
        }
        return n
    }

    /** Makes [m]; if it leaves the mover's king in check the move is undone and false is returned. */
    fun makeLegal(m: Int): Boolean {
        val us = side
        makeMove(m)
        if (kingSq[us] >= 0 && isAttacked(kingSq[us], us xor 1)) {
            unmakeMove()
            return false
        }
        return true
    }

    fun legalMoves(): IntArray {
        val buf = IntArray(256)
        val n = generate(buf, false)
        val out = IntArray(n)
        var k = 0
        for (i in 0 until n) {
            if (makeLegal(buf[i])) {
                unmakeMove()
                out[k++] = buf[i]
            }
        }
        return out.copyOf(k)
    }

    fun isRepetition(): Boolean {
        var i = sp - 2
        val limit = maxOf(0, sp - halfmove)
        while (i >= limit) {
            if (hashStack[i] == hash) return true
            i -= 2
        }
        return false
    }

    fun hasNonPawn(color: Int): Boolean {
        for (s in 0 until 64) {
            val p = board[s]
            if (p != 0 && (p shr 3) == color) {
                val t = p and 7
                if (t != Piece.PAWN && t != Piece.KING) return true
            }
        }
        return false
    }

    fun insufficientMaterial(): Boolean {
        var minors = 0
        for (s in 0 until 64) {
            when (board[s] and 7) {
                Piece.PAWN, Piece.ROOK, Piece.QUEEN -> return false
                Piece.KNIGHT, Piece.BISHOP -> minors++
            }
        }
        return minors <= 1
    }

    fun perft(depth: Int): Long {
        if (depth == 0) return 1
        val buf = IntArray(256)
        val n = generate(buf, false)
        var total = 0L
        for (i in 0 until n) {
            if (makeLegal(buf[i])) {
                total += if (depth == 1) 1 else perft(depth - 1)
                unmakeMove()
            }
        }
        return total
    }

    /** The legal move matching a UCI string such as "e2e4" or "e7e8q", or -1. */
    fun parseUci(s: String): Int {
        for (m in legalMoves()) if (Moves.uci(m) == s) return m
        return -1
    }

    fun placementEquals(other: IntArray): Boolean = board.contentEquals(other)

    fun toFen(): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var empty = 0
            for (f in 0 until 8) {
                val p = board[r * 8 + f]
                if (p == 0) empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(Piece.toChar(p))
                }
            }
            if (empty > 0) sb.append(empty)
            if (r > 0) sb.append('/')
        }
        sb.append(if (side == Piece.WHITE) " w " else " b ")
        if (castle == 0) sb.append('-') else {
            if (castle and 1 != 0) sb.append('K')
            if (castle and 2 != 0) sb.append('Q')
            if (castle and 4 != 0) sb.append('k')
            if (castle and 8 != 0) sb.append('q')
        }
        sb.append(' ')
        sb.append(if (ep >= 0) Moves.squareName(ep) else "-")
        sb.append(' ').append(halfmove).append(' ').append(fullmove)
        return sb.toString()
    }

    companion object {
        private val WP = Piece.make(Piece.WHITE, Piece.PAWN)
        private val BP = Piece.make(Piece.BLACK, Piece.PAWN)
        private val WR = Piece.make(Piece.WHITE, Piece.ROOK)
        private val BR = Piece.make(Piece.BLACK, Piece.ROOK)

        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun start(): Position = fromFen(START_FEN)!!

        fun fromFen(fen: String): Position? {
            val parts = fen.trim().split(Regex("\\s+"))
            if (parts.size < 4) return null
            val p = Position()
            val rows = parts[0].split('/')
            if (rows.size != 8) return null
            for ((i, row) in rows.withIndex()) {
                val rank = 7 - i
                var file = 0
                for (c in row) {
                    if (c.isDigit()) file += c - '0' else {
                        val pc = Piece.fromChar(c)
                        if (pc < 0 || file > 7) return null
                        p.board[rank * 8 + file] = pc
                        file++
                    }
                }
                if (file != 8) return null
            }
            p.side = if (parts[1] == "b") Piece.BLACK else Piece.WHITE
            var c = 0
            for (ch in parts[2]) when (ch) {
                'K' -> c = c or 1
                'Q' -> c = c or 2
                'k' -> c = c or 4
                'q' -> c = c or 8
            }
            p.castle = c
            p.ep = if (parts[3] == "-" || parts[3].length != 2) -1 else (parts[3][1] - '1') * 8 + (parts[3][0] - 'a')
            p.halfmove = parts.getOrNull(4)?.toIntOrNull() ?: 0
            p.fullmove = parts.getOrNull(5)?.toIntOrNull() ?: 1
            p.finishSetup()
            return p
        }

        /** Castling rights that are plausible for a bare piece placement (king and rook on their home squares). */
        fun inferCastle(b: IntArray): Int {
            var c = 0
            if (b[4] == Piece.make(Piece.WHITE, Piece.KING)) {
                if (b[7] == WR) c = c or 1
                if (b[0] == WR) c = c or 2
            }
            if (b[60] == Piece.make(Piece.BLACK, Piece.KING)) {
                if (b[63] == BR) c = c or 4
                if (b[56] == BR) c = c or 8
            }
            return c
        }

        fun fromBoard(b: IntArray, side: Int, castle: Int = inferCastle(b)): Position {
            val p = Position()
            System.arraycopy(b, 0, p.board, 0, 64)
            p.side = side
            p.castle = castle
            p.ep = -1
            p.finishSetup()
            return p
        }

        fun startBoard(): IntArray = start().board.copyOf()
    }
}
