package com.chesslens.core

import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.Base64

/** Licence token checking with no Android dependencies, so it can be tested on a plain JVM. */
object LicenseCore {
    class Token(val key: String, val device: String, val exp: Long, val iat: Long)

    enum class State { VALID, EXPIRED, NEEDS_ONLINE, INVALID }

    const val OFFLINE_GRACE_MS = 24L * 3600 * 1000

    private fun field(s: String, name: String): String? =
        Regex("\"" + name + "\"\\s*:\\s*(\"([^\"]*)\"|-?[0-9]+|true|false)").find(s)?.let { it.groupValues[2].ifEmpty { it.groupValues[1] } }

    fun jsonString(s: String, name: String): String? = field(s, name)
    fun jsonLong(s: String, name: String): Long? = field(s, name)?.toLongOrNull()
    fun jsonBool(s: String, name: String): Boolean? = field(s, name)?.let { it == "true" }

    /** Signature produced by WebCrypto is raw r||s (64 bytes); Java wants DER. */
    fun rawToDer(raw: ByteArray): ByteArray {
        require(raw.size == 64)
        fun enc(b: ByteArray): ByteArray {
            var i = 0
            while (i < b.size - 1 && b[i].toInt() == 0) i++
            var v = b.copyOfRange(i, b.size)
            if (v[0] < 0) v = byteArrayOf(0) + v
            return byteArrayOf(0x02, v.size.toByte()) + v
        }
        val r = enc(raw.copyOfRange(0, 32))
        val s = enc(raw.copyOfRange(32, 64))
        return byteArrayOf(0x30, (r.size + s.size).toByte()) + r + s
    }

    /** True when [token] carries a valid signature from [spkiB64] (whoever it is for). */
    fun signatureOk(token: String, spkiB64: String): Boolean {
        return try {
            val dot = token.indexOf('.')
            if (dot <= 0) return false
            val sig = Base64.getUrlDecoder().decode(token.substring(dot + 1))
            if (sig.size != 64) return false
            val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.getDecoder().decode(spkiB64)))
            val v = Signature.getInstance("SHA256withECDSA")
            v.initVerify(pub)
            v.update(token.substring(0, dot).toByteArray(Charsets.UTF_8))
            v.verify(rawToDer(sig))
        } catch (e: Exception) {
            false
        }
    }

    /** Returns the token only if the signature is valid for [spkiB64] and it belongs to [device]. */
    fun parse(token: String, spkiB64: String, device: String): Token? {
        return try {
            val dot = token.indexOf('.')
            if (dot <= 0) return null
            val body = token.substring(0, dot)
            val sig = Base64.getUrlDecoder().decode(token.substring(dot + 1))
            if (sig.size != 64) return null
            val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.getDecoder().decode(spkiB64)))
            val v = Signature.getInstance("SHA256withECDSA")
            v.initVerify(pub)
            v.update(body.toByteArray(Charsets.UTF_8))
            if (!v.verify(rawToDer(sig))) return null
            val json = String(Base64.getUrlDecoder().decode(body), Charsets.UTF_8)
            val t = Token(
                jsonString(json, "k") ?: return null,
                jsonString(json, "d") ?: return null,
                jsonLong(json, "exp") ?: return null,
                jsonLong(json, "iat") ?: return null
            )
            if (t.device != device) null else t
        } catch (e: Exception) {
            null
        }
    }

    /**
     * [lastOkLocal] is the phone clock when the server last confirmed the key. Offline use is allowed for a day,
     * and not at all if the clock was set back behind that moment.
     */
    fun state(t: Token?, nowLocal: Long, lastOkLocal: Long): State {
        if (t == null) return State.INVALID
        if (nowLocal >= t.exp) return State.EXPIRED
        if (nowLocal < lastOkLocal - 5 * 60_000L) return State.NEEDS_ONLINE
        if (nowLocal - lastOkLocal > OFFLINE_GRACE_MS) return State.NEEDS_ONLINE
        return State.VALID
    }
}
