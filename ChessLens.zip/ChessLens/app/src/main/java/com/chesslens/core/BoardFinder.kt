package com.chesslens.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.sqrt

/** A board found on the screen: top-left corner and side length in screen pixels. */
class FoundBoard(val x: Int, val y: Int, val size: Int, val score: Double)

/**
 * Finds an 8x8 chess board anywhere on a screenshot without knowing what the pieces look like.
 *
 * A board is a regular grid where the colour alternates from square to square. At each of the 49 inner grid
 * corners the four small patches around the corner satisfy  topLeft + bottomRight - topRight - bottomLeft = +-V
 * with the sign flipping from corner to corner, so summing the 49 corners with alternating signs adds up
 * coherently only for a real board. The patches hug the corner (not the whole square), so the pieces in the
 * middle of the squares do not disturb it. A coarse search over position and size is followed by a refinement
 * at full resolution.
 */
object BoardFinder {
    private const val COARSE_TARGET = 480
    private const val MIN_BOARD_FRACTION = 0.30
    private const val T_MIN = 30
    private const val MIN_SCORE = 18.0
    private const val MIN_COHERENCE = 0.70

    /** Packed RGB (0xRRGGBB) of the pixel at (x, y). */
    fun interface Pixels {
        fun at(x: Int, y: Int): Int
    }

    fun find(width: Int, height: Int, pixel: Pixels): FoundBoard? {
        val k = ceil(maxOf(width, height) / COARSE_TARGET.toDouble()).toInt().coerceAtLeast(1)
        val cw = width / k
        val ch = height / k
        if (cw < 40 || ch < 40) return null
        val w1 = cw + 1
        // integral images of the coarse picture, one per colour channel
        val integral = Array(3) { IntArray(w1 * (ch + 1)) }
        for (cy in 0 until ch) {
            val rowSum = IntArray(3)
            for (cx in 0 until cw) {
                var r = 0
                var g = 0
                var b = 0
                for (q in 0 until 4) {
                    val px = ((cx + 0.25 + 0.5 * (q and 1)) * k).toInt().coerceIn(0, width - 1)
                    val py = ((cy + 0.25 + 0.5 * (q shr 1)) * k).toInt().coerceIn(0, height - 1)
                    val c = pixel.at(px, py)
                    r += (c shr 16) and 255
                    g += (c shr 8) and 255
                    b += c and 255
                }
                rowSum[0] += r / 4
                rowSum[1] += g / 4
                rowSum[2] += b / 4
                val idx = (cy + 1) * w1 + cx + 1
                for (c in 0 until 3) integral[c][idx] = integral[c][idx - w1] + rowSum[c]
            }
        }

        val minDim = minOf(width, height)
        val sMin = maxOf(6, Math.round(MIN_BOARD_FRACTION * minDim / 8 / k).toInt())
        val sMax = minOf((cw - 2) / 8, (ch - 2) / 8, Math.round(1.0 * minDim / 8 / k).toInt())
        if (sMax < sMin) return null

        val tMap = Array(3) { IntArray(cw * ch) }
        var bestScore = 0.0
        var bx = 0
        var by = 0
        var bs = 0
        for (s in sMin..sMax) {
            val t = maxOf(2, (s * 0.35).toInt())
            val area = t * t
            // checker response at every possible inner corner for this square size
            for (vy in s..ch - s) for (vx in s..cw - s) {
                if (vx - t < 0 || vy - t < 0 || vx + t > cw || vy + t > ch) continue
                for (c in 0 until 3) {
                    val ii = integral[c]
                    val a = block(ii, w1, vx - t, vy - t, vx, vy)
                    val b = block(ii, w1, vx, vy - t, vx + t, vy)
                    val cc = block(ii, w1, vx - t, vy, vx, vy + t)
                    val d = block(ii, w1, vx, vy, vx + t, vy + t)
                    tMap[c][vy * cw + vx] = (a + d - b - cc) / area
                }
            }
            for (y0 in s..ch - 7 * s) for (x0 in s..cw - 7 * s) {
                if (!plausible(tMap, cw, x0, y0, s)) continue
                val sc = latticeScore(bestScore) { i, j, out ->
                    val idx = (y0 + j * s) * cw + x0 + i * s
                    out[0] = tMap[0][idx]
                    out[1] = tMap[1][idx]
                    out[2] = tMap[2][idx]
                }
                if (sc > bestScore) {
                    bestScore = sc
                    bx = x0
                    by = y0
                    bs = s
                }
            }
        }
        if (bs == 0 || bestScore < MIN_SCORE) return null
        return refine(width, height, pixel, bx * k, by * k, bs * k, k)
    }

    private fun block(ii: IntArray, w1: Int, x0: Int, y0: Int, x1: Int, y1: Int): Int =
        ii[y1 * w1 + x1] - ii[y0 * w1 + x1] - ii[y1 * w1 + x0] + ii[y0 * w1 + x0]

    /** Cheap rejection: the middle corner and its four neighbours must all show a strong checker response. */
    private fun plausible(t: Array<IntArray>, cw: Int, x0: Int, y0: Int, s: Int): Boolean {
        fun mag(i: Int, j: Int): Int {
            val idx = (y0 + j * s) * cw + x0 + i * s
            return abs(t[0][idx]) + abs(t[1][idx]) + abs(t[2][idx])
        }
        if (mag(3, 3) < T_MIN) return false
        val low = T_MIN * 6 / 10
        return mag(2, 3) >= low && mag(4, 3) >= low && mag(3, 2) >= low && mag(3, 4) >= low
    }

    /**
     * Score of a 7x7 lattice of corner responses delivered by [corner] (i, j, out[3]); 0 if it cannot beat [floor].
     * The score is the average coherent response times the share of corners that agree with the overall direction.
     */
    private inline fun latticeScore(floor: Double, corner: (Int, Int, IntArray) -> Unit): Double {
        val v = IntArray(3)
        var sr = 0.0
        var sg = 0.0
        var sb = 0.0
        for (j in 0 until 7) for (i in 0 until 7) {
            corner(i, j, v)
            val sign = if (((i + j) and 1) == 0) 1 else -1
            sr += sign * v[0]
            sg += sign * v[1]
            sb += sign * v[2]
        }
        val norm = sqrt(sr * sr + sg * sg + sb * sb)
        val avg = norm / 49.0
        if (avg < MIN_SCORE || avg <= floor) return 0.0
        val ur = sr / norm
        val ug = sg / norm
        val ub = sb / norm
        var agree = 0
        for (j in 0 until 7) for (i in 0 until 7) {
            corner(i, j, v)
            val sign = if (((i + j) and 1) == 0) 1 else -1
            val p = sign * (v[0] * ur + v[1] * ug + v[2] * ub)
            if (p > 0.4 * avg) agree++
        }
        val coherence = agree / 49.0
        if (coherence < MIN_COHERENCE) return 0.0
        return avg * coherence
    }

    /** Fine search at full resolution around the coarse result (lattice origin x0, y0 = first inner corner). */
    private fun refine(width: Int, height: Int, pixel: Pixels, x0: Int, y0: Int, s: Int, k: Int): FoundBoard? {
        val cx = x0 + 3 * s
        val cy = y0 + 3 * s
        var best = -1.0
        var bestS = s
        var bestX = x0
        var bestY = y0
        fun consider(ss: Int, dx: Int, dy: Int) {
            val ox = cx + dx - 3 * ss
            val oy = cy + dy - 3 * ss
            val sc = fullScore(width, height, pixel, ox, oy, ss)
            if (sc > best) {
                best = sc
                bestS = ss
                bestX = ox
                bestY = oy
            }
        }
        val step = if (k >= 3) 2 else 1
        var ds = -k
        while (ds <= k) {
            var dx = -k
            while (dx <= k) {
                var dy = -k
                while (dy <= k) {
                    consider(s + ds, dx, dy)
                    dy += step
                }
                dx += step
            }
            ds += step
        }
        if (step > 1) {
            val cs = bestS
            val ccx = bestX + 3 * cs
            val ccy = bestY + 3 * cs
            for (ds2 in -1..1) for (dx in -1..1) for (dy in -1..1) {
                val ss = cs + ds2
                val ox = ccx + dx - 3 * ss
                val oy = ccy + dy - 3 * ss
                val sc = fullScore(width, height, pixel, ox, oy, ss)
                if (sc > best) {
                    best = sc
                    bestS = ss
                    bestX = ox
                    bestY = oy
                }
            }
        }
        if (best < MIN_SCORE) return null
        val left = bestX - bestS
        val top = bestY - bestS
        val size = bestS * 8
        if (left < 0 || top < 0 || left + size > width || top + size > height) return null
        return FoundBoard(left, top, size, best)
    }

    private fun fullScore(width: Int, height: Int, pixel: Pixels, x0: Int, y0: Int, s: Int): Double {
        if (s < 6 || x0 - s < 0 || y0 - s < 0 || x0 + 7 * s > width || y0 + 7 * s > height) return 0.0
        val t = maxOf(3, (s * 0.3).toInt())
        if (x0 - t < 0 || y0 - t < 0 || x0 + 6 * s + t > width || y0 + 6 * s + t > height) return 0.0
        val n = 4
        fun patch(px0: Int, py0: Int, out: IntArray, sign: Int) {
            var r = 0
            var g = 0
            var b = 0
            for (qy in 0 until n) for (qx in 0 until n) {
                val c = pixel.at(px0 + (qx * t + t / 2) / n, py0 + (qy * t + t / 2) / n)
                r += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
            }
            val cnt = n * n
            out[0] += sign * r / cnt
            out[1] += sign * g / cnt
            out[2] += sign * b / cnt
        }
        return latticeScore(0.0) { i, j, out ->
            out[0] = 0
            out[1] = 0
            out[2] = 0
            val vx = x0 + i * s
            val vy = y0 + j * s
            patch(vx - t, vy - t, out, 1)
            patch(vx, vy, out, 1)
            patch(vx, vy - t, out, -1)
            patch(vx - t, vy, out, -1)
        }
    }

    /** Colour of a square's background, taken from its four corners where pieces rarely reach. */
    private fun cellColor(x: Int, y: Int, cell: Double, row: Int, col: Int, pixel: Pixels): IntArray {
        val inset = 0.14 * cell
        val rad = (0.05 * cell).toInt().coerceAtLeast(1)
        val rs = IntArray(4)
        val gs = IntArray(4)
        val bs = IntArray(4)
        var q = 0
        for (cy in intArrayOf(0, 1)) for (cx in intArrayOf(0, 1)) {
            val px = (x + col * cell + (if (cx == 0) inset else cell - inset)).toInt()
            val py = (y + row * cell + (if (cy == 0) inset else cell - inset)).toInt()
            var r = 0
            var g = 0
            var b = 0
            var cnt = 0
            for (dy in -rad..rad) for (dx in -rad..rad) {
                val c = pixel.at(px + dx, py + dy)
                r += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
                cnt++
            }
            rs[q] = r / cnt
            gs[q] = g / cnt
            bs[q] = b / cnt
            q++
        }
        rs.sort()
        gs.sort()
        bs.sort()
        // median of four = mean of the middle two
        return intArrayOf((rs[1] + rs[2]) / 2, (gs[1] + gs[2]) / 2, (bs[1] + bs[2]) / 2)
    }

    private fun dist(a: IntArray, b: IntArray) = abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])

    /** True if the area really looks like a two-coloured 8x8 checkerboard (used to confirm a find and to notice it vanished). */
    fun verify(x: Int, y: Int, size: Int, width: Int, height: Int, pixel: Pixels): Boolean {
        if (x < 0 || y < 0 || x + size > width || y + size > height || size < 160) return false
        val cell = size / 8.0
        val colors = Array(64) { cellColor(x, y, cell, it / 8, it % 8, pixel) }
        val mean = Array(2) { IntArray(3) }
        val cnt = IntArray(2)
        for (i in 0 until 64) {
            val cls = ((i / 8) + (i % 8)) and 1
            for (c in 0 until 3) mean[cls][c] += colors[i][c]
            cnt[cls]++
        }
        for (cls in 0..1) for (c in 0 until 3) mean[cls][c] /= cnt[cls]
        if (dist(mean[0], mean[1]) < 24) return false
        var good = 0
        for (i in 0 until 64) {
            val cls = ((i / 8) + (i % 8)) and 1
            val own = dist(colors[i], mean[cls])
            val other = dist(colors[i], mean[cls xor 1])
            if (own < other && own <= 90) good++
        }
        return good >= 54
    }

    /** Copies the board area into a picture of at most 512 x 512 pixels (area-averaged). */
    fun crop(x: Int, y: Int, w: Int, h: Int, pixel: Pixels): BoardImage {
        val s = minOf(512, w, h)
        val sx = w.toDouble() / s
        val sy = h.toDouble() / s
        val out = IntArray(s * s)
        for (oy in 0 until s) for (ox in 0 until s) {
            var r = 0
            var g = 0
            var b = 0
            for (q in 0 until 4) {
                val fx = (ox + 0.25 + 0.5 * (q and 1)) * sx
                val fy = (oy + 0.25 + 0.5 * (q shr 1)) * sy
                val c = pixel.at(x + fx.toInt(), y + fy.toInt())
                r += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
            }
            out[oy * s + ox] = (0xFF shl 24) or ((r / 4) shl 16) or ((g / 4) shl 8) or (b / 4)
        }
        return BoardImage(s, s, out)
    }
}
