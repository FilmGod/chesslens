package com.chesslens

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Taps the screen on request. It only ever performs taps that ChessLens asks for (the squares of a move);
 * it does not read or touch anything else on the screen.
 */
class MoveTapService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: MoveTapService? = null

        val enabled: Boolean get() = instance != null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Taps each point in order, starting at the matching offset (ms) in [times]. [done] gets true when the system finished all the taps. */
    fun tapSequence(points: List<Pair<Float, Float>>, times: List<Long>, durations: List<Long>? = null, done: (Boolean) -> Unit) {
        val b = GestureDescription.Builder()
        for ((i, p) in points.withIndex()) {
            val path = Path()
            path.moveTo(p.first, p.second)
            path.lineTo(p.first, p.second + 0.5f)
            b.addStroke(GestureDescription.StrokeDescription(path, times[i], durations?.get(i) ?: 45L))
        }
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done(true) }
            override fun onCancelled(g: GestureDescription?) { done(false) }
        }, null)
        if (!ok) done(false)
    }
}
