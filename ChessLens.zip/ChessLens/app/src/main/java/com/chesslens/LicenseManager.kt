package com.chesslens

import android.content.Context
import android.provider.Settings
import com.chesslens.core.LicenseCore
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Activation key handling: talks to the licence server and keeps the signed token it hands out. */
class LicenseManager(ctx: Context) {
    private val app = ctx.applicationContext
    private val sp = app.getSharedPreferences("license", Context.MODE_PRIVATE)

    private val server: String
    private val pinnedPub: String

    init {
        val cfg = try { app.assets.open("license.json").bufferedReader().use { it.readText() } } catch (e: Exception) { "" }
        server = (LicenseCore.jsonString(cfg, "server") ?: "").trim().trimEnd('/')
        pinnedPub = (LicenseCore.jsonString(cfg, "pubkey") ?: "").trim()
    }

    /** False until a server address is put in assets/license.json; then the app works without a key. */
    val required: Boolean get() = server.startsWith("https://")

    val device: String by lazy {
        val id = Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        MessageDigest.getInstance("SHA-256").digest(("chesslens:$id").toByteArray()).joinToString("") { "%02x".format(it) }
    }

    class Status(val state: LicenseCore.State, val expiresAt: Long) {
        val daysLeft: Int get() = Math.max(0, Math.ceil((expiresAt - System.currentTimeMillis()) / 86400000.0).toInt())
    }

    private fun pub(): String = pinnedPub.ifEmpty { sp.getString("pub", "") ?: "" }

    fun status(): Status {
        if (!required) return Status(LicenseCore.State.VALID, Long.MAX_VALUE)
        val token = sp.getString("token", null) ?: return Status(LicenseCore.State.INVALID, 0)
        val t = LicenseCore.parse(token, pub(), device)
        val st = LicenseCore.state(t, System.currentTimeMillis(), sp.getLong("lastOk", 0))
        return Status(st, t?.exp ?: 0)
    }

    val savedKey: String get() = sp.getString("key", "") ?: ""
    val lastCheck: Long get() = sp.getLong("lastTry", 0)

    private fun post(path: String, body: String): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(server + path).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.requestMethod = if (body.isEmpty()) "GET" else "POST"
            if (body.isNotEmpty()) {
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            stream?.bufferedReader()?.use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    /** Result text for the user, or null when the key was accepted. Blocking: call from a background thread. */
    fun activate(key: String): String? {
        if (!required) return null
        if (pinnedPub.isEmpty() && (sp.getString("pub", "") ?: "").isEmpty()) {
            val r = post("/api/pubkey", "") ?: return "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ตรวจอินเทอร์เน็ตแล้วลองใหม่"
            val spki = LicenseCore.jsonString(r, "spki") ?: return "เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ"
            sp.edit().putString("pub", spki).apply()
        }
        return check(key.trim())
    }

    /** Re-confirms the saved key with the server. Returns an error text, or null when still valid or when offline. */
    fun refresh(): String? {
        val k = savedKey
        if (!required || k.isEmpty()) return null
        return check(k, quietOffline = true)
    }

    private fun check(key: String, quietOffline: Boolean = false): String? {
        sp.edit().putLong("lastTry", System.currentTimeMillis()).apply()
        val body = "{\"key\":\"${key.replace("\"", "")}\",\"device\":\"$device\"}"
        val r = post("/api/verify", body)
            ?: return if (quietOffline) null else "เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ตรวจอินเทอร์เน็ตแล้วลองใหม่"
        val ok = LicenseCore.jsonBool(r, "ok")
        if (ok == true) {
            val token = LicenseCore.jsonString(r, "token") ?: return "เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ"
            if (LicenseCore.parse(token, pub(), device) == null) return "ตรวจลายเซ็นของคีย์ไม่ผ่าน"
            sp.edit().putString("key", key).putString("token", token).putLong("lastOk", System.currentTimeMillis()).apply()
            return null
        }
        if (ok == false) {
            // the server said no (revoked, expired, used elsewhere): forget the token
            sp.edit().remove("token").apply()
            return LicenseCore.jsonString(r, "message") ?: "คีย์ใช้ไม่ได้"
        }
        return if (quietOffline) null else "เซิร์ฟเวอร์ตอบกลับผิดรูปแบบ"
    }
}
