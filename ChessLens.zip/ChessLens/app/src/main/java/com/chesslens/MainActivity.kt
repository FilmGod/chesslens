package com.chesslens

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private companion object {
        const val REQ_CAPTURE = 1001
        const val REQ_NOTIFICATIONS = 1002
    }

    private lateinit var prefs: Prefs
    private lateinit var overlayPill: TextView
    private lateinit var runPill: TextView
    private lateinit var tapPill: TextView
    private var pulse: ValueAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        pulse?.cancel()
        super.onDestroy()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.rounded(Ui.CARD, dp(20), Ui.STROKE, 1)
        setPadding(dp(18), dp(16), dp(18), dp(18))
    }

    private fun badge(n: String): TextView = TextView(this).apply {
        text = n
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Ui.ON_ACCENT)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        background = Ui.circle(Ui.ACCENT)
        layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
    }

    /** Header line of a card: numbered badge, title and an optional status pill on the right. */
    private fun cardHeader(n: String, title: String, pill: TextView?): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(badge(n))
            addView(Ui.label(this@MainActivity, title, 17f, bold = true).also {
                it.layoutParams = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, dp(12)).also { p -> p.weight = 1f }
            })
            if (pill != null) addView(pill)
        }

    private fun buildUi() {
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(20), dp(36), dp(20), dp(32))
        val rise = dp(26)
        var step = 0L

        // ---- header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = TextView(this)
        logo.text = "♞"
        logo.textSize = 30f
        logo.gravity = Gravity.CENTER
        logo.setTextColor(Ui.ON_ACCENT)
        logo.background = Ui.gradient(Ui.ACCENT, Ui.ACCENT_DEEP, dp(18))
        logo.layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(Ui.label(this, "ChessLens", 28f, bold = true))
        titles.addView(Ui.label(this, "ผู้ช่วยดูกระดานหมากรุกบนหน้าจอ", 13.5f, Ui.MUTED))
        head.addView(logo)
        head.addView(titles, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(14)))
        column.addView(head)
        Ui.enter(head, step, rise)
        step += 70

        val intro = Ui.label(
            this,
            "แอปดูกระดานที่แสดงอยู่บนจอ อ่านตำแหน่งหมาก แล้ววาดลูกศรบอกตาเดินที่ดีที่สุดทับบนจอ " +
                "หากระดาน รู้ว่าคุณเล่นฝั่งไหน และเรียนรู้ตัวหมากให้เอง",
            14f, Ui.MUTED
        )
        intro.setLineSpacing(0f, 1.15f)
        column.addView(intro, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(18), 0, dp(6)))
        Ui.enter(intro, step, rise)
        step += 70

        // ---- step 1: overlay permission
        overlayPill = Ui.pill(this, "", Ui.ERR, Ui.withAlpha(Ui.ERR, 40))
        val c1 = card()
        c1.addView(cardHeader("1", "อนุญาตแสดงทับแอปอื่น", overlayPill))
        c1.addView(
            Ui.label(this, "ต้องใช้เพื่อวาดลูกศรและแผงเล็กๆ ทับบนเกมหมากรุก", 13.5f, Ui.MUTED),
            Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(10), 0, dp(12))
        )
        c1.addView(Ui.ghostButton(this, "เปิดหน้าตั้งค่าอนุญาต") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        column.addView(c1, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(14), 0, 0))
        Ui.enter(c1, step, rise)
        step += 70

        // ---- step 2: start
        runPill = Ui.pill(this, "", Ui.MUTED, Ui.withAlpha(Ui.MUTED, 40))
        val c2 = card()
        c2.addView(cardHeader("2", "เริ่มทำงาน", runPill))
        c2.addView(
            Ui.label(
                this,
                "ระบบจะถามสิทธิ์บันทึกหน้าจอ ให้เลือกบันทึกทั้งหน้าจอ แล้วสลับไปเปิดเกมหมากรุก " +
                    "จะมีแผงเล็กๆ ลอยอยู่ ถ้าหากระดานไม่เจอ กด 'ตั้งกรอบ' เอง ถ้าฝั่งผิด กด 'กลับฝั่ง'",
                13.5f, Ui.MUTED
            ).also { it.setLineSpacing(0f, 1.15f) },
            Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(10), 0, dp(14))
        )
        c2.addView(Ui.primaryButton(this, "เริ่มทำงาน") { startCapture() },
            Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        c2.addView(Ui.ghostButton(this, "หยุดการทำงาน", Ui.ERR) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        }, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(10), 0, 0))
        column.addView(c2, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(14), 0, 0))
        Ui.enter(c2, step, rise)
        step += 70

        // ---- optional: tap service for the move buttons
        tapPill = Ui.pill(this, "", Ui.MUTED, Ui.withAlpha(Ui.MUTED, 40))
        val c3 = card()
        c3.addView(cardHeader("+", "ให้แอปแตะเดินหมาก (ไม่บังคับ)", tapPill))
        c3.addView(
            Ui.label(
                this,
                "ใช้กับปุ่ม 'เดินให้' (แตะเดินตาเดียวเมื่อกด) และโหมด 'ออโต้' (เดินให้ทุกตาเอง) บนแผงลอย " +
                    "เปิดได้ที่ การช่วยเหลือพิเศษ > แอปที่ติดตั้ง > ChessLens แอปใช้แตะช่องหมากเท่านั้น " +
                    "ทำเพื่อฝึกซ้อมกับบอทหรือเอนจิน ห้ามใช้กับคนจริง",
                13.5f, Ui.MUTED
            ).also { it.setLineSpacing(0f, 1.15f) },
            Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(10), 0, dp(12))
        )
        c3.addView(Ui.ghostButton(this, "เปิดหน้าตั้งค่าการช่วยเหลือพิเศษ") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        column.addView(c3, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(14), 0, 0))
        Ui.enter(c3, step, rise)
        step += 70

        // ---- fair play note
        val note = LinearLayout(this)
        note.orientation = LinearLayout.VERTICAL
        note.background = Ui.rounded(Ui.withAlpha(Ui.GOLD, 28), dp(18), Ui.withAlpha(Ui.GOLD, 90), 1)
        note.setPadding(dp(16), dp(14), dp(16), dp(14))
        note.addView(Ui.label(this, "โปรดใช้อย่างเป็นธรรม", 14.5f, Ui.GOLD, bold = true))
        note.addView(
            Ui.label(
                this,
                "ใช้กับการฝึกซ้อม เล่นกับบอท หรือทบทวนเกมเก่า การใช้ช่วยตัดสินใจระหว่างเกมจริงกับคนอื่น " +
                    "ผิดกติกาของ lichess, chess.com และเว็บส่วนใหญ่ และอาจทำให้บัญชีถูกแบน",
                13f, Ui.TEXT
            ).also { it.setLineSpacing(0f, 1.15f) },
            Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(6), 0, 0)
        )
        column.addView(note, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(14), 0, 0))
        Ui.enter(note, step, rise)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.addView(column)
        setContentView(scroll)
    }

    private fun setPill(p: TextView, text: String, fg: Int) {
        p.text = text
        p.setTextColor(fg)
        p.background = Ui.rounded(Ui.withAlpha(fg, 40), dp(20))
        p.setPadding(dp(10), dp(4), dp(10), dp(4))
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        setPill(overlayPill, if (ok) "✓ อนุญาตแล้ว" else "ยังไม่อนุญาต", if (ok) Ui.ACCENT else Ui.ERR)
        setPill(tapPill, if (MoveTapService.enabled) "✓ เปิดอยู่" else "ปิดอยู่", if (MoveTapService.enabled) Ui.ACCENT else Ui.MUTED)
        val running = CaptureService.running
        setPill(runPill, if (running) "● กำลังทำงาน" else "ยังไม่เริ่ม", if (running) Ui.ACCENT else Ui.MUTED)
        pulse?.cancel()
        pulse = null
        runPill.alpha = 1f
        if (running) {
            val a = ValueAnimator.ofFloat(1f, 0.45f)
            a.setDuration(900)
            a.setRepeatCount(ValueAnimator.INFINITE)
            a.setRepeatMode(ValueAnimator.REVERSE)
            a.addUpdateListener { v -> runPill.alpha = v.animatedValue as Float }
            a.start()
            pulse = a
        }
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "ทำขั้นที่ 1 ก่อน", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "เริ่มแล้ว — สลับไปเปิดเกมหมากรุกได้เลย", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "ไม่ได้รับอนุญาตให้บันทึกหน้าจอ", Toast.LENGTH_LONG).show()
        }
    }
}
