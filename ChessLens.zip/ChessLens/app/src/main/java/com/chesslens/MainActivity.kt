package com.chesslens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private companion object {
        const val REQ_CAPTURE = 1001
        const val REQ_NOTIFICATIONS = 1002
        const val ID_WHITE = 2001
        const val ID_BLACK = 2002
    }

    private lateinit var prefs: Prefs
    private lateinit var overlayStatus: TextView
    private lateinit var runStatus: TextView
    private lateinit var colorGroup: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(content: String, size: Float, bold: Boolean = false, color: Int = Color.rgb(33, 33, 33)): TextView =
        TextView(this).apply {
            text = content
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(20), dp(28), dp(20), dp(28))

        column.addView(text("♞ ChessLens", 26f, bold = true))
        column.addView(
            text(
                "ผู้ช่วยดูกระดานหมากรุกบนหน้าจอ: แอปจะดูกระดานที่แสดงอยู่ อ่านตำแหน่งหมาก " +
                    "แล้ววาดลูกศรบอกตาเดินที่ดีที่สุดทับบนจอ",
                15f
            )
        )

        column.addView(text("ขั้นที่ 1: อนุญาตให้แสดงทับแอปอื่น", 16f, bold = true))
        overlayStatus = text("", 14f)
        column.addView(overlayStatus)
        column.addView(button("เปิดหน้าตั้งค่าอนุญาต") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        column.addView(text("ขั้นที่ 2: ฝั่งล่างของกระดานบนจอคือสีอะไร", 16f, bold = true))
        colorGroup = RadioGroup(this)
        colorGroup.orientation = RadioGroup.HORIZONTAL
        val white = RadioButton(this).apply { text = "ขาว (ฉันเล่นขาว)"; id = ID_WHITE }
        val black = RadioButton(this).apply { text = "ดำ (ฉันเล่นดำ)"; id = ID_BLACK }
        colorGroup.addView(white)
        colorGroup.addView(black)
        colorGroup.check(if (prefs.bottomIsWhite) ID_WHITE else ID_BLACK)
        column.addView(colorGroup)

        column.addView(text("ขั้นที่ 3: เริ่มทำงาน", 16f, bold = true))
        column.addView(
            text(
                "ระบบจะถามสิทธิ์บันทึกหน้าจอ ให้เลือกบันทึกทั้งหน้าจอ แล้วสลับไปเปิดเกมหมากรุก " +
                    "จะมีแผงเล็กๆ ลอยอยู่: กด 'ตั้งกรอบ' ลากกรอบให้พอดีกับกระดาน แล้วกด 'เรียนรู้' " +
                    "ตอนที่กระดานอยู่ในตำแหน่งเริ่มเกม (ทำครั้งเดียวต่อธีมกระดาน)",
                14f
            )
        )
        column.addView(button("เริ่มทำงาน") { startCapture() })
        runStatus = text("", 14f)
        column.addView(runStatus)
        column.addView(button("หยุดการทำงาน") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        })

        column.addView(
            text(
                "โปรดใช้อย่างเป็นธรรม: ใช้กับการฝึกซ้อม เล่นกับบอท หรือทบทวนเกมเก่า " +
                    "การใช้ช่วยตัดสินใจระหว่างเกมจริงกับคนอื่นผิดกติกาของ lichess, chess.com และเว็บส่วนใหญ่ " +
                    "และอาจทำให้บัญชีถูกแบน",
                13f,
                color = Color.rgb(150, 60, 30)
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(column)
        setContentView(scroll)
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        overlayStatus.text = if (ok) "✓ อนุญาตแล้ว" else "✗ ยังไม่ได้อนุญาต"
        overlayStatus.setTextColor(if (ok) Color.rgb(0, 130, 60) else Color.rgb(190, 40, 40))
        runStatus.text = if (CaptureService.running) "กำลังทำงานอยู่ (ดูแผงลอยบนจอ)" else "ยังไม่ได้เริ่ม"
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "ทำขั้นที่ 1 ก่อน", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
        }
        prefs.bottomIsWhite = colorGroup.checkedRadioButtonId != ID_BLACK
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "เริ่มแล้ว — สลับไปเปิดเกมหมากรุกได้เลย", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "ไม่ได้รับอนุญาตให้บันทึกหน้าจอ", Toast.LENGTH_LONG).show()
        }
    }
}
