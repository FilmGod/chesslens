package com.chesslens.core

import java.util.Random

/** A small built-in opening book: choose a repertoire and the app plays its moves while the game stays on book. */
object Openings {
    class Repertoire(val id: String, val name: String, val side: Int, val lines: List<String>)

    private fun w(id: String, name: String, vararg l: String) = Repertoire(id, name, Piece.WHITE, l.toList())
    private fun b(id: String, name: String, vararg l: String) = Repertoire(id, name, Piece.BLACK, l.toList())

    val all: List<Repertoire> = listOf(
        w("italian", "Italian Game (อิตาเลียน)",
            "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d4 e5d4 c3d4 c5b4 c1d2 b4d2 b1d2 d7d5",
            "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 d2d3 f8c5 c2c3 d7d6 e1g1 e8g8",
            "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5 c4b5 c7c6 d5c6 b7c6 b5e2 h7h6 g5f3 e5e4 f3e5 f8d6",
            "e2e4 e7e5 g1f3 b8c6 f1c4 f8e7 d2d4 e5d4 e1g1 g8f6"),
        w("london", "London System (ลอนดอน)",
            "d2d4 d7d5 c1f4 g8f6 e2e3 e7e6 g1f3 c7c5 c2c3 b8c6 b1d2 f8d6 f4g3 e8g8 f1d3 d8c7",
            "d2d4 g8f6 c1f4 e7e6 e2e3 d7d5 g1f3 f8d6 f4g3 e8g8 f1d3 b8d7",
            "d2d4 g8f6 c1f4 d7d5 e2e3 c7c5 c2c3 b8c6 b1d2 e7e6 g1f3 f8d6",
            "d2d4 g8f6 c1f4 g7g6 e2e3 f8g7 g1f3 d7d6 f1e2 e8g8 e1g1 b8d7"),
        w("qg", "Queen's Gambit (ควีนส์แกมบิต)",
            "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3 b8d7",
            "d2d4 d7d5 c2c4 d5c4 g1f3 g8f6 e2e3 e7e6 f1c4 c7c5 e1g1 a7a6",
            "d2d4 d7d5 c2c4 c7c6 g1f3 g8f6 b1c3 d5c4 a2a4 c8f5 e2e3 e7e6 f1c4 f8b4",
            "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4 e2e3 e8g8 f1d3 d7d5 g1f3 c7c5"),
        w("english", "English Opening (อังกฤษ)",
            "c2c4 e7e5 b1c3 g8f6 g1f3 b8c6 g2g3 d7d5 c4d5 f6d5 f1g2 d5b6 e1g1 f8e7",
            "c2c4 g8f6 b1c3 e7e6 g1f3 d7d5 d2d4 f8e7 c1g5 e8g8",
            "c2c4 c7c5 g1f3 g8f6 b1c3 b8c6 g2g3 g7g6 f1g2 f8g7 e1g1 e8g8",
            "c2c4 e7e5 b1c3 b8c6 g2g3 g7g6 f1g2 f8g7 d2d3 d7d6"),
        w("kingsgambit", "King's Gambit (คิงส์แกมบิต)",
            "e2e4 e7e5 f2f4 e5f4 g1f3 g7g5 h2h4 g5g4 f3e5 g8f6",
            "e2e4 e7e5 f2f4 d7d5 e4d5 e5e4 d2d3 g8f6 d3e4 f6e4 g1f3 f8c5",
            "e2e4 e7e5 f2f4 e5f4 g1f3 d7d6 d2d4 g7g5 h2h4 g5g4 f3g1 f8e7"),
        b("caro", "Caro-Kann (คาโร-คานน์)",
            "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4 c3e4 c8f5 e4g3 f5g6 h2h4 h7h6 g1f3 b8d7 h4h5 g6h7 f1d3 h7d3 d1d3 e7e6",
            "e2e4 c7c6 d2d4 d7d5 e4e5 c8f5 g1f3 e7e6 f1e2 c6c5 e1g1 b8c6",
            "e2e4 c7c6 d2d4 d7d5 e4d5 c6d5 c2c4 g8f6 b1c3 e7e6 g1f3 f8e7",
            "e2e4 c7c6 b1c3 d7d5 g1f3 c8g4 h2h3 g4f3 d1f3 e7e6 d2d3 g8f6",
            "d2d4 c7c6 c2c4 d7d5 b1c3 g8f6 g1f3 e7e6 e2e3 b8d7",
            "g1f3 d7d5 d2d4 c7c6 c2c4 g8f6 b1c3 e7e6 e2e3 b8d7"),
        b("sicilian", "Sicilian Defence (ซิซิเลียน)",
            "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6 c1e3 e7e5 d4b3 c8e6",
            "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 g7g6 c1e3 f8g7 f2f3 e8g8 d1d2 b8c6",
            "e2e4 c7c5 g1f3 b8c6 d2d4 c5d4 f3d4 g8f6 b1c3 d7d6 f1e2 e7e6 e1g1 f8e7",
            "e2e4 c7c5 c2c3 g8f6 e4e5 f6d5 d2d4 c5d4 g1f3 b8c6 c3d4 d7d6 f1c4 d5b6",
            "e2e4 c7c5 b1c3 b8c6 g2g3 g7g6 f1g2 f8g7 d2d3 d7d6"),
        b("french", "French Defence (ฝรั่งเศส)",
            "e2e4 e7e6 d2d4 d7d5 b1c3 g8f6 c1g5 f8e7 e4e5 f6d7 g5e7 d8e7 f2f4 e8g8 g1f3 c7c5",
            "e2e4 e7e6 d2d4 d7d5 b1d2 g8f6 e4e5 f6d7 f1d3 c7c5 c2c3 b8c6 g1e2 c5d4 c3d4 f7f6",
            "e2e4 e7e6 d2d4 d7d5 e4e5 c7c5 c2c3 b8c6 g1f3 d8b6 a2a3 c5c4",
            "e2e4 e7e6 d2d4 d7d5 b1c3 f8b4 e4e5 c7c5 a2a3 b4c3 b2c3 g8e7 d1g4 d8c7"),
        b("scandi", "Scandinavian (สแกนดิเนเวียน)",
            "e2e4 d7d5 e4d5 d8d5 b1c3 d5a5 d2d4 g8f6 g1f3 c7c6 f1c4 c8f5",
            "e2e4 d7d5 e4d5 g8f6 d2d4 f6d5 g1f3 g7g6 c2c4 d5b6 b1c3 f8g7"),
        b("kid", "King's Indian (คิงส์อินเดียน)",
            "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 g1f3 e8g8 f1e2 e7e5 e1g1 b8c6 d4d5 c6e7",
            "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 f2f3 e8g8 c1e3 e7e5 g1e2 c7c6",
            "d2d4 g8f6 c2c4 g7g6 g2g3 f8g7 f1g2 e8g8 b1c3 d7d6 g1f3 b8d7 e1g1 e7e5",
            "d2d4 g8f6 g1f3 g7g6 c2c4 f8g7 b1c3 e8g8 e2e4 d7d6",
            "d2d4 g8f6 c1f4 g7g6 e2e3 f8g7 g1f3 d7d6 f1e2 e8g8 e1g1 b8d7"),
        b("nimzo", "Nimzo-Indian (นิมโซ-อินเดียน)",
            "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4 e2e3 e8g8 f1d3 d7d5 g1f3 c7c5 e1g1 b8c6 a2a3 b4c3 b2c3 d5c4 d3c4 d8c7",
            "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4 d1c2 e8g8 a2a3 b4c3 c2c3 b7b6 c1g5 c8b7 e2e3 d7d6",
            "d2d4 g8f6 c2c4 e7e6 g1f3 f8b4 c1d2 d8e7 g2g3 b8c6"),
        b("qgd", "Queen's Gambit Declined (QGD)",
            "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c1g5 f8e7 e2e3 e8g8 g1f3 h7h6 g5h4 b7b6",
            "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6 c4d5 e6d5 c1g5 c7c6 e2e3 f8e7 f1d3 b8d7",
            "d2d4 d7d5 c2c4 e7e6 g1f3 g8f6 b1c3 f8e7 c1f4 e8g8 e2e3 c7c5"),
        b("grunfeld", "Grünfeld (กรุนเฟลด์)",
            "d2d4 g8f6 c2c4 g7g6 b1c3 d7d5 c4d5 f6d5 e2e4 d5c3 b2c3 f8g7 g1f3 c7c5 f1e2 e8g8 e1g1 b8c6",
            "d2d4 g8f6 c2c4 g7g6 b1c3 d7d5 g1f3 f8g7 d1b3 d5c4 b3c4 e8g8 e2e4 c8g4 c1e3 f6d7"),
        b("indian", "Indian Game (อินเดียนทุกแนว)",
            "d2d4 g8f6 c2c4 e7e6 g1f3 b7b6 g2g3 c8b7 f1g2 f8e7 e1g1 e8g8 b1c3 f6e4",
            "d2d4 g8f6 c2c4 d7d6 b1c3 b8d7 e2e4 e7e5 g1f3 f8e7 f1e2 c7c6 e1g1 e8g8",
            "d2d4 g8f6 c2c4 c7c5 d4d5 e7e6 b1c3 e6d5 c4d5 d7d6 e2e4 g7g6 g1f3 f8g7 f1e2 e8g8 e1g1",
            "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 g1f3 e8g8 f1e2 e7e5 e1g1 b8c6 d4d5 c6e7",
            "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4 e2e3 e8g8 f1d3 d7d5 g1f3 c7c5 e1g1 b8c6",
            "d2d4 g8f6 c2c4 g7g6 b1c3 d7d5 c4d5 f6d5 e2e4 d5c3 b2c3 f8g7 g1f3 c7c5")
    )

    fun byId(id: String): Repertoire? = all.firstOrNull { it.id == id }
    fun forSide(side: Int): List<Repertoire> = all.filter { it.side == side }

    private val cache = HashMap<String, HashMap<String, IntArray>>()

    /** position key -> the repertoire's moves for that position (for the repertoire's own side). */
    /** Key of a position: pieces, side to move and castling rights (en-passant square and move counters ignored, so transpositions match). */
    private fun key(p: Position): String = p.toFen().split(" ").take(3).joinToString(" ")

    private fun book(r: Repertoire): HashMap<String, IntArray> = cache.getOrPut(r.id) {
        val map = HashMap<String, IntArray>()
        for (line in r.lines) {
            val pos = Position.start()
            for (u in line.split(" ")) {
                val m = pos.parseUci(u)
                if (m < 0) break
                if (pos.side == r.side) {
                    val k = key(pos)
                    val have = map[k]
                    if (have == null) map[k] = intArrayOf(m)
                    else if (!have.contains(m)) map[k] = have + m
                }
                pos.makeMove(m)
            }
        }
        map
    }

    /** A book move for [pos], or 0 when the game is out of the repertoire. */
    fun move(r: Repertoire, pos: Position, rng: Random): Int {
        if (pos.side != r.side) return 0
        val ms = book(r)[key(pos)] ?: return 0
        val legal = pos.legalMoves()
        val ok = ms.filter { legal.contains(it) }
        if (ok.isEmpty()) return 0
        return ok[rng.nextInt(ok.size)]
    }

    /** Lines that do not play out legally (used by the tests). */
    fun brokenLines(): List<String> {
        val bad = ArrayList<String>()
        for (r in all) for (line in r.lines) {
            val pos = Position.start()
            for (u in line.split(" ")) {
                val m = pos.parseUci(u)
                if (m < 0) { bad.add("${r.id}: $line (at $u)"); break }
                pos.makeMove(m)
            }
        }
        return bad
    }
}
