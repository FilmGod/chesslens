package com.chesslens.core

import java.util.Random

/** How good a move is compared with the best one, plus the "play at a chosen accuracy" move picker. */
object MoveQuality {
    enum class Kind { BEST, GOOD, MISS, BLUNDER }

    /** Chance of winning (0..100) for the side the score belongs to. */
    fun winPct(cp: Int, mateIn: Int?): Double {
        if (mateIn != null) return if (mateIn > 0) 100.0 else 0.0
        return 50.0 + 50.0 * (2.0 / (1.0 + Math.exp(-0.00368208 * cp)) - 1.0)
    }

    fun winPct(r: SearchResult) = winPct(r.scoreCp, r.mateIn)

    /** Accuracy (0..100) of a move that gives up [winLoss] percentage points of winning chances. */
    fun accuracy(winLoss: Double): Double =
        (103.1668 * Math.exp(-0.04354 * Math.max(0.0, winLoss)) - 3.1669).coerceIn(0.0, 100.0)

    fun kindOf(winLoss: Double): Kind = when {
        winLoss <= 3.0 -> Kind.BEST
        winLoss <= 10.0 -> Kind.GOOD
        winLoss <= 20.0 -> Kind.MISS
        else -> Kind.BLUNDER
    }

    private fun value(p: Int): Int = when (Piece.type(p)) {
        Piece.PAWN -> 1
        Piece.KNIGHT, Piece.BISHOP -> 3
        Piece.ROOK -> 5
        Piece.QUEEN -> 9
        else -> 0
    }

    /** Best material the side to move can win by captures alone (never below 0: it may stop capturing). */
    private fun captureGain(p: Position, depth: Int): Int {
        if (depth == 0) return 0
        var best = 0
        for (m in p.legalMoves()) {
            val got = value(p.board[Moves.to(m)])
            if (got == 0) continue
            val q = p.copy()
            q.makeMove(m)
            best = Math.max(best, got - captureGain(q, depth - 1))
        }
        return best
    }

    /** Material the mover ends up with after the capture sequence that follows the move (negative = a sacrifice). */
    fun materialSwing(pos: Position, move: Int): Int {
        val got = value(pos.board[Moves.to(move)]) + if (Moves.promo(move) != 0) 8 else 0
        val q = pos.copy()
        q.makeMove(move)
        return got - captureGain(q, 5)
    }

    /**
     * A "brilliant" move: a real sacrifice (at least two pawns of material lost in the exchanges) that is still
     * (nearly) the best move, played in a position that was not already clearly won.
     */
    fun isBrilliant(pos: Position, move: Int, winLoss: Double, winBefore: Double, winAfter: Double): Boolean =
        winLoss <= 2.0 && winBefore < 82.0 && winAfter >= 45.0 && materialSwing(pos, move) <= -2

    /**
     * Picks which of the engine's lines (best first) to play so that the running average accuracy of the game
     * approaches [target]. [sumSoFar] / [countSoFar] are the accuracies of the moves already played.
     * Returns the index into [lines].
     */
    fun pick(lines: List<SearchResult>, target: Double, sumSoFar: Double, countSoFar: Int, rng: Random): Int {
        if (lines.size < 2 || target >= 99.5) return 0
        val best = winPct(lines[0])
        val accs = lines.map { accuracy(best - winPct(it)) }
        var want = target * (countSoFar + 1) - sumSoFar + rng.nextGaussian() * 4.0
        want = want.coerceIn(0.0, 100.0)
        var pickIdx = 0
        var diff = Double.MAX_VALUE
        for (i in lines.indices) {
            // never throw the game away: skip lines that give up more than a quarter of the winning chances unless asked for very low accuracy
            if (best - winPct(lines[i]) > 25.0 && target > 55.0) continue
            val d = Math.abs(accs[i] - want)
            if (d < diff - 1e-9) { diff = d; pickIdx = i }
        }
        return pickIdx
    }
}
