package com.chesslens.core

/** Human-readable (Thai) description of a move, e.g. "ม้า g1 → f3". */
object MoveText {
    private val NAMES = arrayOf("", "เบี้ย", "ม้า", "บิชอป", "เรือ", "ควีน", "คิง")

    fun pieceName(type: Int): String = NAMES[type]

    /** [pos] must be the position BEFORE the move is played. */
    fun describe(pos: Position, m: Int): String {
        val from = Moves.from(m)
        val to = Moves.to(m)
        val piece = pos.board[from]
        val type = piece and 7
        val fromName = Moves.squareName(from)
        val toName = Moves.squareName(to)
        if (type == Piece.KING && (to - from == 2)) return "ชิงตัวฝั่งคิง (O-O)  $fromName → $toName"
        if (type == Piece.KING && (from - to == 2)) return "ชิงตัวฝั่งควีน (O-O-O)  $fromName → $toName"
        val isEp = type == Piece.PAWN && to == pos.ep && pos.board[to] == 0 && (from and 7) != (to and 7)
        val captured = pos.board[to] != 0 || isEp
        val sb = StringBuilder()
        sb.append(NAMES[type]).append(' ').append(fromName)
        sb.append(if (captured) " กิน " else " → ").append(toName)
        val promo = Moves.promo(m)
        if (promo != 0) sb.append(" เลื่อนขั้นเป็น").append(NAMES[promo])
        return sb.toString()
    }

    /** "+0.35" style text for a centipawn score, or a mate message. */
    fun scoreText(r: SearchResult): String {
        val mate = r.mateIn
        if (mate != null) return if (mate > 0) "รุกจนใน $mate ตา" else "ระวังถูกรุกจน"
        val v = r.scoreCp / 100.0
        return (if (v >= 0) "+" else "") + String.format(java.util.Locale.US, "%.2f", v)
    }
}
