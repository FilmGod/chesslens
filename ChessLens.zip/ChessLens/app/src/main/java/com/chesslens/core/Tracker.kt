package com.chesslens.core

/**
 * Follows the game from a series of piece placements read off the screen. It finds which legal moves
 * (up to three plies, in case a frame was missed) turned the previous placement into the new one, so it
 * always knows whose turn it is, plus castling rights and en passant.
 */
class PositionTracker {
    private companion object {
        const val NOT_FOUND = 99
    }

    enum class Change { NONE, MOVES, RESYNC }

    var pos: Position? = null
        private set

    /** True when whose turn it is had to be guessed (first reading in mid-game, or after losing track). */
    var assumedTurn = false
        private set

    fun reset() {
        pos = null
        assumedTurn = false
    }

    fun update(read: IntArray, userColor: Int): Change {
        var p = pos
        if (p == null) {
            sync(read, userColor)
            return Change.RESYNC
        }
        if (p.board.contentEquals(read)) return Change.NONE
        var stillGuessing = false
        if (assumedTurn) {
            // Whose turn it is was a guess: keep the side that explains the change with the fewest moves.
            val alt = p.copy()
            alt.setSideToMove(p.side xor 1)
            val dCur = minDepth(p, read)
            val dAlt = minDepth(alt, read)
            if (dAlt < dCur) {
                p = alt
                pos = alt
            }
            stillGuessing = dCur == dAlt && dCur < NOT_FOUND
        }
        for (depth in 1..3) {
            if (!has(p, read, depth, -1)) continue
            if (depth == 2) {
                // The same placement can come from 2 plies or from 3 plies with the other side to move
                // (one side moving a piece twice while the opponent moves once). Then the turn is a guess.
                val white = has(p, read, 2, 0) || has(p, read, 3, 0)
                val black = has(p, read, 2, 1) || has(p, read, 3, 1)
                if (white && black) {
                    for (d in 2..3) if (findPath(p, read, d, userColor)) break
                    assumedTurn = true
                    return Change.MOVES
                }
            }
            findPath(p, read, depth, -1)
            assumedTurn = stillGuessing
            return Change.MOVES
        }
        sync(read, userColor)
        return Change.RESYNC
    }

    private fun minDepth(p: Position, target: IntArray): Int {
        for (d in 1..3) if (has(p, target, d, -1)) return d
        return NOT_FOUND
    }

    /**
     * Some squares could not be read. Looks for the board the game could really have reached (0 to 3 legal plies
     * from the tracked position) that agrees with every square that WAS read. Returns it when there is a single
     * answer at the fewest plies, or when the reader's own best guesses pick one of several. Otherwise null.
     */
    fun complete(read: IntArray, unknown: BooleanArray, guess: IntArray): IntArray? {
        val start = pos ?: return null
        val p = start.copy()
        val found = LinkedHashMap<String, IntArray>()
        val depthOf = HashMap<String, Int>()
        var nodes = 0
        fun matches(): Boolean {
            for (sq in 0 until 64) if (!unknown[sq] && p.board[sq] != read[sq]) return false
            return true
        }
        fun dfs(depth: Int, used: Int) {
            if (matches()) {
                val key = p.board.contentToString()
                if (!found.containsKey(key)) {
                    found[key] = p.board.copyOf()
                    depthOf[key] = used
                }
            }
            if (depth == 0 || found.size > 12 || nodes > 60000) return
            val buf = IntArray(256)
            val n = p.generate(buf, false)
            for (i in 0 until n) {
                if (!p.makeLegal(buf[i])) continue
                nodes++
                dfs(depth - 1, used + 1)
                p.unmakeMove()
            }
        }
        dfs(3, 0)
        if (found.isEmpty()) return null
        if (found.size == 1) return found.values.first()
        val fewest = depthOf.values.min()
        val nearest = found.filter { depthOf[it.key] == fewest }
        if (nearest.size == 1) return nearest.values.first()
        val agreeing = found.values.filter { b -> (0 until 64).all { sq -> !unknown[sq] || b[sq] == guess[sq] } }
        return if (agreeing.size == 1) agreeing[0] else null
    }

    /** User says it is actually the other side's turn. */
    fun flipTurn() {
        val p = pos ?: return
        p.setSideToMove(p.side xor 1)
        assumedTurn = false
    }

    private fun sync(read: IntArray, userColor: Int) {
        val isStart = read.contentEquals(Position.startBoard())
        val side = if (isStart) Piece.WHITE else userColor
        pos = Position.fromBoard(read, side)
        assumedTurn = !isStart
    }

    /** Looks for a legal sequence of exactly [depth] plies reaching [target]; on success the moves stay applied. */
    private fun findPath(p: Position, target: IntArray, depth: Int, want: Int): Boolean {
        val buf = IntArray(256)
        val n = p.generate(buf, false)
        for (i in 0 until n) {
            if (!p.makeLegal(buf[i])) continue
            if (depth == 1) {
                if (p.board.contentEquals(target) && (want < 0 || p.side == want)) return true
            } else if (findPath(p, target, depth - 1, want)) {
                return true
            }
            p.unmakeMove()
        }
        return false
    }

    private fun has(p: Position, target: IntArray, depth: Int, want: Int): Boolean {
        if (!findPath(p, target, depth, want)) return false
        repeat(depth) { p.unmakeMove() }
        return true
    }
}

object BoardGeometry {
    /** Cell indices (row * 8 + col, row 0 at the top of the screen) the arrow from [from] to [to] passes over. */
    fun arrowMask(from: Int, to: Int, whiteAtBottom: Boolean): BooleanArray {
        val mask = BooleanArray(64)
        fun cx(sq: Int): Double = (if (whiteAtBottom) (sq and 7) else 7 - (sq and 7)) + 0.5
        fun cy(sq: Int): Double = (if (whiteAtBottom) 7 - (sq shr 3) else (sq shr 3)) + 0.5
        val ax = cx(from)
        val ay = cy(from)
        val bx = cx(to)
        val by = cy(to)
        val steps = 40
        for (s in 0..steps) {
            val t = s.toDouble() / steps
            val px = ax + (bx - ax) * t
            val py = ay + (by - ay) * t
            for (ox in doubleArrayOf(-0.35, 0.35)) for (oy in doubleArrayOf(-0.35, 0.35)) {
                val c = Math.floor(px + ox).toInt()
                val r = Math.floor(py + oy).toInt()
                if (c in 0..7 && r in 0..7) mask[r * 8 + c] = true
            }
        }
        return mask
    }

    /**
     * Which signature samples (see [Signature]) lie under an arrow drawn from [from] to [to], so that our own
     * overlay is not mistaken for a change on the board.
     */
    fun arrowSampleMask(from: Int, to: Int, whiteAtBottom: Boolean, halfWidth: Double = 0.22, headRadius: Double = 0.58): BooleanArray {
        val g = Signature.G
        val mask = BooleanArray(64 * g * g)
        fun cx(sq: Int): Double = (if (whiteAtBottom) (sq and 7) else 7 - (sq and 7)) + 0.5
        fun cy(sq: Int): Double = (if (whiteAtBottom) 7 - (sq shr 3) else (sq shr 3)) + 0.5
        val ax = cx(from)
        val ay = cy(from)
        val bx = cx(to)
        val by = cy(to)
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        var k = 0
        for (row in 0 until 8) for (col in 0 until 8) for (j in 0 until g) for (i in 0 until g) {
            val px = col + (i + 0.5) / g
            val py = row + (j + 0.5) / g
            val t = if (len2 == 0.0) 0.0 else (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0.0, 1.0)
            val qx = ax + dx * t
            val qy = ay + dy * t
            val d = Math.hypot(px - qx, py - qy)
            val dHead = Math.hypot(px - bx, py - by)
            val dTail = Math.hypot(px - ax, py - ay)
            mask[k++] = d <= halfWidth || dHead <= headRadius || dTail <= 0.5
        }
        return mask
    }
}
