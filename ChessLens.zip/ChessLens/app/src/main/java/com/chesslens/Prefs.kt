package com.chesslens

import android.content.Context
import android.graphics.Rect
import java.io.File

/** Small persistent settings: which colour is at the bottom of the screen, where the board is, what was learned. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("chesslens", Context.MODE_PRIVATE)
    val templatesFile = File(ctx.applicationContext.filesDir, "templates.bin")

    var bottomIsWhite: Boolean
        get() = sp.getBoolean("bottomWhite", true)
        set(v) { sp.edit().putBoolean("bottomWhite", v).apply() }

    /** Floating panel: folded to just its title bar, and its width in pixels (0 = default). */
    var panelCollapsed: Boolean
        get() = sp.getBoolean("panelCollapsed", false)
        set(v) { sp.edit().putBoolean("panelCollapsed", v).apply() }

    var panelWidth: Int
        get() = sp.getInt("panelWidth", 0)
        set(v) { sp.edit().putInt("panelWidth", v).apply() }

    /** Auto mode plays with uneven think time and slightly off-centre taps instead of a fixed rhythm. */
    var humanLike: Boolean
        get() = sp.getBoolean("humanLike", true)
        set(v) { sp.edit().putBoolean("humanLike", v).apply() }

    /** Eval bar beside the board. */
    var evalBar: Boolean
        get() = sp.getBoolean("evalBar", true)
        set(v) { sp.edit().putBoolean("evalBar", v).apply() }

    /** Show the three best moves instead of one. */
    var multiLines: Boolean
        get() = sp.getBoolean("multiLines", false)
        set(v) { sp.edit().putBoolean("multiLines", v).apply() }

    /** Engine strength: 0 = full strength, otherwise an Elo from 1350 to 2800. */
    var elo: Int
        get() = sp.getInt("elo", 0)
        set(v) { sp.edit().putInt("elo", v).apply() }

    /** The board frame is remembered per screen size, because rotating the device changes where the board is. */
    fun frame(w: Int, h: Int): Rect? {
        val s = sp.getString("frame_${w}x$h", null) ?: return null
        val p = s.split(",")
        if (p.size != 4) return null
        return try {
            Rect(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt())
        } catch (e: NumberFormatException) {
            null
        }
    }

    fun setFrame(w: Int, h: Int, r: Rect) {
        sp.edit().putString("frame_${w}x$h", "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }
}
