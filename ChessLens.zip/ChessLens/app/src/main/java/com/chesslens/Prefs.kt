package com.chesslens

import android.content.Context
import android.graphics.Rect
import java.io.File

/** Small persistent settings: which colour is at the bottom of the screen, where the board is, what was learned. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("chesslens", Context.MODE_PRIVATE)
    val templatesFile = File(ctx.applicationContext.filesDir, "templates.bin")

    var bottomIsWhite: Boolean
        get() = sp.getBoolean("bottomWhite", true)
        set(v) { sp.edit().putBoolean("bottomWhite", v).apply() }

    /** The board frame is remembered per screen size, because rotating the device changes where the board is. */
    fun frame(w: Int, h: Int): Rect? {
        val s = sp.getString("frame_${w}x$h", null) ?: return null
        val p = s.split(",")
        if (p.size != 4) return null
        return try {
            Rect(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt())
        } catch (e: NumberFormatException) {
            null
        }
    }

    fun setFrame(w: Int, h: Int, r: Rect) {
        sp.edit().putString("frame_${w}x$h", "${r.left},${r.top},${r.right},${r.bottom}").apply()
    }
}
