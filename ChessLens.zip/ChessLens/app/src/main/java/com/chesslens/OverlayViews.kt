package com.chesslens

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Transparent full-screen view that draws the suggested move as an arrow over the board. */
class ArrowView(context: Context) : View(context) {
    private var board: Rect? = null
    private var from = -1
    private var to = -1
    private var bottomWhite = true

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(225, 0, 200, 83)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(225, 0, 200, 83)
        style = Paint.Style.FILL
    }
    private val outlineFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(225, 0, 200, 83)
        style = Paint.Style.STROKE
    }

    fun setArrow(board: Rect?, from: Int, to: Int, bottomWhite: Boolean) {
        this.board = board?.let { Rect(it) }
        this.from = from
        this.to = to
        this.bottomWhite = bottomWhite
        invalidate()
    }

    fun clear() {
        board = null
        invalidate()
    }

    private fun cx(r: Rect, sq: Int): Float {
        val f = if (bottomWhite) sq and 7 else 7 - (sq and 7)
        return r.left + (f + 0.5f) * r.width() / 8f
    }

    private fun cy(r: Rect, sq: Int): Float {
        val k = if (bottomWhite) 7 - (sq shr 3) else sq shr 3
        return r.top + (k + 0.5f) * r.height() / 8f
    }

    override fun onDraw(canvas: Canvas) {
        val r = board ?: return
        if (from < 0 || to < 0) return
        val cell = r.width() / 8f
        val ax = cx(r, from)
        val ay = cy(r, from)
        val bx = cx(r, to)
        val by = cy(r, to)
        ring.strokeWidth = cell * 0.07f
        canvas.drawCircle(ax, ay, cell * 0.4f, ring)
        val dx = bx - ax
        val dy = by - ay
        val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (len < 1f) return
        val ux = dx / len
        val uy = dy / len
        val headLen = cell * 0.45f
        val headHalf = cell * 0.27f
        val lineW = cell * 0.17f
        val baseX = bx - ux * headLen
        val baseY = by - uy * headLen
        val startX = ax + ux * cell * 0.15f
        val startY = ay + uy * cell * 0.15f
        outline.strokeWidth = lineW + cell * 0.07f
        line.strokeWidth = lineW
        canvas.drawLine(startX, startY, baseX, baseY, outline)
        canvas.drawLine(startX, startY, baseX, baseY, line)
        val head = Path()
        head.moveTo(bx, by)
        head.lineTo(baseX - uy * headHalf, baseY + ux * headHalf)
        head.lineTo(baseX + uy * headHalf, baseY - ux * headHalf)
        head.close()
        outlineFill.strokeWidth = cell * 0.07f
        canvas.drawPath(head, outlineFill)
        canvas.drawPath(head, fill)
    }
}

/**
 * Full-screen editor where the user places a square over the chess board. Drag the square to move it,
 * drag the round handle to resize it, use the small buttons for 1-pixel adjustments.
 */
class FrameEditor(
    context: Context,
    initial: Rect,
    private val screenW: Int,
    private val screenH: Int,
    private val onResult: (Rect?) -> Unit
) : FrameLayout(context) {

    private val rect = RectF(initial)
    private val density = context.resources.displayMetrics.density

    private val dim = Paint().apply { color = Color.argb(120, 0, 0, 0) }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 193, 7)
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 255, 193, 7)
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 193, 7)
        style = Paint.Style.FILL
    }

    private enum class Mode { NONE, MOVE, RESIZE }

    private var mode = Mode.NONE
    private var lastX = 0f
    private var lastY = 0f

    private val canvasView = object : View(context) {
        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawRect(0f, 0f, w, rect.top, dim)
            canvas.drawRect(0f, rect.bottom, w, h, dim)
            canvas.drawRect(0f, rect.top, rect.left, rect.bottom, dim)
            canvas.drawRect(rect.right, rect.top, w, rect.bottom, dim)
            val step = rect.width() / 8f
            for (i in 1 until 8) {
                canvas.drawLine(rect.left + i * step, rect.top, rect.left + i * step, rect.bottom, grid)
                canvas.drawLine(rect.left, rect.top + i * step, rect.right, rect.top + i * step, grid)
            }
            canvas.drawRect(rect, border)
            canvas.drawCircle(rect.right, rect.bottom, 16f * density, handle)
        }
    }

    init {
        addView(canvasView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(225, 32, 39, 51))
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val hint = TextView(context).apply {
            text = "ลากกรอบให้พอดีกับกระดาน 8x8 (ลากจุดกลมมุมขวาล่างเพื่อปรับขนาด)"
            setTextColor(Color.WHITE)
            textSize = 13f
        }
        bar.addView(hint)
        val nudge = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        fun nudgeBtn(label: String, action: () -> Unit) {
            nudge.addView(smallButton(label) { action(); clampRect(); canvasView.invalidate() })
        }
        nudgeBtn("◀") { rect.offset(-1f, 0f) }
        nudgeBtn("▶") { rect.offset(1f, 0f) }
        nudgeBtn("▲") { rect.offset(0f, -1f) }
        nudgeBtn("▼") { rect.offset(0f, 1f) }
        nudgeBtn("−") { rect.right -= 1f; rect.bottom -= 1f }
        nudgeBtn("+") { rect.right += 1f; rect.bottom += 1f }
        bar.addView(nudge)
        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(smallButton("ตกลง") { onResult(toRect()) })
        actions.addView(smallButton("ยกเลิก") { onResult(null) })
        bar.addView(actions)
        addView(bar, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP))
        clampRect()
    }

    private fun dp(v: Int) = (v * density).toInt()

    private fun smallButton(label: String, action: () -> Unit): Button = Button(context).apply {
        text = label
        textSize = 12f
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0)
        layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        setOnClickListener { action() }
    }

    private fun toRect() = Rect(Math.round(rect.left), Math.round(rect.top), Math.round(rect.right), Math.round(rect.bottom))

    private fun clampRect() {
        val minSide = 160f
        val side = minOf(rect.width(), rect.height()).coerceIn(minSide, minOf(screenW, screenH).toFloat())
        rect.right = rect.left + side
        rect.bottom = rect.top + side
        if (rect.left < 0f) rect.offset(-rect.left, 0f)
        if (rect.top < 0f) rect.offset(0f, -rect.top)
        if (rect.right > screenW) rect.offset(screenW - rect.right, 0f)
        if (rect.bottom > screenH) rect.offset(0f, screenH - rect.bottom)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val near = Math.hypot((e.x - rect.right).toDouble(), (e.y - rect.bottom).toDouble())
                mode = when {
                    near <= 40f * density -> Mode.RESIZE
                    rect.contains(e.x, e.y) -> Mode.MOVE
                    else -> Mode.NONE
                }
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                val dy = e.y - lastY
                lastX = e.x
                lastY = e.y
                when (mode) {
                    Mode.MOVE -> rect.offset(dx, dy)
                    Mode.RESIZE -> {
                        val d = (dx + dy) / 2f
                        rect.right += d
                        rect.bottom += d
                    }
                    Mode.NONE -> {}
                }
                clampRect()
                canvasView.invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = Mode.NONE
        }
        return true
    }
}
