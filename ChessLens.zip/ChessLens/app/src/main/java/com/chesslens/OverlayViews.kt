package com.chesslens

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.animation.DecelerateInterpolator
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Transparent full-screen view that draws the suggested move as an animated arrow over the board. */
class ArrowView(context: Context) : View(context) {
    private var board: Rect? = null
    private var from = -1
    private var to = -1
    private var bottomWhite = true
    private var progress = 1f
    private var pulse = 0f
    private var grow: ValueAnimator? = null
    private var beat: ValueAnimator? = null

    private val accent = Color.rgb(52, 226, 168)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 52, 226, 168)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(240, 52, 226, 168)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(240, 52, 226, 168)
        style = Paint.Style.FILL
    }
    private val outlineFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        style = Paint.Style.STROKE
    }

    fun setArrow(board: Rect?, from: Int, to: Int, bottomWhite: Boolean) {
        val same = this.from == from && this.to == to && this.bottomWhite == bottomWhite && this.board != null
        this.board = board?.let { Rect(it) }
        this.from = from
        this.to = to
        this.bottomWhite = bottomWhite
        if (!same) startAnimations()
        invalidate()
    }

    fun clear() {
        board = null
        stopAnimations()
        invalidate()
    }

    private fun startAnimations() {
        stopAnimations()
        progress = 0f
        val g = ValueAnimator.ofFloat(0f, 1f)
        g.setDuration(260)
        g.setInterpolator(DecelerateInterpolator(1.8f))
        g.addUpdateListener { a ->
            progress = a.animatedValue as Float
            invalidate()
        }
        g.start()
        grow = g
        val b = ValueAnimator.ofFloat(0f, 1f)
        b.setDuration(900)
        b.setRepeatCount(ValueAnimator.INFINITE)
        b.setRepeatMode(ValueAnimator.REVERSE)
        b.addUpdateListener { a ->
            pulse = a.animatedValue as Float
            invalidate()
        }
        b.start()
        beat = b
    }

    private fun stopAnimations() {
        grow?.cancel()
        beat?.cancel()
        grow = null
        beat = null
        progress = 1f
        pulse = 0f
    }

    override fun onDetachedFromWindow() {
        stopAnimations()
        super.onDetachedFromWindow()
    }

    private fun cx(r: Rect, sq: Int): Float {
        val f = if (bottomWhite) sq and 7 else 7 - (sq and 7)
        return r.left + (f + 0.5f) * r.width() / 8f
    }

    private fun cy(r: Rect, sq: Int): Float {
        val k = if (bottomWhite) 7 - (sq shr 3) else sq shr 3
        return r.top + (k + 0.5f) * r.height() / 8f
    }

    // ---- secondary arrows (the 2nd and 3rd best moves) and the evaluation bar
    private var extras: List<IntArray> = emptyList()
    private var evalBoard: Rect? = null
    private var evalShown = 0.5f
    private var evalText = ""
    private var evalOn = false
    private var evalAnim: ValueAnimator? = null
    private val density = context.resources.displayMetrics.density
    private val barDark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(34, 38, 46); style = Paint.Style.FILL }
    private val barLight = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(240, 244, 248); style = Paint.Style.FILL }
    private val barEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(160, 20, 24, 30); style = Paint.Style.STROKE }
    private val barTick = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 52, 226, 168); style = Paint.Style.STROKE }
    private val barText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
    }

    /** The 2nd/3rd best moves as thinner arrows; each entry is [from, to]. */
    fun setExtras(list: List<IntArray>) {
        extras = list
        invalidate()
    }

    /** Shows or moves the evaluation bar. [whiteFrac] is white's share of the bar (0..1); null hides it. */
    fun setEval(board: Rect?, whiteFrac: Float, text: String) {
        if (board == null) {
            evalOn = false
            evalAnim?.cancel()
            invalidate()
            return
        }
        evalBoard = Rect(board)
        evalText = text
        val target = whiteFrac.coerceIn(0.02f, 0.98f)
        if (!evalOn) {
            evalOn = true
            evalShown = target
            invalidate()
            return
        }
        evalAnim?.cancel()
        val from = evalShown
        val an = ValueAnimator.ofFloat(from, target)
        an.setDuration(420)
        an.setInterpolator(DecelerateInterpolator(1.6f))
        an.addUpdateListener { v ->
            evalShown = v.animatedValue as Float
            invalidate()
        }
        an.start()
        evalAnim = an
    }

    private fun drawEval(canvas: Canvas) {
        if (!evalOn) return
        val eb = evalBoard ?: return
        val cell = eb.width() / 8f
        val w = Math.max(8f * density, Math.min(cell * 0.3f, 18f * density))
        val gap = 4f * density
        var x1 = eb.left - gap - w
        if (x1 < 2f * density) x1 = eb.right + gap
        if (x1 + w > width - 2f * density) return // no room beside the board
        val top = eb.top.toFloat()
        val bottom = eb.bottom.toFloat()
        val h = bottom - top
        val rr = w / 2f
        val clip = Path()
        clip.addRoundRect(RectF(x1, top, x1 + w, bottom), rr, rr, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        canvas.drawRect(x1, top, x1 + w, bottom, barDark)
        val lightH = h * evalShown
        if (bottomWhite) canvas.drawRect(x1, bottom - lightH, x1 + w, bottom, barLight)
        else canvas.drawRect(x1, top, x1 + w, top + lightH, barLight)
        barTick.strokeWidth = Math.max(1f, density)
        canvas.drawLine(x1, top + h / 2f, x1 + w, top + h / 2f, barTick)
        canvas.restore()
        barEdge.strokeWidth = Math.max(1f, density)
        canvas.drawRoundRect(RectF(x1, top, x1 + w, bottom), rr, rr, barEdge)
        barText.textSize = 11f * density
        val cx = x1 + w / 2f
        val ty = if (top > 22f * density) top - 6f * density else bottom + 16f * density
        canvas.drawText(evalText, Math.max(20f * density, Math.min(cx, width - 20f * density)), ty, barText)
    }

    private fun drawShape(canvas: Canvas, r: Rect, from: Int, to: Int, p: Float, widthScale: Float, color: Int, alpha: Int) {
        val cell = r.width() / 8f
        val ax = cx(r, from)
        val ay = cy(r, from)
        val fullBx = cx(r, to)
        val fullBy = cy(r, to)
        val bx = ax + (fullBx - ax) * p
        val by = ay + (fullBy - ay) * p
        val dx = fullBx - ax
        val dy = fullBy - ay
        val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (len < 1f) return
        val ux = dx / len
        val uy = dy / len
        val headScale = if (p < 0.5f) p * 2f else 1f
        val headLen = cell * 0.45f * headScale * widthScale
        val headHalf = cell * 0.27f * headScale * widthScale
        val lineW = cell * 0.17f * widthScale
        val baseX = bx - ux * headLen
        val baseY = by - uy * headLen
        val startX = ax + ux * cell * 0.15f
        val startY = ay + uy * cell * 0.15f
        val rr = Color.red(color)
        val gg = Color.green(color)
        val bb = Color.blue(color)
        glow.color = Color.argb(alpha / 4, rr, gg, bb)
        outline.color = Color.argb(alpha * 215 / 255, 255, 255, 255)
        outlineFill.color = Color.argb(alpha * 215 / 255, 255, 255, 255)
        line.color = Color.argb(alpha, rr, gg, bb)
        fill.color = Color.argb(alpha, rr, gg, bb)
        glow.strokeWidth = lineW * 2f
        outline.strokeWidth = lineW + cell * 0.07f
        line.strokeWidth = lineW
        canvas.drawLine(startX, startY, baseX, baseY, glow)
        canvas.drawLine(startX, startY, baseX, baseY, outline)
        canvas.drawLine(startX, startY, baseX, baseY, line)
        if (headLen > 1f) {
            val head = Path()
            head.moveTo(bx, by)
            head.lineTo(baseX - uy * headHalf, baseY + ux * headHalf)
            head.lineTo(baseX + uy * headHalf, baseY - ux * headHalf)
            head.close()
            outlineFill.strokeWidth = cell * 0.07f * widthScale
            canvas.drawPath(head, outlineFill)
            canvas.drawPath(head, fill)
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawEval(canvas)
        val r = board ?: return
        if (from < 0 || to < 0) return
        val cell = r.width() / 8f
        // the lesser moves first, so the best move is drawn on top
        val colors = intArrayOf(Color.rgb(255, 196, 61), Color.rgb(110, 170, 255), Color.rgb(255, 130, 190), Color.rgb(190, 150, 255))
        for ((i, e) in extras.withIndex().reversed()) drawShape(canvas, r, e[0], e[1], 1f, 0.72f, colors[i % colors.size], 175)
        // the pulsing ring around the piece to move
        ring.strokeWidth = cell * 0.07f
        ring.alpha = (255 * (0.95f - 0.35f * pulse)).toInt()
        canvas.drawCircle(cx(r, from), cy(r, from), cell * (0.38f + 0.06f * pulse), ring)
        drawShape(canvas, r, from, to, progress, 1f, accent, 240)
    }
}

/**
 * Full-screen editor where the user places a square over the chess board. Drag the square to move it,
 * drag the round handle to resize it, use the small buttons for 1-pixel adjustments.
 */
class FrameEditor(
    context: Context,
    initial: Rect,
    private val screenW: Int,
    private val screenH: Int,
    private val onResult: (Rect?) -> Unit
) : FrameLayout(context) {

    private val rect = RectF(initial)
    private val density = context.resources.displayMetrics.density

    private val dim = Paint().apply { color = Color.argb(120, 0, 0, 0) }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 226, 168)
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(130, 52, 226, 168)
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 226, 168)
        style = Paint.Style.FILL
    }

    private enum class Mode { NONE, MOVE, RESIZE }

    private var mode = Mode.NONE
    private var lastX = 0f
    private var lastY = 0f

    private val canvasView = object : View(context) {
        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawRect(0f, 0f, w, rect.top, dim)
            canvas.drawRect(0f, rect.bottom, w, h, dim)
            canvas.drawRect(0f, rect.top, rect.left, rect.bottom, dim)
            canvas.drawRect(rect.right, rect.top, w, rect.bottom, dim)
            val step = rect.width() / 8f
            for (i in 1 until 8) {
                canvas.drawLine(rect.left + i * step, rect.top, rect.left + i * step, rect.bottom, grid)
                canvas.drawLine(rect.left, rect.top + i * step, rect.right, rect.top + i * step, grid)
            }
            canvas.drawRect(rect, border)
            canvas.drawCircle(rect.right, rect.bottom, 16f * density, handle)
        }
    }

    init {
        addView(canvasView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(Color.argb(238, 14, 20, 28), dp(18), Ui.STROKE, 1)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val hint = TextView(context).apply {
            text = "ลากกรอบให้พอดีกับกระดาน 8x8 (ลากจุดกลมมุมขวาล่างเพื่อปรับขนาด)"
            setTextColor(Ui.TEXT)
            textSize = 13f
        }
        bar.addView(hint)
        val nudge = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        fun nudgeBtn(label: String, action: () -> Unit) {
            nudge.addView(smallButton(label) { action(); clampRect(); canvasView.invalidate() })
        }
        nudgeBtn("◀") { rect.offset(-1f, 0f) }
        nudgeBtn("▶") { rect.offset(1f, 0f) }
        nudgeBtn("▲") { rect.offset(0f, -1f) }
        nudgeBtn("▼") { rect.offset(0f, 1f) }
        nudgeBtn("−") { rect.right -= 1f; rect.bottom -= 1f }
        nudgeBtn("+") { rect.right += 1f; rect.bottom += 1f }
        bar.addView(nudge)
        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(smallButton("ตกลง") { onResult(toRect()) })
        actions.addView(smallButton("ยกเลิก") { onResult(null) })
        bar.addView(actions)
        addView(bar, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP))
        clampRect()
    }

    private fun dp(v: Int) = (v * density).toInt()

    private fun smallButton(label: String, action: () -> Unit): Button = Button(context).apply {
        text = label
        textSize = 13f
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setTextColor(if (label == "ตกลง") Ui.ON_ACCENT else Ui.TEXT)
        background = if (label == "ตกลง") Ui.gradient(Ui.ACCENT, Ui.ACCENT_DEEP, dp(12)) else Ui.rounded(Ui.CARD_HI, dp(12), Ui.STROKE, 1)
        setStateListAnimator(null)
        setElevation(0f)
        setPadding(dp(10), 0, dp(10), 0)
        layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).also { it.setMargins(dp(3), dp(4), dp(3), dp(2)) }
        setOnClickListener { action() }
        Ui.pressEffect(this)
    }

    private fun toRect() = Rect(Math.round(rect.left), Math.round(rect.top), Math.round(rect.right), Math.round(rect.bottom))

    private fun clampRect() {
        val minSide = 160f
        val side = minOf(rect.width(), rect.height()).coerceIn(minSide, minOf(screenW, screenH).toFloat())
        rect.right = rect.left + side
        rect.bottom = rect.top + side
        if (rect.left < 0f) rect.offset(-rect.left, 0f)
        if (rect.top < 0f) rect.offset(0f, -rect.top)
        if (rect.right > screenW) rect.offset(screenW - rect.right, 0f)
        if (rect.bottom > screenH) rect.offset(0f, screenH - rect.bottom)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val near = Math.hypot((e.x - rect.right).toDouble(), (e.y - rect.bottom).toDouble())
                mode = when {
                    near <= 40f * density -> Mode.RESIZE
                    rect.contains(e.x, e.y) -> Mode.MOVE
                    else -> Mode.NONE
                }
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                val dy = e.y - lastY
                lastX = e.x
                lastY = e.y
                when (mode) {
                    Mode.MOVE -> rect.offset(dx, dy)
                    Mode.RESIZE -> {
                        val d = (dx + dy) / 2f
                        rect.right += d
                        rect.bottom += d
                    }
                    Mode.NONE -> {}
                }
                clampRect()
                canvasView.invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = Mode.NONE
        }
        return true
    }
}
