package com.chesslens.core

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import kotlin.math.abs

/** A cropped picture of the chess board (exactly the 8x8 area), packed ARGB. */
class BoardImage(val width: Int, val height: Int, val argb: IntArray)

/** Shrinks a mask by one pixel (4-neighbourhood) so anti-aliased edge pixels, which mix in the square colour, are ignored. */
internal fun erode(mask: BooleanArray, n: Int): BooleanArray {
    val out = BooleanArray(n * n)
    for (y in 1 until n - 1) for (x in 1 until n - 1) {
        val i = y * n + x
        out[i] = mask[i] && mask[i - 1] && mask[i + 1] && mask[i - n] && mask[i + n]
    }
    return out
}

/** Grows a mask by one pixel (4-neighbourhood). */
internal fun dilate(mask: BooleanArray, n: Int): BooleanArray {
    val out = BooleanArray(n * n)
    for (y in 0 until n) for (x in 0 until n) {
        val i = y * n + x
        out[i] = mask[i] || (x > 0 && mask[i - 1]) || (x < n - 1 && mask[i + 1]) ||
            (y > 0 && mask[i - n]) || (y < n - 1 && mask[i + n])
    }
    return out
}

class PieceTemplate(val piece: Int, val pix: IntArray, val mask: BooleanArray) {
    val core: BooleanArray = erode(mask, BoardReader.N)
    val wide: BooleanArray = dilate(mask, BoardReader.N)
    val mx: Double
    val my: Double

    init {
        val c = centroid(mask, BoardReader.N)
        mx = c[0]
        my = c[1]
    }
}

/** Centre of mass of the true pixels as [x, y]; the middle of the picture for an empty mask. */
internal fun centroid(mask: BooleanArray, n: Int): DoubleArray {
    var sx = 0.0
    var sy = 0.0
    var cnt = 0
    for (y in 0 until n) for (x in 0 until n) if (mask[y * n + x]) { sx += x; sy += y; cnt++ }
    return if (cnt == 0) doubleArrayOf((n - 1) / 2.0, (n - 1) / 2.0) else doubleArrayOf(sx / cnt, sy / cnt)
}

/**
 * [unknown] / [guess] are only set when some squares could not be read: which squares, and the piece the reader
 * would pick for each if it had to (used to finish the read from the game's own legal moves).
 */
class ReadResult(
    val ok: Boolean, val pieces: IntArray, val reason: String, val worstCost: Int,
    val unknown: BooleanArray? = null, val guess: IntArray? = null
)

class LearnResult(val ok: Boolean, val message: String)

/**
 * Reads a board position out of a screenshot without any pre-made piece images.
 *
 * The user shows the app the starting position once ("learn"); the app cuts out every piece, removes the
 * square colour with a flood fill, and later re-draws those cut-outs on whatever square colour it meets
 * (so a queen learned on a light square is still recognised on a dark one).
 */
class BoardReader {
    companion object {
        const val N = 32
        private const val MARGIN = 0.06
        private const val BG_TOL = 48
        private const val MIN_FG = 70
        private const val MIN_PIECE_H = 17
        private const val COLOR_CAP = 120
        private const val SHAPE_WEIGHT = 400
        private const val ACCEPT = 170
        private const val MARGIN_MIN = 6
        private const val MAGIC = 0x43484C32

        /** Screen cell (row from the top, col from the left) -> board square (a1 = 0). */
        fun squareOf(row: Int, col: Int, whiteAtBottom: Boolean): Int {
            val file = if (whiteAtBottom) col else 7 - col
            val rank = if (whiteAtBottom) 7 - row else row
            return rank * 8 + file
        }
    }

    val templates = ArrayList<PieceTemplate>()

    val isReady: Boolean get() = templates.isNotEmpty()

    private class Cell(val pix: IntArray, val mask: BooleanArray, val bg: Int, val fg: Int) {
        val core: BooleanArray = erode(mask, N)
        val wide: BooleanArray = dilate(mask, N)
        val mx: Double = centroid(mask, N)[0]
        val my: Double = centroid(mask, N)[1]
    }

    private fun extractCell(img: BoardImage, row: Int, col: Int): Cell {
        val cw = img.width / 8.0
        val ch = img.height / 8.0
        val x0 = col * cw + MARGIN * cw
        val y0 = row * ch + MARGIN * ch
        val sw = cw * (1 - 2 * MARGIN)
        val sh = ch * (1 - 2 * MARGIN)
        val pix = IntArray(N * N)
        for (j in 0 until N) {
            val iy0 = (y0 + j * sh / N).toInt().coerceIn(0, img.height - 1)
            val iy1 = maxOf(iy0 + 1, Math.ceil(y0 + (j + 1) * sh / N).toInt()).coerceAtMost(img.height)
            for (i in 0 until N) {
                val ix0 = (x0 + i * sw / N).toInt().coerceIn(0, img.width - 1)
                val ix1 = maxOf(ix0 + 1, Math.ceil(x0 + (i + 1) * sw / N).toInt()).coerceAtMost(img.width)
                var r = 0
                var g = 0
                var b = 0
                var cnt = 0
                for (y in iy0 until iy1) {
                    val base = y * img.width
                    for (x in ix0 until ix1) {
                        val c = img.argb[base + x]
                        r += (c shr 16) and 255
                        g += (c shr 8) and 255
                        b += c and 255
                        cnt++
                    }
                }
                pix[j * N + i] = ((r / cnt) shl 16) or ((g / cnt) shl 8) or (b / cnt)
            }
        }
        // background colour = median of the four corner patches
        val rs = IntArray(64)
        val gs = IntArray(64)
        val bs = IntArray(64)
        var k = 0
        for (cy in intArrayOf(0, N - 4)) for (cx in intArrayOf(0, N - 4)) {
            for (y in cy until cy + 4) for (x in cx until cx + 4) {
                val c = pix[y * N + x]
                rs[k] = (c shr 16) and 255
                gs[k] = (c shr 8) and 255
                bs[k] = c and 255
                k++
            }
        }
        rs.sort(); gs.sort(); bs.sort()
        val br = rs[32]
        val bgc = gs[32]
        val bb = bs[32]
        val bg = (br shl 16) or (bgc shl 8) or bb

        // flood fill the background from the border; everything not reached belongs to the piece
        val reach = BooleanArray(N * N)
        val stack = IntArray(N * N)
        var sp = 0
        fun bgLike(c: Int): Boolean =
            abs(((c shr 16) and 255) - br) + abs(((c shr 8) and 255) - bgc) + abs((c and 255) - bb) <= BG_TOL
        fun push(x: Int, y: Int) {
            val idx = y * N + x
            if (!reach[idx] && bgLike(pix[idx])) {
                reach[idx] = true
                stack[sp++] = idx
            }
        }
        for (t in 0 until N) {
            push(t, 0); push(t, N - 1); push(0, t); push(N - 1, t)
        }
        while (sp > 0) {
            val idx = stack[--sp]
            val x = idx % N
            val y = idx / N
            if (x > 0) push(x - 1, y)
            if (x < N - 1) push(x + 1, y)
            if (y > 0) push(x, y - 1)
            if (y < N - 1) push(x, y + 1)
        }
        // drop blobs sitting in a corner of the square: coordinate labels ("8", "a") are drawn there, pieces never reach it
        val comp = IntArray(N * N)
        val keep = BooleanArray(N * N)
        var nextId = 0
        for (start in 0 until N * N) {
            if (reach[start] || comp[start] != 0) continue
            nextId++
            var size = 0
            var sx = 0L
            var sy = 0L
            sp = 0
            stack[sp++] = start
            comp[start] = nextId
            val members = ArrayList<Int>()
            while (sp > 0) {
                val idx = stack[--sp]
                members.add(idx)
                size++
                val x = idx % N
                val y = idx / N
                sx += x
                sy += y
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= N || ny >= N) continue
                    val ni = ny * N + nx
                    if (!reach[ni] && comp[ni] == 0) {
                        comp[ni] = nextId
                        stack[sp++] = ni
                    }
                }
            }
            val cx = sx.toDouble() / size
            val cy = sy.toDouble() / size
            val inCorner = Math.abs(cx - 15.5) > 9.0 && Math.abs(cy - 15.5) > 9.0
            if (!inCorner) for (m in members) keep[m] = true
        }
        val mask = BooleanArray(N * N)
        var fg = 0
        var minY = N
        var maxY = -1
        for (i in 0 until N * N) {
            if (keep[i]) {
                mask[i] = true
                fg++
                if (i / N < minY) minY = i / N
                if (i / N > maxY) maxY = i / N
            }
        }
        // a small round blob (move-hint dot, ring) is not a piece: pieces are at least about half a square tall
        if (fg > 0 && maxY - minY + 1 < MIN_PIECE_H) {
            java.util.Arrays.fill(mask, false)
            fg = 0
        }
        return Cell(pix, mask, bg, fg)
    }

    /**
     * Lower is better. Colour is compared only where both pictures are solidly inside a piece, so a different
     * square colour (move highlight, other theme) does not matter; the outline is compared as a shape.
     */
    private fun cost(c: Cell, t: PieceTemplate, dx: Int, dy: Int): Int {
        var colorSum = 0L
        var colorCnt = 0
        var miss = 0
        var union = 0
        for (y in 0 until N) {
            val cy = y + dy
            for (x in 0 until N) {
                val cx = x + dx
                val ti = y * N + x
                val inside = cx in 0 until N && cy in 0 until N
                val ci = cy * N + cx
                val tm = t.mask[ti]
                val cm = inside && c.mask[ci]
                if (tm || cm) union++
                // shape: a pixel solidly inside one piece but clearly outside the other (1 px of edge jitter is ignored)
                if (t.core[ti] && !(inside && c.wide[ci])) miss++
                if (inside && c.core[ci] && !t.wide[ti]) miss++
                if (inside && t.core[ti] && c.core[ci]) {
                    val tp = t.pix[ti]
                    val cp = c.pix[ci]
                    // capped so a few mis-registered edge pixels inside the piece cannot outweigh the overall colour
                    colorSum += minOf(
                        abs(((tp shr 16) and 255) - ((cp shr 16) and 255)) +
                            abs(((tp shr 8) and 255) - ((cp shr 8) and 255)) +
                            abs((tp and 255) - (cp and 255)),
                        COLOR_CAP
                    )
                    colorCnt++
                }
            }
        }
        val color = if (colorCnt == 0) 0 else (colorSum / colorCnt).toInt()
        val shape = if (union == 0) 0 else miss * SHAPE_WEIGHT / union
        return color + shape
    }

    /** Returns [best piece code, best cost, best cost of any other piece code]. Lower cost is better. */
    private fun classify(c: Cell): IntArray {
        val n = templates.size
        val ox = IntArray(n)
        val oy = IntArray(n)
        val c0 = IntArray(n)
        for (i in 0 until n) {
            val t = templates[i]
            // line the two shapes up by their centres of mass, so imperfect framing of the board does not matter
            ox[i] = Math.round(c.mx - t.mx).toInt().coerceIn(-4, 4)
            oy[i] = Math.round(c.my - t.my).toInt().coerceIn(-4, 4)
            c0[i] = cost(c, t, ox[i], oy[i])
        }
        val order = (0 until n).sortedBy { c0[it] }.take(8)
        val perPiece = HashMap<Int, Int>()
        for (i in order) {
            var m = c0[i]
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val v = cost(c, templates[i], ox[i] + dx, oy[i] + dy)
                if (v < m) m = v
            }
            val key = templates[i].piece
            val prev = perPiece[key]
            if (prev == null || m < prev) perPiece[key] = m
        }
        var bestPiece = 0
        var secondPiece = 0
        var best = Int.MAX_VALUE
        var second = Int.MAX_VALUE
        for ((pc, v) in perPiece) {
            if (v < best) {
                second = best; secondPiece = bestPiece
                best = v; bestPiece = pc
            } else if (v < second) {
                second = v; secondPiece = pc
            }
        }
        return intArrayOf(bestPiece, best, second, secondPiece)
    }

    /** Debug/test helper: [piece, bestCost, secondCost, foregroundPixels] for one screen cell. */
    fun fgCount(img: BoardImage, row: Int, col: Int): Int = extractCell(img, row, col).fg

    fun probe(img: BoardImage, row: Int, col: Int): IntArray {
        val cell = extractCell(img, row, col)
        val r = classify(cell)
        return intArrayOf(r[0], r[1], r[2], cell.fg)
    }

    /** Debug helper: cost of every template at the centre-of-mass alignment. */
    fun debugCosts(img: BoardImage, row: Int, col: Int): String {
        val c = extractCell(img, row, col)
        val sb = StringBuilder("cell mx=%.1f my=%.1f fg=%d bg=%06x\n".format(c.mx, c.my, c.fg, c.bg))
        for (t in templates) {
            val ox = Math.round(c.mx - t.mx).toInt().coerceIn(-4, 4)
            val oy = Math.round(c.my - t.my).toInt().coerceIn(-4, 4)
            sb.append("  %s off=(%d,%d) cost=%d zero=%d\n".format(Piece.toChar(t.piece), ox, oy, cost(c, t, ox, oy), cost(c, t, 0, 0)))
        }
        return sb.toString()
    }

    private fun validate(p: IntArray): String? {
        val kings = IntArray(2)
        val pawns = IntArray(2)
        val total = IntArray(2)
        for (sq in 0 until 64) {
            val pc = p[sq]
            if (pc == 0) continue
            val c = pc shr 3
            total[c]++
            if (pc and 7 == Piece.KING) kings[c]++
            if (pc and 7 == Piece.PAWN) {
                pawns[c]++
                if ((sq shr 3) == 0 || (sq shr 3) == 7) return "มีเบี้ยอยู่แถวสุดท้าย"
            }
        }
        if (kings[0] != 1 || kings[1] != 1) return "ไม่พบคิงครบทั้งสองฝั่ง"
        if (pawns[0] > 8 || pawns[1] > 8 || total[0] > 16 || total[1] > 16) return "จำนวนตัวหมากผิดปกติ"
        return null
    }

    fun read(img: BoardImage, whiteAtBottom: Boolean, prior: IntArray? = null): ReadResult {
        if (templates.isEmpty()) return ReadResult(false, IntArray(64), "ยังไม่ได้เรียนรู้ตัวหมาก", 0)
        val pieces = IntArray(64)
        val firstCost = IntArray(64)
        val altPiece = IntArray(64)
        val altCost = IntArray(64) { Int.MAX_VALUE }
        var worst = 0
        val bad = ArrayList<String>()
        val unknown = BooleanArray(64)
        val guess = IntArray(64)
        for (row in 0 until 8) for (col in 0 until 8) {
            val sq = squareOf(row, col, whiteAtBottom)
            val cell = extractCell(img, row, col)
            if (cell.fg < MIN_FG) continue
            val r = classify(cell)
            if (r[1] > ACCEPT || (r[2] != Int.MAX_VALUE && r[2] - r[1] < MARGIN_MIN)) {
                unknown[sq] = true
                guess[sq] = r[0]
                val second = if (r[2] == Int.MAX_VALUE) "-" else "${Piece.toChar(r[3])} ${r[2]}"
                bad.add(Moves.squareName(sq) + "(${Piece.toChar(r[0])} ${r[1]} / $second)")
                continue
            }
            pieces[sq] = r[0]
            firstCost[sq] = r[1]
            altPiece[sq] = r[3]
            altCost[sq] = r[2]
            if (r[1] > worst) worst = r[1]
        }
        if (bad.isNotEmpty()) {
            return ReadResult(false, pieces, "อ่านช่อง ${bad.take(3).joinToString(", ")} ไม่ออก", worst, unknown, guess)
        }
        var v = validate(pieces)
        if (v != null) {
            // a king taken for another piece (or the reverse): flip the least certain square that fixes the king count
            if (repairKings(pieces, altPiece, altCost, firstCost, prior)) v = validate(pieces)
        }
        if (v != null) return ReadResult(false, pieces, v + " " + kingInfo(pieces), worst)
        return ReadResult(true, pieces, "", worst)
    }

    private fun kingCount(p: IntArray, color: Int): Int {
        var n = 0
        for (pc in p) if (pc != 0 && (pc shr 3) == color && (pc and 7) == Piece.KING) n++
        return n
    }

    private fun kingInfo(p: IntArray) = "(คิงขาว ${kingCount(p, Piece.WHITE)} ดำ ${kingCount(p, Piece.BLACK)})"

    private fun repairKings(p: IntArray, alt: IntArray, altCost: IntArray, cost: IntArray, prior: IntArray?): Boolean {
        var changed = false
        for (color in 0..1) {
            val n = kingCount(p, color)
            if (n == 0) {
                // need one more king: the square of that colour whose runner-up is the king and is closest
                var bestSq = -1
                var bestGap = Int.MAX_VALUE
                for (sq in 0 until 64) {
                    if (p[sq] == 0 || alt[sq] != (color shl 3 or Piece.KING)) continue
                    // the king usually stands where it stood before (e1 / e8 at the start): trust that much more
                    val known = prior != null && prior[sq] == (color shl 3 or Piece.KING)
                    val gap = altCost[sq] - cost[sq] - (if (known) 1000 else 0)
                    if (gap < bestGap) { bestGap = gap; bestSq = sq }
                }
                if (bestSq >= 0 && bestGap <= 60) { p[bestSq] = alt[bestSq]; changed = true }
            } else if (n > 1) {
                // too many kings: turn the least certain extra one into its runner-up
                var bestSq = -1
                var bestGap = Int.MAX_VALUE
                for (sq in 0 until 64) {
                    if (p[sq] != (color shl 3 or Piece.KING) || alt[sq] == 0) continue
                    val gap = altCost[sq] - cost[sq]
                    if (gap < bestGap) { bestGap = gap; bestSq = sq }
                }
                if (bestSq >= 0 && bestGap <= 60) { p[bestSq] = alt[bestSq]; changed = true }
            }
        }
        return changed
    }

    private fun colorDist(a: Int, b: Int): Int =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) +
            abs(((a shr 8) and 255) - ((b shr 8) and 255)) +
            abs((a and 255) - (b and 255))

    /** [img] must show the standard starting position with the user's colour at the bottom as stated. */
    fun learn(img: BoardImage, whiteAtBottom: Boolean): LearnResult {
        val start = Position.startBoard()
        val fresh = ArrayList<PieceTemplate>()
        val usedBg = HashMap<Int, ArrayList<Int>>()
        for (row in 0 until 8) for (col in 0 until 8) {
            val sq = squareOf(row, col, whiteAtBottom)
            val expected = start[sq]
            val cell = extractCell(img, row, col)
            val name = Moves.squareName(sq)
            if (expected == 0) {
                if (cell.fg >= MIN_FG) {
                    return LearnResult(false, "ช่อง $name ควรว่าง — ต้องเป็นตำแหน่งเริ่มเกมและกรอบต้องพอดีกับกระดาน")
                }
                continue
            }
            if (cell.fg < MIN_FG) {
                return LearnResult(false, "ไม่พบตัวหมากที่ช่อง $name — ตรวจกรอบและสีด้านล่างอีกครั้ง")
            }
            val used = usedBg.getOrPut(expected) { ArrayList() }
            if (used.size >= 2) continue
            if (used.size == 1 && colorDist(used[0], cell.bg) < 30) continue
            used.add(cell.bg)
            fresh.add(PieceTemplate(expected, cell.pix.copyOf(), cell.mask.copyOf()))
        }
        val old = ArrayList(templates)
        templates.clear()
        templates.addAll(fresh)
        val check = read(img, whiteAtBottom)
        if (!check.ok || !check.pieces.contentEquals(start)) {
            templates.clear()
            templates.addAll(old)
            val why = if (check.ok) "ผลอ่านไม่ตรงกับตำแหน่งเริ่มเกม" else check.reason
            return LearnResult(false, "เรียนรู้ไม่สำเร็จ: $why")
        }
        return LearnResult(true, "เรียนรู้ตัวหมากสำเร็จ (${templates.size} แบบ)")
    }

    /**
     * For a picture of the starting position: true if the light pieces are at the bottom (we play White),
     * false if the dark ones are, null if the picture does not look like a start position.
     */
    fun detectBottomWhite(img: BoardImage): Boolean? {
        val lum = DoubleArray(4)
        val cnt = IntArray(4)
        for (row in 2..5) for (col in 0 until 8) if (extractCell(img, row, col).fg >= MIN_FG) return null
        for (row in intArrayOf(0, 1, 6, 7)) for (col in 0 until 8) {
            val cell = extractCell(img, row, col)
            if (cell.fg < MIN_FG) return null
            var s = 0.0
            var n = 0
            for (i in 0 until N * N) if (cell.core[i]) {
                val c = cell.pix[i]
                s += 0.299 * ((c shr 16) and 255) + 0.587 * ((c shr 8) and 255) + 0.114 * (c and 255)
                n++
            }
            if (n == 0) return null
            val g = if (row < 2) 0 else 1
            lum[g] += s / n
            cnt[g]++
        }
        val top = lum[0] / cnt[0]
        val bottom = lum[1] / cnt[1]
        if (abs(top - bottom) < 40) return null
        return bottom > top
    }

    /**
     * Which colour is at the bottom of the screen: from the piece colours when the picture shows the starting
     * position, otherwise (needs learned pieces) from where the two kings stand - the player at the bottom
     * has the king nearer the bottom edge. null if undecided.
     */
    fun guessBottomWhite(img: BoardImage): Boolean? {
        detectBottomWhite(img)?.let { return it }
        if (templates.isEmpty()) return null
        val r = read(img, true)
        if (!r.ok) return null
        var wk = -1
        var bk = -1
        for (sq in 0 until 64) {
            if (r.pieces[sq] == (Piece.WHITE shl 3 or Piece.KING)) wk = sq shr 3
            if (r.pieces[sq] == (Piece.BLACK shl 3 or Piece.KING)) bk = sq shr 3
        }
        if (wk < 0 || bk < 0 || wk == bk) return null
        return wk < bk
    }

    /** Says in words what keeps this picture from looking like the starting position (for the status text). */
    fun whyNotStart(img: BoardImage): String {
        val extra = ArrayList<String>()
        val missing = ArrayList<String>()
        for (row in 0 until 8) for (col in 0 until 8) {
            val full = row <= 1 || row >= 6
            val has = extractCell(img, row, col).fg >= MIN_FG
            val name = "" + ('a' + col) + (8 - row)
            if (full && !has) missing.add(name)
            if (!full && has) extra.add(name)
        }
        if (missing.isNotEmpty() || extra.isNotEmpty()) {
            val sb = StringBuilder("ต้องเป็นตำแหน่งเริ่มต้น (หมากครบ 32 ตัว ยังไม่มีใครเดิน)")
            if (missing.isNotEmpty()) sb.append("\nช่องที่ควรมีหมากแต่ไม่เห็น: ").append(missing.take(6).joinToString(" "))
            if (extra.isNotEmpty()) sb.append("\nช่องที่ควรว่างแต่มีของอยู่: ").append(extra.take(6).joinToString(" "))
            return sb.toString()
        }
        return "สีหมากฝั่งบนกับฝั่งล่างต่างกันไม่พอ (ตรวจกรอบ/ธีม)"
    }

    /** Detects which colour is at the bottom and learns the pieces; the orientation is in [LearnResult.message] only on failure. */
    fun learnAuto(img: BoardImage): Pair<LearnResult, Boolean?> {
        val white = detectBottomWhite(img)
            ?: return Pair(LearnResult(false, "ไม่เห็นตำแหน่งเริ่มเกม: " + whyNotStart(img)), null)
        return Pair(learn(img, white), white)
    }

    fun save(out: OutputStream) {
        val d = DataOutputStream(BufferedOutputStream(out))
        d.writeInt(MAGIC)
        d.writeInt(N)
        d.writeInt(templates.size)
        for (t in templates) {
            d.writeInt(t.piece)
            for (v in t.pix) d.writeInt(v)
            for (v in t.mask) d.writeBoolean(v)
        }
        d.flush()
    }

    fun load(inp: InputStream): Boolean {
        return try {
            val d = DataInputStream(BufferedInputStream(inp))
            if (d.readInt() != MAGIC || d.readInt() != N) return false
            val n = d.readInt()
            if (n !in 1..64) return false
            val list = ArrayList<PieceTemplate>()
            repeat(n) {
                val piece = d.readInt()
                val pix = IntArray(N * N) { d.readInt() }
                val mask = BooleanArray(N * N) { d.readBoolean() }
                list.add(PieceTemplate(piece, pix, mask))
            }
            templates.clear()
            templates.addAll(list)
            true
        } catch (e: Exception) {
            false
        }
    }
}

/** Cheap fingerprint of the board picture, used to notice that something on the board changed. */
object Signature {
    const val G = 6
    const val PER_CELL = G * G

    /** Samples a G x G grid of luminance values in every board cell; [pixel] returns packed RGB for (x, y) inside width x height. */
    fun sample(width: Int, height: Int, pixel: (Int, Int) -> Int): IntArray {
        val out = IntArray(64 * PER_CELL)
        var k = 0
        for (row in 0 until 8) for (col in 0 until 8) for (j in 0 until G) for (i in 0 until G) {
            val x = ((col * G + i + 0.5) * width / (8.0 * G)).toInt().coerceIn(0, width - 1)
            val y = ((row * G + j + 0.5) * height / (8.0 * G)).toInt().coerceIn(0, height - 1)
            val c = pixel(x, y)
            out[k++] = (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 151 + (c and 255) * 28) shr 8
        }
        return out
    }

    fun of(img: BoardImage): IntArray = sample(img.width, img.height) { x, y -> img.argb[y * img.width + x] }

    /**
     * True if any board cell changed by more than [thr] (mean luminance difference over its samples).
     * Samples flagged in [ignore] (same layout as the signature) are skipped, e.g. where our own arrow is drawn.
     */
    fun changed(a: IntArray, b: IntArray, ignore: BooleanArray?, thr: Int): Boolean {
        for (cell in 0 until 64) {
            val base = cell * PER_CELL
            var sum = 0
            var cnt = 0
            for (i in 0 until PER_CELL) {
                if (ignore != null && ignore[base + i]) continue
                sum += abs(a[base + i] - b[base + i])
                cnt++
            }
            if (cnt >= PER_CELL / 3 && sum / cnt > thr) return true
        }
        return false
    }
}
