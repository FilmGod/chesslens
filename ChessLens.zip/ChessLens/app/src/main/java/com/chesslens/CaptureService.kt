package com.chesslens

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Point
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.graphics.Bitmap
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.chesslens.core.BoardGeometry
import com.chesslens.core.BoardImage
import com.chesslens.core.BoardReader
import com.chesslens.core.BuiltinEngine
import com.chesslens.core.Moves
import com.chesslens.core.MoveAdvisor
import com.chesslens.core.MoveText
import com.chesslens.core.Piece
import com.chesslens.core.PositionTracker
import com.chesslens.core.Signature
import com.chesslens.core.UciEngine
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Watches the screen (with the user's permission), reads the chess board, follows the game and draws the
 * engine's best move as an arrow. Everything about the game runs on one worker thread ([work]);
 * only views are touched on the main thread.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_STOP = "com.chesslens.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "chesslens"
        private const val NOTIF_ID = 17
        private const val TICK_MS = 100L
        private const val QUICK_MS = 120L
        private const val CHANGE_THR = 10

        @Volatile
        var running = false
    }

    private class Advice(
        val from: Int, val to: Int, val text: String, val move: Int = 0,
        val others: List<IntArray> = emptyList(), val evalFrac: Float = 0.5f, val evalText: String = ""
    )

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var thread: HandlerThread? = null
    private var work: Handler? = null
    private var projection: MediaProjection? = null
    private val analysisPool = Executors.newSingleThreadExecutor { r ->
        Thread(r, "chesslens-engine").apply { priority = Thread.MAX_PRIORITY }
    }

    // ---- views (main thread) ----
    private var arrowView: ArrowView? = null
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var statusView: TextView? = null
    private var thumbRow: LinearLayout? = null
    private var thumbBoard: ImageView? = null
    private var thumbScreen: ImageView? = null
    private var editor: FrameEditor? = null

    // ---- game state (work thread only, except where marked) ----
    private var grabber: ScreenGrabber? = null
    private val reader = BoardReader()
    private val tracker = PositionTracker()
    private var engine: MoveAdvisor? = null
    private var engineTimeMs = 1000L
    private var frame: Rect? = null
    @Volatile
    private var frameShadow: Rect? = null
    private var lastSig: IntArray? = null
    private var ignore: BooleanArray? = null
    private var accepted: IntArray? = null
    private var pending: IntArray? = null
    private var forceRead = false
    private var failCount = 0
    private var notBefore = 0L
    private var advice: Advice? = null
    private var autoMode = false
    private var userMovedPanel = false
    private var dockedFor: Rect? = null
    private var licenseChecks = 0
    private var license: LicenseManager? = null
    private var autoBtn: Button? = null
    private var evalBtn: Button? = null
    private var multiBtn: Button? = null
    private var autoArmUntil = 0L
    private var moving = false
    @Volatile
    private var generation = 0

    @Volatile
    private var bottomWhite = true
    private val userColor: Int get() = if (bottomWhite) Piece.WHITE else Piece.BLACK
    private var frameManual = false
    private var verifyFails = 0
    private var tickCount = 0
    private var nextFindAt = 0L
    private var nextLearnAt = 0L

    private fun setBottom(white: Boolean) {
        bottomWhite = white
        prefs.bottomIsWhite = white
    }

    private val tickRunnable = Runnable { tick() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        val lic = LicenseManager(this)
        license = lic
        if (lic.status().state != com.chesslens.core.LicenseCore.State.VALID) {
            main.post { android.widget.Toast.makeText(this, "คีย์ใช้งานไม่ผ่านหรือหมดอายุ", android.widget.Toast.LENGTH_LONG).show() }
            stopSelf()
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (proj == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        running = true
        val t = HandlerThread("chesslens-work")
        t.start()
        thread = t
        work = Handler(t.looper)
        buildOverlays()
        work?.post { initWork(proj) }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        work?.removeCallbacksAndMessages(null)
        main.removeCallbacksAndMessages(null)
        removeOverlays()
        try { grabber?.release() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { engine?.close() } catch (e: Exception) { }
        analysisPool.shutdownNow()
        thread?.quitSafely()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "ChessLens", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_launcher), "หยุด", stop).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("ChessLens กำลังทำงาน")
            .setContentText("กำลังดูกระดานหมากรุกบนหน้าจอ")
            .setOngoing(true)
            .addAction(action)
            .build()
    }

    // ------------------------------------------------------------------ overlay windows (main thread)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Point {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Point(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Point(dm.widthPixels, dm.heightPixels)
    }

    private fun fullScreenParams(touchable: Boolean): WindowManager.LayoutParams {
        val sz = screenSize()
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            sz.x, sz.y, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun smallButton(label: String, color: Int = Ui.TEXT, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        setSingleLine(true)
        gravity = Gravity.CENTER
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        setTextColor(color)
        background = Ui.rounded(Ui.CARD_HI, dp(12), Ui.STROKE, 1)
        setStateListAnimator(null)
        setElevation(0f)
        setPadding(dp(4), dp(4), dp(4), dp(4))
        layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f).also { it.setMargins(0, 0, dp(5), 0) }
        setOnClickListener { onClick() }
        Ui.pressEffect(this)
    }

    private fun buildOverlays() {
        val arrow = ArrowView(this)
        wm.addView(arrow, fullScreenParams(false))
        arrowView = arrow

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(10), dp(12), dp(10))
        box.background = Ui.rounded(Color.argb(240, 12, 18, 26), dp(20), Ui.STROKE, 1)
        val title = LinearLayout(this)
        title.orientation = LinearLayout.HORIZONTAL
        title.gravity = Gravity.CENTER_VERTICAL
        val chip = TextView(this)
        chip.text = "♞"
        chip.textSize = 13f
        chip.gravity = Gravity.CENTER
        chip.setTextColor(Ui.ON_ACCENT)
        chip.background = Ui.gradient(Ui.ACCENT, Ui.ACCENT_DEEP, dp(8))
        chip.layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
        val name = Ui.label(this, "ChessLens", 13f, Ui.ACCENT, bold = true)
        val hint = Ui.label(this, "ลากตรงนี้เพื่อย้าย", 10.5f, Ui.MUTED)
        title.addView(chip)
        title.addView(name, Ui.lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, dp(8), 0, dp(8), 0))
        title.addView(hint)
        val status = TextView(this)
        status.text = "กำลังเริ่มระบบ…"
        status.setTextColor(Ui.TEXT)
        status.textSize = 13.5f
        status.setLineSpacing(0f, 1.12f)
        statusView = status
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(smallButton("ตั้งกรอบ") { openEditor() })
        row.addView(smallButton("เรียนรู้") { work?.post { doLearn() } })
        row.addView(smallButton("สลับตา") { work?.post { doFlipTurn() } })
        row.addView(smallButton("กลับฝั่ง") { work?.post { doFlipSide() } })
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(smallButton("เดินให้", Ui.ACCENT) { work?.post { playAdvice(false) } })
        val ab = smallButton("ออโต้: ปิด") { work?.post { toggleAuto() } }
        autoBtn = ab
        row2.addView(ab)
        row2.addView(smallButton("หยุด", Ui.ERR) { stopSelf() })
        val row3 = LinearLayout(this)
        row3.orientation = LinearLayout.HORIZONTAL
        val eb = smallButton("") { toggleEvalBar() }
        val mb = smallButton("") { toggleMulti() }
        evalBtn = eb
        multiBtn = mb
        row3.addView(eb)
        row3.addView(mb)
        updateToggleLabels()
        // diagnostics shown only when reading fails: what the app sees inside its frame, and the whole screen with the frame
        val tb = ImageView(this)
        tb.layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        val ts = ImageView(this)
        ts.layoutParams = LinearLayout.LayoutParams(dp(110), dp(244))
        val trow = LinearLayout(this)
        trow.orientation = LinearLayout.HORIZONTAL
        trow.addView(tb)
        trow.addView(ts)
        trow.visibility = View.GONE
        thumbRow = trow
        thumbBoard = tb
        thumbScreen = ts
        box.addView(title)
        box.addView(status, Ui.lp(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(8), 0, dp(8)))
        box.addView(trow)
        box.addView(row)
        box.addView(row2, Ui.lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(5), 0, 0))
        box.addView(row3, Ui.lp(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0, dp(5), 0, 0))

        // a fixed width: with WRAP_CONTENT the window shrinks to whatever is left of the screen, which squeezed
        // the panel to a sliver (and made the buttons untappable) once it was dragged towards the edge
        val screen0 = screenSize()
        val lp = WindowManager.LayoutParams(
            Math.min(dp(312), screen0.x - dp(16)), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(48)
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        title.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val sz = screenSize()
                    lp.x = (startX + (e.rawX - downX).toInt()).coerceIn(0, Math.max(0, sz.x - lp.width))
                    lp.y = (startY + (e.rawY - downY).toInt()).coerceIn(0, Math.max(0, sz.y - box.height))
                    userMovedPanel = true
                    try { wm.updateViewLayout(box, lp) } catch (ex: Exception) { }
                }
            }
            true
        }
        wm.addView(box, lp)
        box.setAlpha(0f)
        box.setScaleX(0.9f)
        box.setScaleY(0.9f)
        box.animate()?.alpha(1f)?.scaleX(1f)?.scaleY(1f)?.setDuration(340)?.setInterpolator(OvershootInterpolator(1.3f))?.start()
        panel = box
        panelLp = lp
    }

    private fun removeOverlays() {
        for (v in listOf<View?>(editor, panel, arrowView)) {
            if (v != null) try { wm.removeView(v) } catch (e: Exception) { }
        }
        editor = null
        panel = null
        arrowView = null
    }

    private fun openEditor() {
        if (editor != null) return
        val sz = screenSize()
        val start = frameShadow ?: run {
            val side = (minOf(sz.x, sz.y) * 0.92f).toInt()
            Rect((sz.x - side) / 2, (sz.y - side) / 2, (sz.x - side) / 2 + side, (sz.y - side) / 2 + side)
        }
        val ed = FrameEditor(this, start, sz.x, sz.y) { result ->
            closeEditor()
            if (result != null) work?.post { applyFrame(result) }
        }
        wm.addView(ed, fullScreenParams(true))
        editor = ed
    }

    private fun closeEditor() {
        editor?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        editor = null
    }

    private fun setStatus(text: String) {
        main.post {
            val v = statusView ?: return@post
            if (v.text.toString() == text) return@post
            v.text = text
            v.alpha = 0.7f
            v.animate()?.alpha(1f)?.setDuration(220)?.start()
        }
    }

    /** Shows (or hides, with null) the picture the reader worked from and the screen overview. */
    private fun showDiag(board: BoardImage?, screen: BoardImage?) {
        main.post {
            val row = thumbRow ?: return@post
            if (board == null) {
                row.visibility = View.GONE
                return@post
            }
            thumbBoard?.setImageBitmap(Bitmap.createBitmap(board.argb, board.width, board.height, Bitmap.Config.ARGB_8888))
            if (screen != null) thumbScreen?.setImageBitmap(Bitmap.createBitmap(screen.argb, screen.width, screen.height, Bitmap.Config.ARGB_8888))
            row.visibility = View.VISIBLE
        }
    }

    private fun showArrowOnMain(a: Advice?) {
        main.post {
            val v = arrowView ?: return@post
            val f = frameShadow
            if (a == null || f == null) {
                v.clear()
                v.setExtras(emptyList())
            } else {
                v.setArrow(f, a.from, a.to, bottomWhite)
                v.setExtras(if (prefs.multiLines) a.others else emptyList())
                if (prefs.evalBar && a.evalText.isNotEmpty()) v.setEval(f, a.evalFrac, a.evalText) else v.setEval(null, 0.5f, "")
            }
        }
    }

    private fun onMainWait(block: () -> Unit) {
        val latch = CountDownLatch(1)
        main.post {
            try { block() } finally { latch.countDown() }
        }
        latch.await(500, TimeUnit.MILLISECONDS)
    }

    // ------------------------------------------------------------------ work thread: setup

    private fun initWork(proj: MediaProjection) {
        try {
            val sz = screenSize()
            grabber = ScreenGrabber(proj, work!!, sz.x, sz.y, resources.displayMetrics.densityDpi)
            if (prefs.templatesFile.exists()) {
                try {
                    prefs.templatesFile.inputStream().use { reader.load(it) }
                } catch (e: Exception) { }
            }
            bottomWhite = prefs.bottomIsWhite
            frame = prefs.frame(sz.x, sz.y)
            frameShadow = frame
            setStatus("กำลังเตรียมเอนจิน…")
            startEngine()
            setStatus(guideText())
            scheduleTick(500)
        } catch (e: Exception) {
            setStatus("เริ่มระบบไม่สำเร็จ: ${e.javaClass.simpleName}")
        }
    }

    private fun startEngine() {
        val lib = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (lib.exists()) {
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 8)
            val uci = UciEngine(lib.absolutePath, threads, 256)
            if (uci.start()) {
                engine = uci
                engineTimeMs = 600
                return
            }
        }
        engine = BuiltinEngine()
        engineTimeMs = 800
    }

    private fun guideText(): String = when {
        frame == null -> "กำลังหากระดานบนหน้าจอ… เปิดหน้าเกมหมากรุกให้เห็นกระดาน (หรือกด 'ตั้งกรอบ' เอง)"
        !reader.isReady -> "เจอกระดานแล้ว — เปิดเกมใหม่ให้เห็นตำแหน่งเริ่มต้น แอปจะเรียนรู้และรู้ฝั่งเองอัตโนมัติ"
        else -> "พร้อมแล้ว — เล่นได้เลย (คุณเล่น${if (bottomWhite) "ขาว" else "ดำ"})"
    }

    // ------------------------------------------------------------------ work thread: loop

    private fun scheduleTick(delayMs: Long) {
        val w = work ?: return
        w.removeCallbacks(tickRunnable)
        w.postDelayed(tickRunnable, delayMs)
    }

    /** Moves the panel off the board (to the roomiest side) when the board frame changes, so it never has to be hidden for a read. */
    private fun dockPanelIfNeeded() {
        val rect = frame ?: return
        if (dockedFor == rect) return
        dockedFor = Rect(rect)
        userMovedPanel = false
        main.post {
            val p = panel ?: return@post
            val lp = panelLp ?: return@post
            val sz = screenSize()
            val w = lp.width
            val h = if (p.height > 0) p.height else dp(190)
            if (!Rect.intersects(Rect(lp.x, lp.y, lp.x + w, lp.y + h), rect)) return@post
            val margin = dp(8)
            val right = sz.x - rect.right
            val left = rect.left
            val top = rect.top
            val bottom = sz.y - rect.bottom
            when {
                right >= w + margin * 2 && right >= left -> { lp.x = rect.right + margin; lp.y = Math.max(margin, rect.top) }
                left >= w + margin * 2 -> { lp.x = rect.left - w - margin; lp.y = Math.max(margin, rect.top) }
                bottom >= h + margin * 2 && bottom >= top -> { lp.x = Math.max(margin, (sz.x - w) / 2); lp.y = rect.bottom + margin }
                top >= h + margin * 2 -> { lp.x = Math.max(margin, (sz.x - w) / 2); lp.y = rect.top - h - margin }
                else -> return@post // the board fills the screen: leave the panel where it is
            }
            lp.x = lp.x.coerceIn(0, Math.max(0, sz.x - w))
            lp.y = lp.y.coerceIn(0, Math.max(0, sz.y - h))
            try { wm.updateViewLayout(p, lp) } catch (e: Exception) { }
        }
    }

    private fun checkLicense() {
        if (licenseChecks % 10 == 0 && !userMovedPanel) dockPanelIfNeeded()
        val lic = license ?: return
        licenseChecks++
        if (licenseChecks % 18000 == 0) Thread { lic.refresh() }.start() // about every 30 minutes
        if (licenseChecks % 600 == 0 && lic.status().state != com.chesslens.core.LicenseCore.State.VALID) {
            main.post {
                android.widget.Toast.makeText(this, "คีย์หมดอายุหรือถูกยกเลิก หยุดการทำงาน", android.widget.Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }
    }

    private fun tick() {
        checkLicense()
        val g = grabber
        if (g != null) {
            try {
                step(g)
            } catch (e: Exception) {
                setStatus("เกิดข้อผิดพลาด: ${e.javaClass.simpleName} ${e.message ?: ""}")
            }
        }
        scheduleTick(TICK_MS)
    }

    private fun step(g: ScreenGrabber) {
        val sz = screenSize()
        if (sz.x != g.width || sz.y != g.height) {
            handleResize(g, sz)
            return
        }
        tickCount++
        val rect = frame
        if (rect == null) {
            autoFindBoard(g)
            return
        }
        if (tickCount % 20 == 0) checkFrameStillBoard(g, rect)
        if (frame == null) return
        if (!reader.isReady) {
            autoLearn(g, rect)
            return
        }
        if (System.currentTimeMillis() < notBefore) return
        val sig = g.signature(rect) ?: return
        val prev = lastSig
        val changed = forceRead || prev == null || Signature.changed(prev, sig, ignore, CHANGE_THR)
        if (!changed) return
        forceRead = false
        onBoardChanged(g, rect, sig)
    }

    private fun autoFindBoard(g: ScreenGrabber) {
        val now = System.currentTimeMillis()
        if (now < nextFindAt) return
        nextFindAt = now + 1500
        val fb = g.findBoard()
        if (fb == null) {
            setStatus(guideText())
            return
        }
        val sz = screenSize()
        val r = Rect(fb.x, fb.y, fb.x + fb.size, fb.y + fb.size)
        frameManual = false
        verifyFails = 0
        applyFrame(r, auto = true)
        if (sz.x == 0) return
    }

    /** Looks for the board again; moves the frame if the board is somewhere else. Returns true if the frame changed. */
    private fun refindFrame(g: ScreenGrabber, rect: Rect): Boolean {
        val fb = g.findBoard() ?: return false
        val moved = Math.abs(fb.x - rect.left) > fb.size / 80 || Math.abs(fb.y - rect.top) > fb.size / 80 ||
            Math.abs(fb.size - rect.width()) > fb.size / 80
        if (!moved) return false
        frameManual = false
        applyFrame(Rect(fb.x, fb.y, fb.x + fb.size, fb.y + fb.size), auto = true)
        return true
    }

    /** If the saved/found frame no longer shows a checkerboard (user left the game page, or it moved), search again. */
    private fun checkFrameStillBoard(g: ScreenGrabber, rect: Rect) {
        if (g.verifyBoard(rect)) {
            verifyFails = 0
            return
        }
        verifyFails++
        if (verifyFails < 3) return
        verifyFails = 0
        // the board may have moved (or a pop-up covers it): look for it again, keep the old frame if nothing new is found
        refindFrame(g, rect)
    }

    /** Waits for the start position, then works out our colour and learns the pieces by itself. */
    private fun autoLearn(g: ScreenGrabber, rect: Rect) {
        val now = System.currentTimeMillis()
        if (now < nextLearnAt) return
        nextLearnAt = now + 1000
        val img = g.grabBoard(rect) ?: return
        if (reader.detectBottomWhite(img) == null) return // not a start position (yet)
        doLearn()
    }

    private fun handleResize(g: ScreenGrabber, sz: Point) {
        clearEvalOnMain()
        g.resize(sz.x, sz.y)
        frame = prefs.frame(sz.x, sz.y)
        frameShadow = frame
        frameManual = false
        verifyFails = 0
        nextFindAt = 0
        lastSig = null
        accepted = null
        pending = null
        advice = null
        generation++
        dockedFor = null
        main.post {
            val pp = panel
            val pl = panelLp
            if (pp != null && pl != null) {
                pl.width = Math.min(dp(312), sz.x - dp(16))
                pl.x = pl.x.coerceIn(0, Math.max(0, sz.x - pl.width))
                pl.y = pl.y.coerceIn(0, Math.max(0, sz.y - Math.max(pp.height, dp(120))))
                try { wm.updateViewLayout(pp, pl) } catch (e: Exception) { }
            }
            arrowView?.let { v -> try { wm.updateViewLayout(v, fullScreenParams(false)) } catch (e: Exception) { } }
            arrowView?.clear()
        }
        setStatus(if (frame == null) "หมุนหน้าจอแล้ว — กำลังหากระดานใหม่…" else guideText())
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { }
    }

    private fun onBoardChanged(g: ScreenGrabber, rect: Rect, sig: IntArray) {
        generation++
        ignore = null
        showArrowOnMain(null)
        // let piece animations finish: two samples a moment apart must agree
        sleep(90)
        val sig2 = g.signature(rect) ?: return
        if (Signature.changed(sig, sig2, null, CHANGE_THR)) {
            lastSig = sig2
            forceRead = true
            return
        }
        lastSig = sig2
        val img = cleanCapture(g, rect) ?: return
        val res = reader.read(img, bottomWhite, tracker.pos?.board ?: com.chesslens.core.Position.startBoard())
        if (!res.ok) {
            pending = null
            failCount++
            forceRead = failCount < 3 // after 3 tries wait for the screen to change instead of retrying forever
            notBefore = System.currentTimeMillis() + 1200
            if (res.pieces.all { it == 0 } && refindFrame(g, rect)) return // nothing at all in the frame: it was not on the board
            showDiag(img, g.overview(rect, 220))
            setStatus("อ่านกระดานไม่ออก: ${res.reason}\n" + gridText(res.pieces) + "\n[กรอบ ${rect.left},${rect.top} ถึง ${rect.right},${rect.bottom} | จอ ${g.width}x${g.height}]\n(เปลี่ยนธีม/กระดานแล้ว? เปิดเกมใหม่ตอนตำแหน่งเริ่มต้น แอปจะเรียนรู้ใหม่เอง)")
            if (reader.detectBottomWhite(img) != null) {
                doLearn()
            }
            return
        }
        failCount = 0
        showDiag(null, null)
        if (tracker.pos == null || looksLikeStart(res.pieces)) {
            // work out which colour is at the bottom; if the guess was wrong, flip and read again
            val guess = reader.guessBottomWhite(img)
            if (guess != null && guess != bottomWhite) {
                setBottom(guess)
                clearEvalOnMain()
                tracker.reset()
                accepted = null
                pending = null
                advice = null
                forceRead = true
                setStatus("ตรวจพบว่าคุณเล่น${if (guess) "ขาว" else "ดำ"}")
                return
            }
        }
        val acc = accepted
        if (acc != null && acc.contentEquals(res.pieces)) {
            // nothing changed on the board itself (e.g. only our own overlay): bring the advice back
            if (tracker.pos != null) analyzeCurrent()
            return
        }
        val pend = pending
        if (pend == null || !pend.contentEquals(res.pieces)) {
            // the same picture must be read twice in a row before it is trusted
            pending = res.pieces
            forceRead = true
            notBefore = System.currentTimeMillis() + 30
            return
        }
        pending = null
        failCount = 0
        accepted = res.pieces
        advice = null
        tracker.update(res.pieces, userColor)
        analyzeCurrent()
    }

    /** What the app currently reads, row by row as on the screen (capital = white), for diagnosing wrong reads. */
    private fun gridText(p: IntArray): String {
        val sb = StringBuilder()
        for (row in 0 until 8) {
            for (col in 0 until 8) sb.append(Piece.toChar(p[BoardReader.squareOf(row, col, bottomWhite)])).append(' ')
            if (row < 7) sb.append('\n')
        }
        return sb.toString()
    }

    private fun looksLikeStart(p: IntArray): Boolean {
        var n = 0
        for (sq in 0 until 64) if (p[sq] != 0) {
            val rank = sq shr 3
            if (rank != 0 && rank != 1 && rank != 6 && rank != 7) return false
            n++
        }
        return n == 32
    }

    /** Picture of the board without our own panel on top of it. */
    private fun cleanCapture(g: ScreenGrabber, rect: Rect): BoardImage? {
        val p = panel
        val lp = panelLp
        var hid = false
        if (p != null && lp != null) {
            val pr = Rect(lp.x, lp.y, lp.x + p.width, lp.y + p.height)
            if (Rect.intersects(pr, rect)) {
                val before = g.frameCount
                onMainWait { p.visibility = View.INVISIBLE }
                g.awaitFrame(before, 350)
                sleep(40)
                hid = true
            }
        }
        val img = g.grabBoard(rect)
        if (hid) onMainWait { p?.visibility = View.VISIBLE }
        return img
    }

    // ------------------------------------------------------------------ work thread: analysis

    private fun turnNote(): String = if (tracker.assumedTurn) "\n(เดาว่าเป็นตาคุณ — กด 'สลับตา' ถ้าไม่ใช่)" else ""

    private fun analyzeCurrent() {
        val pos = tracker.pos ?: return
        val moves = pos.legalMoves()
        if (moves.isEmpty()) {
            advice = null
            showArrowOnMain(null)
            setStatus(if (pos.inCheck()) "รุกจน — จบเกม" else "เสมอ (ไม่มีตาเดิน)")
            return
        }
        if (pos.side != userColor) {
            advice = null
            showArrowOnMain(null)
            setStatus("รอคู่ต่อสู้เดิน…" + turnNote())
            return
        }
        val a = advice
        if (a != null) {
            applyAdvice(a)
            return
        }
        val eng = engine ?: return
        val snapshot = pos.copy()
        eng.configure(if (prefs.multiLines) 3 else 1, prefs.elo)
        val gen = generation
        val ms = engineTimeMs
        setStatus("กำลังคิด…")
        analysisPool.execute {
            // first a quick look so an arrow appears at once, then the full search may improve it
            for (budget in longArrayOf(QUICK_MS, ms)) {
                if (gen != generation) return@execute
                val r = try { eng.analyze(snapshot, budget) } catch (e: Exception) { null }
                if (r == null) {
                    // never leave the panel on "thinking" forever: say why, and switch to the built-in engine if Stockfish failed
                    val why = (eng as? UciEngine)?.lastError ?: ""
                    work?.post { if (gen == generation) engineFailed(eng, why) }
                    return@execute
                }
                work?.post {
                    if (gen == generation && r != null) {
                        var text = MoveText.describe(snapshot, r.move) + "\nประเมิน: " + MoveText.scoreText(r) +
                            "  (${eng.name}, ลึก ${r.depth})" + turnNote()
                        val shown = if (prefs.multiLines) r.others else emptyList()
                        if (shown.isNotEmpty()) {
                            text += "\nตัวเลือกอื่น: " + shown.withIndex().joinToString("   ") { (i, o) ->
                                "${i + 2}) ${Moves.squareName(Moves.from(o.move))}${Moves.squareName(Moves.to(o.move))} ${MoveText.scoreText(o)}"
                            }
                        }
                        if (prefs.elo > 0 && eng is UciEngine) text += "\nจำกัดระดับเอนจิน ~${prefs.elo}"
                        val whiteCp = if (snapshot.side == Piece.WHITE) r.scoreCp else -r.scoreCp
                        val frac = if (r.mateIn != null) {
                            val whiteWins = (r.mateIn > 0) == (snapshot.side == Piece.WHITE)
                            if (whiteWins) 0.98f else 0.02f
                        } else (1.0 / (1.0 + Math.exp(-whiteCp / 400.0))).toFloat()
                        val evalText = if (r.mateIn != null) "M" + Math.abs(r.mateIn)
                        else (if (whiteCp >= 0) "+" else "-") + String.format(java.util.Locale.US, "%.1f", Math.abs(whiteCp) / 100.0)
                        val adv = Advice(
                            Moves.from(r.move), Moves.to(r.move), text, r.move,
                            r.others.map { intArrayOf(Moves.from(it.move), Moves.to(it.move)) }, frac, evalText
                        )
                        advice = adv
                        applyAdvice(adv)
                        if (budget == ms && autoMode) playAdvice(true)
                    }
                }
            }
        }
    }

    private fun engineFailed(eng: MoveAdvisor, why: String) {
        if (eng is UciEngine) {
            try { eng.close() } catch (e: Exception) { }
            engine = BuiltinEngine()
            engineTimeMs = 800
            setStatus("Stockfish ใช้ไม่ได้ ($why)\nสลับไปใช้เอนจินในตัวแทน")
            analyzeCurrent()
        } else {
            setStatus("คิดตาเดินไม่ออก: ไม่พบตาเดินที่ใช้ได้ในตำแหน่งนี้\nอ่านกระดานอาจผิด ลองกด 'สลับตา' หรือ 'เรียนรู้'")
        }
    }

    private fun applyAdvice(a: Advice) {
        val mask = BoardGeometry.arrowSampleMask(a.from, a.to, bottomWhite)
        if (prefs.multiLines) for (e in a.others) {
            val m2 = BoardGeometry.arrowSampleMask(e[0], e[1], bottomWhite)
            for (i in mask.indices) if (m2[i]) mask[i] = true
        }
        ignore = mask
        showArrowOnMain(a)
        setStatus(a.text)
    }

    // ------------------------------------------------------------------ work thread: user actions

    private fun applyFrame(r: Rect, auto: Boolean = false) {
        clearEvalOnMain()
        val sz = screenSize()
        frame = r
        frameShadow = r
        if (!auto) frameManual = true
        prefs.setFrame(sz.x, sz.y, r)
        lastSig = null
        accepted = null
        pending = null
        advice = null
        generation++
        showArrowOnMain(null)
        setStatus(guideText())
    }

    private fun doLearn() {
        val g = grabber ?: return
        val rect = frame
        if (rect == null) {
            setStatus("ตั้งกรอบกระดานก่อน (กด 'ตั้งกรอบ')")
            return
        }
        generation++
        advice = null
        ignore = null
        showArrowOnMain(null)
        sleep(300)
        val img = cleanCapture(g, rect)
        if (img == null) {
            setStatus("ยังไม่ได้รับภาพหน้าจอ ลองอีกครั้ง")
            return
        }
        val (lr, side) = reader.learnAuto(img)
        if (lr.ok && side != null) {
            setBottom(side)
            try {
                prefs.templatesFile.outputStream().use { reader.save(it) }
            } catch (e: Exception) { }
            clearEvalOnMain()
            tracker.reset()
            accepted = null
            pending = null
            lastSig = null
            forceRead = true
            notBefore = 0
            showDiag(null, null)
            setStatus(lr.message + "\nคุณเล่น${if (side) "ขาว" else "ดำ"} — เริ่มเล่นได้เลย")
        } else {
            showDiag(img, g.overview(rect, 220))
            setStatus(lr.message + "\n[กรอบ ${rect.left},${rect.top} ถึง ${rect.right},${rect.bottom} | จอ ${g.width}x${g.height}]")
        }
    }

    private fun doFlipSide() {
        clearEvalOnMain()
        generation++
        advice = null
        ignore = null
        showArrowOnMain(null)
        setBottom(!bottomWhite)
        tracker.reset()
        accepted = null
        pending = null
        lastSig = null
        forceRead = true
        setStatus("สลับเป็นเล่น${if (bottomWhite) "ขาว" else "ดำ"}")
    }

    // ------------------------------------------------------------------ tapping the move (practice vs bots / engines only)

    private fun squareCenter(rect: Rect, sq: Int): Pair<Float, Float> {
        val file = sq and 7
        val rank = sq shr 3
        val col = if (bottomWhite) file else 7 - file
        val row = if (bottomWhite) 7 - rank else rank
        return Pair(rect.left + (col + 0.5f) * rect.width() / 8f, rect.top + (row + 0.5f) * rect.height() / 8f)
    }

    private fun toggleAuto() {
        val now = System.currentTimeMillis()
        if (autoMode) {
            autoMode = false
            updateAutoButton()
            setStatus("ปิดโหมดออโต้แล้ว")
            return
        }
        if (!MoveTapService.enabled) {
            setStatus("ยังไม่ได้เปิดบริการแตะ: ตั้งค่า > การช่วยเหลือพิเศษ > ChessLens")
            return
        }
        if (now > autoArmUntil) {
            autoArmUntil = now + 5000
            setStatus("โหมดออโต้จะเดินให้ทุกตา ใช้ฝึกกับบอท/เอนจินเท่านั้น ห้ามใช้กับคนจริง\nกด 'ออโต้' อีกครั้งภายใน 5 วินาทีเพื่อยืนยัน")
            return
        }
        autoMode = true
        updateAutoButton()
        setStatus("เปิดโหมดออโต้ (ฝึกกับบอท) จะเดินให้เมื่อถึงตาคุณ")
        analyzeCurrent()
    }

    private fun updateAutoButton() {
        main.post { autoBtn?.text = if (autoMode) "ออโต้: เปิด" else "ออโต้: ปิด" }
    }

    private fun stopAuto(why: String) {
        autoMode = false
        updateAutoButton()
        setStatus(why)
    }

    /** Taps the advised move. [fromAuto] is true when the automatic mode asks for it. */
    private fun playAdvice(fromAuto: Boolean) {
        val a = advice
        val rect = frame
        val svc = MoveTapService.instance
        val pos = tracker.pos
        if (moving) return
        if (svc == null) { setStatus("ยังไม่ได้เปิดบริการแตะ: ตั้งค่า > การช่วยเหลือพิเศษ > ChessLens"); return }
        if (a == null || rect == null || pos == null || pos.side != userColor) {
            if (!fromAuto) setStatus("ยังไม่มีตาเดินที่ต้องเดิน (รอถึงตาคุณและรอให้คิดเสร็จ)")
            return
        }
        moving = true
        val gen = generation
        val before = accepted?.copyOf()
        val promo = Moves.promo(a.move) != 0
        val f = squareCenter(rect, a.from)
        val t = squareCenter(rect, a.to)
        // the panel would catch the taps if it sat on top of the board, so hide it for a moment
        onMainWait { panel?.visibility = View.INVISIBLE }
        sleep(120)
        // promotion: the piece picker opens on the destination square with the queen first in both chess.com and lichess,
        // so tapping the destination again picks the queen
        val taps = if (promo) listOf(f, t, t) else listOf(f, t)
        val times = if (promo) listOf(0L, 220L, 900L) else listOf(0L, 220L)
        svc.tapSequence(taps, times) { ok ->
            work?.post {
                onMainWait { panel?.visibility = View.VISIBLE }
                moving = false
                if (!ok) {
                    stopAuto("แตะไม่สำเร็จ ปิดโหมดออโต้")
                    return@post
                }
                if (promo) setStatus("เดินเลื่อนขั้นเป็นควีน")
                forceRead = true
                notBefore = System.currentTimeMillis() + 150
                // if the board did not change a few seconds later the tap did not take: stop rather than keep trying
                work?.postDelayed({
                    val same = before != null && accepted != null && accepted!!.contentEquals(before)
                    if (same && gen == generation && tracker.pos?.side == userColor && autoMode) {
                        stopAuto("เดินแล้วกระดานไม่เปลี่ยน (แอปเกมอาจไม่รับการแตะ หรือแผงบังกระดาน) ปิดโหมดออโต้")
                    }
                }, 3500)
            }
        }
    }

    private fun updateToggleLabels() {
        evalBtn?.text = if (prefs.evalBar) "แถบประเมิน: เปิด" else "แถบประเมิน: ปิด"
        multiBtn?.text = if (prefs.multiLines) "3 ตาเดิน: เปิด" else "3 ตาเดิน: ปิด"
    }

    private fun toggleEvalBar() {
        prefs.evalBar = !prefs.evalBar
        updateToggleLabels()
        showArrowOnMain(advice)
    }

    private fun toggleMulti() {
        prefs.multiLines = !prefs.multiLines
        updateToggleLabels()
        work?.post {
            // the engine has to search again to give three moves (or one)
            advice = null
            generation++
            analyzeCurrent()
        }
    }

    private fun clearEvalOnMain() {
        main.post { arrowView?.setEval(null, 0.5f, "") }
    }

    private fun doFlipTurn() {
        if (tracker.pos == null) return
        generation++
        advice = null
        ignore = null
        showArrowOnMain(null)
        tracker.flipTurn()
        analyzeCurrent()
    }
}
