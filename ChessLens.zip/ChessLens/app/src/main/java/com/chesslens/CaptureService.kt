package com.chesslens

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Point
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.chesslens.core.BoardGeometry
import com.chesslens.core.BoardImage
import com.chesslens.core.BoardReader
import com.chesslens.core.BuiltinEngine
import com.chesslens.core.Moves
import com.chesslens.core.MoveAdvisor
import com.chesslens.core.MoveText
import com.chesslens.core.Piece
import com.chesslens.core.PositionTracker
import com.chesslens.core.Signature
import com.chesslens.core.UciEngine
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Watches the screen (with the user's permission), reads the chess board, follows the game and draws the
 * engine's best move as an arrow. Everything about the game runs on one worker thread ([work]);
 * only views are touched on the main thread.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_STOP = "com.chesslens.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "chesslens"
        private const val NOTIF_ID = 17
        private const val TICK_MS = 400L
        private const val CHANGE_THR = 10

        @Volatile
        var running = false
    }

    private class Advice(val from: Int, val to: Int, val text: String)

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var thread: HandlerThread? = null
    private var work: Handler? = null
    private var projection: MediaProjection? = null
    private val analysisPool = Executors.newSingleThreadExecutor()

    // ---- views (main thread) ----
    private var arrowView: ArrowView? = null
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var statusView: TextView? = null
    private var editor: FrameEditor? = null

    // ---- game state (work thread only, except where marked) ----
    private var grabber: ScreenGrabber? = null
    private val reader = BoardReader()
    private val tracker = PositionTracker()
    private var engine: MoveAdvisor? = null
    private var engineTimeMs = 1000L
    private var frame: Rect? = null
    @Volatile
    private var frameShadow: Rect? = null
    private var lastSig: IntArray? = null
    private var ignore: BooleanArray? = null
    private var accepted: IntArray? = null
    private var pending: IntArray? = null
    private var forceRead = false
    private var failCount = 0
    private var notBefore = 0L
    private var advice: Advice? = null
    @Volatile
    private var generation = 0

    @Volatile
    private var bottomWhite = true
    private val userColor: Int get() = if (bottomWhite) Piece.WHITE else Piece.BLACK
    private var frameManual = false
    private var verifyFails = 0
    private var tickCount = 0
    private var nextFindAt = 0L
    private var nextLearnAt = 0L

    private fun setBottom(white: Boolean) {
        bottomWhite = white
        prefs.bottomIsWhite = white
    }

    private val tickRunnable = Runnable { tick() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (code != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (proj == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        running = true
        val t = HandlerThread("chesslens-work")
        t.start()
        thread = t
        work = Handler(t.looper)
        buildOverlays()
        work?.post { initWork(proj) }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        work?.removeCallbacksAndMessages(null)
        main.removeCallbacksAndMessages(null)
        removeOverlays()
        try { grabber?.release() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { engine?.close() } catch (e: Exception) { }
        analysisPool.shutdownNow()
        thread?.quitSafely()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "ChessLens", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_launcher), "หยุด", stop).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("ChessLens กำลังทำงาน")
            .setContentText("กำลังดูกระดานหมากรุกบนหน้าจอ")
            .setOngoing(true)
            .addAction(action)
            .build()
    }

    // ------------------------------------------------------------------ overlay windows (main thread)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Point {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Point(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Point(dm.widthPixels, dm.heightPixels)
    }

    private fun fullScreenParams(touchable: Boolean): WindowManager.LayoutParams {
        val sz = screenSize()
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            sz.x, sz.y, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun smallButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(8), dp(4), dp(8), dp(4))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34))
        setOnClickListener { onClick() }
    }

    private fun buildOverlays() {
        val arrow = ArrowView(this)
        wm.addView(arrow, fullScreenParams(false))
        arrowView = arrow

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(10), dp(8), dp(10), dp(8))
        box.background = GradientDrawable().apply {
            setColor(Color.argb(232, 32, 39, 51))
            cornerRadius = dp(14).toFloat()
        }
        val title = TextView(this)
        title.text = "♞ ChessLens   (ลากตรงนี้เพื่อย้าย)"
        title.setTextColor(Color.rgb(255, 193, 7))
        title.textSize = 12f
        val status = TextView(this)
        status.text = "กำลังเริ่มระบบ…"
        status.setTextColor(Color.WHITE)
        status.textSize = 14f
        status.maxWidth = dp(270)
        statusView = status
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(smallButton("ตั้งกรอบ") { openEditor() })
        row.addView(smallButton("เรียนรู้") { work?.post { doLearn() } })
        row.addView(smallButton("สลับตา") { work?.post { doFlipTurn() } })
        row.addView(smallButton("กลับฝั่ง") { work?.post { doFlipSide() } })
        row.addView(smallButton("หยุด") { stopSelf() })
        box.addView(title)
        box.addView(status)
        box.addView(row)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(48)
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        title.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(box, lp) } catch (ex: Exception) { }
                }
            }
            true
        }
        wm.addView(box, lp)
        panel = box
        panelLp = lp
    }

    private fun removeOverlays() {
        for (v in listOf<View?>(editor, panel, arrowView)) {
            if (v != null) try { wm.removeView(v) } catch (e: Exception) { }
        }
        editor = null
        panel = null
        arrowView = null
    }

    private fun openEditor() {
        if (editor != null) return
        val sz = screenSize()
        val start = frameShadow ?: run {
            val side = (minOf(sz.x, sz.y) * 0.92f).toInt()
            Rect((sz.x - side) / 2, (sz.y - side) / 2, (sz.x - side) / 2 + side, (sz.y - side) / 2 + side)
        }
        val ed = FrameEditor(this, start, sz.x, sz.y) { result ->
            closeEditor()
            if (result != null) work?.post { applyFrame(result) }
        }
        wm.addView(ed, fullScreenParams(true))
        editor = ed
    }

    private fun closeEditor() {
        editor?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        editor = null
    }

    private fun setStatus(text: String) {
        main.post { statusView?.text = text }
    }

    private fun showArrowOnMain(a: Advice?) {
        main.post {
            val v = arrowView ?: return@post
            val f = frameShadow
            if (a == null || f == null) v.clear() else v.setArrow(f, a.from, a.to, bottomWhite)
        }
    }

    private fun onMainWait(block: () -> Unit) {
        val latch = CountDownLatch(1)
        main.post {
            try { block() } finally { latch.countDown() }
        }
        latch.await(500, TimeUnit.MILLISECONDS)
    }

    // ------------------------------------------------------------------ work thread: setup

    private fun initWork(proj: MediaProjection) {
        try {
            val sz = screenSize()
            grabber = ScreenGrabber(proj, work!!, sz.x, sz.y, resources.displayMetrics.densityDpi)
            if (prefs.templatesFile.exists()) {
                try {
                    prefs.templatesFile.inputStream().use { reader.load(it) }
                } catch (e: Exception) { }
            }
            bottomWhite = prefs.bottomIsWhite
            frame = prefs.frame(sz.x, sz.y)
            frameShadow = frame
            setStatus("กำลังเตรียมเอนจิน…")
            startEngine()
            setStatus(guideText())
            scheduleTick(500)
        } catch (e: Exception) {
            setStatus("เริ่มระบบไม่สำเร็จ: ${e.javaClass.simpleName}")
        }
    }

    private fun startEngine() {
        val lib = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (lib.exists()) {
            val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)
            val uci = UciEngine(lib.absolutePath, threads)
            if (uci.start()) {
                engine = uci
                engineTimeMs = 900
                return
            }
        }
        engine = BuiltinEngine()
        engineTimeMs = 1200
    }

    private fun guideText(): String = when {
        frame == null -> "กำลังหากระดานบนหน้าจอ… เปิดหน้าเกมหมากรุกให้เห็นกระดาน (หรือกด 'ตั้งกรอบ' เอง)"
        !reader.isReady -> "เจอกระดานแล้ว — เปิดเกมใหม่ให้เห็นตำแหน่งเริ่มต้น แอปจะเรียนรู้และรู้ฝั่งเองอัตโนมัติ"
        else -> "พร้อมแล้ว — เล่นได้เลย (คุณเล่น${if (bottomWhite) "ขาว" else "ดำ"})"
    }

    // ------------------------------------------------------------------ work thread: loop

    private fun scheduleTick(delayMs: Long) {
        val w = work ?: return
        w.removeCallbacks(tickRunnable)
        w.postDelayed(tickRunnable, delayMs)
    }

    private fun tick() {
        val g = grabber
        if (g != null) {
            try {
                step(g)
            } catch (e: Exception) {
                setStatus("เกิดข้อผิดพลาด: ${e.javaClass.simpleName} ${e.message ?: ""}")
            }
        }
        scheduleTick(TICK_MS)
    }

    private fun step(g: ScreenGrabber) {
        val sz = screenSize()
        if (sz.x != g.width || sz.y != g.height) {
            handleResize(g, sz)
            return
        }
        tickCount++
        val rect = frame
        if (rect == null) {
            autoFindBoard(g)
            return
        }
        if (tickCount % 5 == 0 && !frameManual) checkFrameStillBoard(g, rect)
        if (frame == null) return
        if (!reader.isReady) {
            autoLearn(g, rect)
            return
        }
        if (System.currentTimeMillis() < notBefore) return
        val sig = g.signature(rect) ?: return
        val prev = lastSig
        val changed = forceRead || prev == null || Signature.changed(prev, sig, ignore, CHANGE_THR)
        if (!changed) return
        forceRead = false
        onBoardChanged(g, rect, sig)
    }

    private fun autoFindBoard(g: ScreenGrabber) {
        val now = System.currentTimeMillis()
        if (now < nextFindAt) return
        nextFindAt = now + 1500
        val fb = g.findBoard()
        if (fb == null) {
            setStatus(guideText())
            return
        }
        val sz = screenSize()
        val r = Rect(fb.x, fb.y, fb.x + fb.size, fb.y + fb.size)
        frameManual = false
        verifyFails = 0
        applyFrame(r, auto = true)
        if (sz.x == 0) return
    }

    /** If the saved/found frame no longer shows a checkerboard (user left the game page, or it moved), search again. */
    private fun checkFrameStillBoard(g: ScreenGrabber, rect: Rect) {
        if (g.verifyBoard(rect)) {
            verifyFails = 0
            return
        }
        verifyFails++
        if (verifyFails < 3) return
        verifyFails = 0
        // the board may have moved (or a pop-up covers it): look for it again, but keep the old frame until a new one is found
        val fb = g.findBoard() ?: return
        val moved = Math.abs(fb.x - rect.left) > fb.size / 80 || Math.abs(fb.y - rect.top) > fb.size / 80 ||
            Math.abs(fb.size - rect.width()) > fb.size / 80
        if (moved) applyFrame(Rect(fb.x, fb.y, fb.x + fb.size, fb.y + fb.size), auto = true)
    }

    /** Waits for the start position, then works out our colour and learns the pieces by itself. */
    private fun autoLearn(g: ScreenGrabber, rect: Rect) {
        val now = System.currentTimeMillis()
        if (now < nextLearnAt) return
        nextLearnAt = now + 1000
        val img = g.grabBoard(rect) ?: return
        if (reader.detectBottomWhite(img) == null) return // not a start position (yet)
        doLearn()
    }

    private fun handleResize(g: ScreenGrabber, sz: Point) {
        g.resize(sz.x, sz.y)
        frame = prefs.frame(sz.x, sz.y)
        frameShadow = frame
        frameManual = false
        verifyFails = 0
        nextFindAt = 0
        lastSig = null
        accepted = null
        pending = null
        advice = null
        generation++
        main.post {
            arrowView?.let { v -> try { wm.updateViewLayout(v, fullScreenParams(false)) } catch (e: Exception) { } }
            arrowView?.clear()
        }
        setStatus(if (frame == null) "หมุนหน้าจอแล้ว — กำลังหากระดานใหม่…" else guideText())
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { }
    }

    private fun onBoardChanged(g: ScreenGrabber, rect: Rect, sig: IntArray) {
        generation++
        ignore = null
        showArrowOnMain(null)
        // let piece animations finish: two samples a moment apart must agree
        sleep(230)
        val sig2 = g.signature(rect) ?: return
        if (Signature.changed(sig, sig2, null, CHANGE_THR)) {
            lastSig = sig2
            forceRead = true
            return
        }
        lastSig = sig2
        val img = cleanCapture(g, rect) ?: return
        val res = reader.read(img, bottomWhite)
        if (!res.ok) {
            pending = null
            failCount++
            forceRead = failCount < 3 // after 3 tries wait for the screen to change instead of retrying forever
            notBefore = System.currentTimeMillis() + 1200
            setStatus("อ่านกระดานไม่ออก: ${res.reason}\n" + gridText(res.pieces) + "\n(เปลี่ยนธีม/กระดานแล้ว? เปิดเกมใหม่ตอนตำแหน่งเริ่มต้น แอปจะเรียนรู้ใหม่เอง)")
            if (reader.detectBottomWhite(img) != null) {
                doLearn()
            }
            return
        }
        failCount = 0
        if (tracker.pos == null || looksLikeStart(res.pieces)) {
            // work out which colour is at the bottom; if the guess was wrong, flip and read again
            val guess = reader.guessBottomWhite(img)
            if (guess != null && guess != bottomWhite) {
                setBottom(guess)
                tracker.reset()
                accepted = null
                pending = null
                advice = null
                forceRead = true
                setStatus("ตรวจพบว่าคุณเล่น${if (guess) "ขาว" else "ดำ"}")
                return
            }
        }
        val acc = accepted
        if (acc != null && acc.contentEquals(res.pieces)) {
            // nothing changed on the board itself (e.g. only our own overlay): bring the advice back
            if (tracker.pos != null) analyzeCurrent()
            return
        }
        val pend = pending
        if (pend == null || !pend.contentEquals(res.pieces)) {
            // the same picture must be read twice in a row before it is trusted
            pending = res.pieces
            forceRead = true
            notBefore = System.currentTimeMillis() + 150
            return
        }
        pending = null
        failCount = 0
        accepted = res.pieces
        advice = null
        tracker.update(res.pieces, userColor)
        analyzeCurrent()
    }

    /** What the app currently reads, row by row as on the screen (capital = white), for diagnosing wrong reads. */
    private fun gridText(p: IntArray): String {
        val sb = StringBuilder()
        for (row in 0 until 8) {
            for (col in 0 until 8) sb.append(Piece.toChar(p[BoardReader.squareOf(row, col, bottomWhite)])).append(' ')
            if (row < 7) sb.append('\n')
        }
        return sb.toString()
    }

    private fun looksLikeStart(p: IntArray): Boolean {
        var n = 0
        for (sq in 0 until 64) if (p[sq] != 0) {
            val rank = sq shr 3
            if (rank != 0 && rank != 1 && rank != 6 && rank != 7) return false
            n++
        }
        return n == 32
    }

    /** Picture of the board without our own panel on top of it. */
    private fun cleanCapture(g: ScreenGrabber, rect: Rect): BoardImage? {
        val p = panel
        val lp = panelLp
        var hid = false
        if (p != null && lp != null) {
            val pr = Rect(lp.x, lp.y, lp.x + p.width, lp.y + p.height)
            if (Rect.intersects(pr, rect)) {
                val before = g.frameCount
                onMainWait { p.visibility = View.INVISIBLE }
                g.awaitFrame(before, 350)
                sleep(40)
                hid = true
            }
        }
        val img = g.grabBoard(rect)
        if (hid) onMainWait { p?.visibility = View.VISIBLE }
        return img
    }

    // ------------------------------------------------------------------ work thread: analysis

    private fun turnNote(): String = if (tracker.assumedTurn) "\n(เดาว่าเป็นตาคุณ — กด 'สลับตา' ถ้าไม่ใช่)" else ""

    private fun analyzeCurrent() {
        val pos = tracker.pos ?: return
        val moves = pos.legalMoves()
        if (moves.isEmpty()) {
            advice = null
            showArrowOnMain(null)
            setStatus(if (pos.inCheck()) "รุกจน — จบเกม" else "เสมอ (ไม่มีตาเดิน)")
            return
        }
        if (pos.side != userColor) {
            advice = null
            showArrowOnMain(null)
            setStatus("รอคู่ต่อสู้เดิน…" + turnNote())
            return
        }
        val a = advice
        if (a != null) {
            applyAdvice(a)
            return
        }
        val eng = engine ?: return
        val snapshot = pos.copy()
        val gen = generation
        val ms = engineTimeMs
        setStatus("กำลังคิด…")
        analysisPool.execute {
            val r = try { eng.analyze(snapshot, ms) } catch (e: Exception) { null }
            work?.post {
                if (gen == generation && r != null) {
                    val text = MoveText.describe(snapshot, r.move) + "\nประเมิน: " + MoveText.scoreText(r) +
                        "  (${eng.name}, ลึก ${r.depth})" + turnNote()
                    val adv = Advice(Moves.from(r.move), Moves.to(r.move), text)
                    advice = adv
                    applyAdvice(adv)
                }
            }
        }
    }

    private fun applyAdvice(a: Advice) {
        ignore = BoardGeometry.arrowSampleMask(a.from, a.to, bottomWhite)
        showArrowOnMain(a)
        setStatus(a.text)
    }

    // ------------------------------------------------------------------ work thread: user actions

    private fun applyFrame(r: Rect, auto: Boolean = false) {
        val sz = screenSize()
        frame = r
        frameShadow = r
        if (!auto) frameManual = true
        prefs.setFrame(sz.x, sz.y, r)
        lastSig = null
        accepted = null
        pending = null
        advice = null
        generation++
        showArrowOnMain(null)
        setStatus(guideText())
    }

    private fun doLearn() {
        val g = grabber ?: return
        val rect = frame
        if (rect == null) {
            setStatus("ตั้งกรอบกระดานก่อน (กด 'ตั้งกรอบ')")
            return
        }
        generation++
        advice = null
        ignore = null
        showArrowOnMain(null)
        sleep(300)
        val img = cleanCapture(g, rect)
        if (img == null) {
            setStatus("ยังไม่ได้รับภาพหน้าจอ ลองอีกครั้ง")
            return
        }
        val (lr, side) = reader.learnAuto(img)
        if (lr.ok && side != null) {
            setBottom(side)
            try {
                prefs.templatesFile.outputStream().use { reader.save(it) }
            } catch (e: Exception) { }
            tracker.reset()
            accepted = null
            pending = null
            lastSig = null
            forceRead = true
            notBefore = 0
            setStatus(lr.message + "\nคุณเล่น${if (side) "ขาว" else "ดำ"} — เริ่มเล่นได้เลย")
        } else {
            setStatus(lr.message)
        }
    }

    private fun doFlipSide() {
        generation++
        advice = null
        ignore = null
        showArrowOnMain(null)
        setBottom(!bottomWhite)
        tracker.reset()
        accepted = null
        pending = null
        lastSig = null
        forceRead = true
        setStatus("สลับเป็นเล่น${if (bottomWhite) "ขาว" else "ดำ"}")
    }

    private fun doFlipTurn() {
        if (tracker.pos == null) return
        generation++
        advice = null
        ignore = null
        showArrowOnMain(null)
        tracker.flipTurn()
        analyzeCurrent()
    }
}
