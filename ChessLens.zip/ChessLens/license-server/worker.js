// ChessLens licence server: one Cloudflare Worker + one KV namespace.
// Bindings needed: KV namespace "LICENSES", secret "ADMIN_PASSWORD".

const DAY = 86400000;
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I

const enc = new TextEncoder();
const b64u = (buf) => {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
const b64 = (buf) => {
  const bytes = new Uint8Array(buf);
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
};

let signer = null;
async function getSigner(env) {
  if (signer) return signer;
  const stored = await env.LICENSES.get("cfg:signing", "json");
  if (stored) {
    const priv = await crypto.subtle.importKey("jwk", stored.jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
    signer = { priv, spki: stored.spki };
    return signer;
  }
  const pair = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
  const jwk = await crypto.subtle.exportKey("jwk", pair.privateKey);
  const spki = b64(await crypto.subtle.exportKey("spki", pair.publicKey));
  await env.LICENSES.put("cfg:signing", JSON.stringify({ jwk, spki }));
  const priv = await crypto.subtle.importKey("jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  signer = { priv, spki };
  return signer;
}

async function makeToken(env, payload) {
  const { priv } = await getSigner(env);
  const body = b64u(enc.encode(JSON.stringify(payload)));
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, priv, enc.encode(body));
  return body + "." + b64u(sig); // sig is raw r||s (64 bytes)
}

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });

const normKey = (k) => String(k || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
function prettyKey(raw) {
  return "CL-" + raw.slice(2).match(/.{1,4}/g).join("-");
}
function newKey() {
  const r = crypto.getRandomValues(new Uint8Array(12));
  let s = "CL";
  for (const b of r) s += ALPHABET[b % 32];
  return s; // CL + 12 chars
}
const kvKey = (raw) => "k:" + raw;

function safeEqual(a, b) {
  a = String(a || "");
  b = String(b || "");
  let d = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) d |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return d === 0;
}

async function verify(env, body) {
  const raw = normKey(body.key);
  const device = String(body.device || "");
  if (raw.length !== 14 || !raw.startsWith("CL") || device.length < 8) return json({ ok: false, error: "invalid", message: "คีย์ไม่ถูกต้อง" });
  const rec = await env.LICENSES.get(kvKey(raw), "json");
  if (!rec) return json({ ok: false, error: "invalid", message: "ไม่พบคีย์นี้" });
  const now = Date.now();
  if (rec.revoked) return json({ ok: false, error: "revoked", message: "คีย์นี้ถูกยกเลิกแล้ว" });
  if (rec.device && rec.device !== device) return json({ ok: false, error: "used", message: "คีย์นี้ถูกใช้กับเครื่องอื่นแล้ว" });
  if (!rec.device) {
    rec.device = device;
    rec.activatedAt = now;
    rec.expiresAt = now + rec.days * DAY;
    await env.LICENSES.put(kvKey(raw), JSON.stringify(rec));
  }
  if (now >= rec.expiresAt) return json({ ok: false, error: "expired", message: "คีย์หมดอายุแล้ว", exp: rec.expiresAt });
  const token = await makeToken(env, { k: raw, d: device, exp: rec.expiresAt, iat: now });
  return json({ ok: true, token, exp: rec.expiresAt, now });
}

async function listAll(env) {
  const out = [];
  let cursor;
  do {
    const page = await env.LICENSES.list({ prefix: "k:", cursor, limit: 1000 });
    for (const k of page.keys) {
      const rec = await env.LICENSES.get(k.name, "json");
      if (rec) out.push({ key: prettyKey(k.name.slice(2)), raw: k.name.slice(2), ...rec });
    }
    cursor = page.list_complete ? undefined : page.cursor;
  } while (cursor);
  out.sort((a, b) => b.created - a.created);
  return out;
}

async function admin(env, path, body) {
  if (path === "/api/admin/list") return json({ keys: await listAll(env), now: Date.now() });
  if (path === "/api/admin/create") {
    const days = Math.floor(Number(body.days));
    const count = Math.min(100, Math.max(1, Math.floor(Number(body.count) || 1)));
    if (!(days >= 1 && days <= 3650)) return json({ error: "days ต้องอยู่ระหว่าง 1 ถึง 3650" }, 400);
    const made = [];
    for (let i = 0; i < count; i++) {
      const raw = newKey();
      await env.LICENSES.put(kvKey(raw), JSON.stringify({ days, note: String(body.note || "").slice(0, 80), created: Date.now(), revoked: false }));
      made.push(prettyKey(raw));
    }
    return json({ created: made });
  }
  const raw = normKey(body.key);
  const rec = await env.LICENSES.get(kvKey(raw), "json");
  if (!rec) return json({ error: "ไม่พบคีย์" }, 404);
  if (path === "/api/admin/revoke") {
    rec.revoked = body.revoked !== false;
    await env.LICENSES.put(kvKey(raw), JSON.stringify(rec));
  } else if (path === "/api/admin/unbind") {
    delete rec.device;
    // keep the remaining time: the clock restarts when the key is activated again
    if (rec.expiresAt) rec.days = Math.max(1, Math.ceil((rec.expiresAt - Date.now()) / DAY));
    delete rec.activatedAt;
    delete rec.expiresAt;
    await env.LICENSES.put(kvKey(raw), JSON.stringify(rec));
  } else if (path === "/api/admin/extend") {
    const d = Math.floor(Number(body.days));
    if (!(d >= 1 && d <= 3650)) return json({ error: "days ไม่ถูกต้อง" }, 400);
    if (rec.expiresAt) rec.expiresAt += d * DAY;
    else rec.days += d;
    await env.LICENSES.put(kvKey(raw), JSON.stringify(rec));
  } else if (path === "/api/admin/delete") {
    await env.LICENSES.delete(kvKey(raw));
  } else return json({ error: "not found" }, 404);
  return json({ ok: true });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    try {
      if (request.method === "GET" && (path === "/" || path === "/admin")) {
        return new Response(ADMIN_HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
      }
      if (request.method === "GET" && path === "/api/pubkey") return json({ spki: (await getSigner(env)).spki });
      if (request.method !== "POST") return json({ error: "not found" }, 404);
      let body = {};
      try { body = await request.json(); } catch (e) { return json({ error: "bad json" }, 400); }
      if (path === "/api/verify") return await verify(env, body);
      if (path.startsWith("/api/admin/")) {
        if (!env.ADMIN_PASSWORD || !safeEqual(request.headers.get("x-admin-password"), env.ADMIN_PASSWORD)) {
          await new Promise((r) => setTimeout(r, 800));
          return json({ error: "รหัสผ่านไม่ถูกต้อง" }, 401);
        }
        return await admin(env, path, body);
      }
      return json({ error: "not found" }, 404);
    } catch (e) {
      return json({ error: "server error: " + (e && e.message) }, 500);
    }
  },
};

const ADMIN_HTML = `<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ChessLens Keys</title><style>
:root{--bg:#0a0f15;--card:#141c26;--line:#2a3848;--tx:#e9f0f7;--mut:#8797a9;--ac:#34e2a8;--er:#ff6f75;--go:#ffc43d}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.4 system-ui,sans-serif;padding:16px;max-width:760px;margin:auto}
h1{font-size:22px;margin:4px 0 14px}.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:14px}
input,select{width:100%;background:#0d141c;border:1px solid var(--line);border-radius:10px;color:var(--tx);padding:11px;font-size:15px;margin:4px 0 10px}
button{background:linear-gradient(135deg,#34e2a8,#14a884);color:#042018;border:0;border-radius:10px;padding:11px 14px;font-weight:700;font-size:14px}
button.g{background:#1d2835;color:var(--tx);font-weight:600;padding:8px 10px;margin:3px 3px 0 0}button.r{color:var(--er)}
.row{display:flex;gap:10px}.row>*{flex:1}.k{font:600 16px ui-monospace,monospace;letter-spacing:.5px}
.p{display:inline-block;padding:2px 9px;border-radius:20px;font-size:12px;font-weight:700}
.free{background:#34e2a826;color:var(--ac)}.used{background:#ffc43d26;color:var(--go)}.bad{background:#ff6f7526;color:var(--er)}
.it{border-top:1px solid var(--line);padding:11px 0}.m{color:var(--mut);font-size:13px}pre{white-space:pre-wrap;margin:0;font:600 15px ui-monospace,monospace}
</style></head><body><h1>♞ ChessLens Keys</h1>
<div class="card" id="login"><label class="m">รหัสผ่านแอดมิน</label><input id="pw" type="password" autocomplete="current-password"><button onclick="go()">เข้าสู่ระบบ</button><div id="lerr" class="m" style="color:var(--er)"></div></div>
<div id="main" style="display:none">
<div class="card"><b>สร้างคีย์ใหม่</b><div class="row"><div><label class="m">จำนวนวัน</label><input id="days" type="number" value="30" min="1"></div><div><label class="m">จำนวนคีย์</label><input id="count" type="number" value="1" min="1" max="100"></div></div>
<label class="m">โน้ต (ไม่บังคับ เช่น ชื่อลูกค้า)</label><input id="note" maxlength="80"><button onclick="create()">สร้างคีย์</button><div id="made" style="margin-top:10px"></div></div>
<div class="card"><div class="row" style="align-items:center"><b>คีย์ทั้งหมด</b><button class="g" style="flex:0" onclick="load()">รีเฟรช</button></div><div id="list"></div></div></div>
<script>
const $=id=>document.getElementById(id);let PW=sessionStorage.getItem('pw')||'';
async function api(p,b){const r=await fetch(p,{method:'POST',headers:{'content-type':'application/json','x-admin-password':PW},body:JSON.stringify(b||{})});const j=await r.json();if(!r.ok)throw new Error(j.error||r.status);return j}
async function go(){PW=$('pw').value;try{await api('/api/admin/list');sessionStorage.setItem('pw',PW);show()}catch(e){$('lerr').textContent=e.message}}
function show(){$('login').style.display='none';$('main').style.display='block';load()}
const fmt=t=>new Date(t).toLocaleString('th-TH',{dateStyle:'medium',timeStyle:'short'});
async function load(){const j=await api('/api/admin/list');$('list').innerHTML=j.keys.map(k=>{let st,cl;
if(k.revoked){st='ยกเลิก';cl='bad'}else if(!k.device){st='ยังไม่ถูกใช้ · '+k.days+' วัน';cl='free'}else if(j.now>=k.expiresAt){st='หมดอายุ';cl='bad'}else{st='ใช้งานอยู่ · เหลือ '+Math.ceil((k.expiresAt-j.now)/864e5)+' วัน';cl='used'}
return '<div class="it"><div class="k">'+k.key+'</div><span class="p '+cl+'">'+st+'</span><div class="m">'+(k.note?k.note+' · ':'')+'สร้าง '+fmt(k.created)+(k.expiresAt?' · หมด '+fmt(k.expiresAt):'')+'</div><div>'
+'<button class="g" onclick="cp(\\''+k.key+'\\')">คัดลอก</button><button class="g" onclick="ext(\\''+k.raw+'\\')">ต่ออายุ</button>'
+(k.device?'<button class="g" onclick="act(\\'unbind\\',\\''+k.raw+'\\')">ล้างเครื่องที่ผูก</button>':'')
+'<button class="g r" onclick="act(\\'revoke\\',\\''+k.raw+'\\',{revoked:'+(!k.revoked)+'})">'+(k.revoked?'เปิดคืน':'ยกเลิก')+'</button>'
+'<button class="g r" onclick="del(\\''+k.raw+'\\')">ลบ</button></div></div>'}).join('')||'<div class="m">ยังไม่มีคีย์</div>'}
async function create(){try{const j=await api('/api/admin/create',{days:$('days').value,count:$('count').value,note:$('note').value});
$('made').innerHTML='<pre>'+j.created.join('\\n')+'</pre><button class="g" onclick="cp(\\''+j.created.join('\\\\n')+'\\')">คัดลอกทั้งหมด</button>';load()}catch(e){alert(e.message)}}
function cp(t){navigator.clipboard&&navigator.clipboard.writeText(t.replace(/\\\\n/g,'\\n'))}
async function act(a,k,x){try{await api('/api/admin/'+a,Object.assign({key:k},x||{}));load()}catch(e){alert(e.message)}}
async function ext(k){const d=prompt('ต่ออายุอีกกี่วัน?','30');if(d)act('extend',k,{days:d})}
async function del(k){if(confirm('ลบคีย์นี้ถาวร?'))act('delete',k)}
if(PW)api('/api/admin/list').then(show).catch(()=>{});
</script></body></html>`;
