# วิธีติดตั้งระบบคีย์ (ทำบนมือถือได้ทั้งหมด ใช้ Cloudflare ฟรี)

1. เข้า dash.cloudflare.com สมัคร/ล็อกอิน แล้วไปที่ Workers & Pages > Create > Create Worker ตั้งชื่อ เช่น `chesslens-keys` กด Deploy
2. กด Edit code ลบโค้ดเดิมทั้งหมด วางโค้ดจากไฟล์ `worker.js` แล้วกด Deploy
3. ไปที่ Storage & Databases > KV > Create namespace ตั้งชื่อ `chesslens-licenses`
4. กลับมาที่ Worker > Settings > Bindings > Add > KV namespace
   - Variable name: `LICENSES` (พิมพ์ตัวใหญ่ตามนี้)
   - เลือก namespace ที่สร้างไว้ แล้วบันทึก
5. Settings > Variables and Secrets > Add > ชนิด Secret ชื่อ `ADMIN_PASSWORD` ใส่รหัสผ่านยาวๆ ที่คาดเดายาก แล้ว Deploy
6. เปิดที่อยู่ของ Worker (เช่น `https://chesslens-keys.ชื่อคุณ.workers.dev`) ใส่รหัสผ่านแอดมิน จะเห็นหน้าสร้างคีย์
7. ใน GitHub แก้ไฟล์ `app/src/main/assets/license.json` ใส่ที่อยู่ Worker:
   `{"server": "https://chesslens-keys.ชื่อคุณ.workers.dev", "pubkey": ""}`
   แล้ว build ใหม่ (ก่อนทำข้อนี้ แอปยังไม่บังคับใช้คีย์)
8. (แนะนำ) เปิด `https://ที่อยู่ของคุณ/api/pubkey` คัดลอกค่า spki ไปใส่ใน `pubkey` ของ license.json เพื่อล็อกให้แอปเชื่อเฉพาะเซิร์ฟเวอร์ของคุณ

หมายเหตุ: คีย์ใหม่อาจใช้เวลาราวหนึ่งนาทีกว่าจะมองเห็นทั่วโลก ถ้าลูกค้าเปลี่ยนเครื่อง กด "ล้างเครื่องที่ผูก" ที่คีย์นั้น
